package handlers

import (
        "encoding/json"
        "fmt"
        "net/http"
        "os"
        "os/exec"
        "runtime"
        "strconv"
        "strings"
        "time"

        "amneziawg-manager/logger"
)

type SystemInfo struct {
        Uptime       string      `json:"uptime"`
        Hostname     string      `json:"hostname"`
        Kernel       string      `json:"kernel"`
        Distribution string      `json:"distribution"`
        CPU          CPUInfo     `json:"cpu"`
        Memory       MemoryInfo  `json:"memory"`
        Storage      StorageInfo `json:"storage"`
        Network      NetworkInfo `json:"network"`
}

type CPUInfo struct {
        Usage       float64 `json:"usage"`
        Temperature float64 `json:"temperature"`
        Cores       int     `json:"cores"`
        Model       string  `json:"model"`
}

type MemoryInfo struct {
        Total     uint64  `json:"total"`
        Used      uint64  `json:"used"`
        Free      uint64  `json:"free"`
        UsedPercent float64 `json:"used_percent"`
}

type StorageInfo struct {
        Total     uint64  `json:"total"`
        Used      uint64  `json:"used"`
        Free      uint64  `json:"free"`
        UsedPercent float64 `json:"used_percent"`
}

type NetworkInfo struct {
        BytesReceived uint64  `json:"bytes_received"`
        BytesSent     uint64  `json:"bytes_sent"`
        RxRate        float64 `json:"rx_rate"`
        TxRate        float64 `json:"tx_rate"`
}

func APISystemInfoHandler(w http.ResponseWriter, r *http.Request) {
        info := getSystemInfo()
        
        w.Header().Set("Content-Type", "application/json")
        if err := json.NewEncoder(w).Encode(info); err != nil {
                logger.Log.Error("failed to encode system info response", "error", err)
        }
}

func getSystemInfo() SystemInfo {
        return SystemInfo{
                Uptime:       getUptime(),
                Hostname:     getSystemHostname(),
                Kernel:       getKernel(),
                Distribution: getDistribution(),
                CPU:          getCPUInfo(),
                Memory:       getMemoryInfo(),
                Storage:      getStorageInfo(),
                Network:      getNetworkInfo(),
        }
}

func getUptime() string {
        data, err := os.ReadFile("/proc/uptime")
        if err != nil {
                logger.Log.Debug("failed to read uptime", "error", err)
                return "N/A"
        }
        
        fields := strings.Fields(string(data))
        if len(fields) < 1 {
                return "N/A"
        }
        
        uptimeSeconds, err := strconv.ParseFloat(fields[0], 64)
        if err != nil {
                return "N/A"
        }
        
        duration := time.Duration(uptimeSeconds) * time.Second
        days := int(duration.Hours() / 24)
        hours := int(duration.Hours()) % 24
        minutes := int(duration.Minutes()) % 60
        
        if days > 0 {
                return fmt.Sprintf("%dd %dh %dm", days, hours, minutes)
        }
        return fmt.Sprintf("%dh %dm", hours, minutes)
}

func getSystemHostname() string {
        hostname, err := os.Hostname()
        if err != nil {
                logger.Log.Debug("failed to get hostname", "error", err)
                return "N/A"
        }
        return hostname
}

func getKernel() string {
        cmd := exec.Command("uname", "-r")
        output, err := cmd.Output()
        if err != nil {
                logger.Log.Debug("failed to get kernel version", "error", err)
                return "N/A"
        }
        return strings.TrimSpace(string(output))
}

func getDistribution() string {
        data, err := os.ReadFile("/etc/os-release")
        if err != nil {
                cmd := exec.Command("uname", "-s")
                output, err := cmd.Output()
                if err != nil {
                        return "N/A"
                }
                return strings.TrimSpace(string(output))
        }
        
        lines := strings.Split(string(data), "\n")
        for _, line := range lines {
                if strings.HasPrefix(line, "PRETTY_NAME=") {
                        name := strings.TrimPrefix(line, "PRETTY_NAME=")
                        name = strings.Trim(name, "\"")
                        return name
                }
        }
        return "Linux"
}

func getCPUInfo() CPUInfo {
        info := CPUInfo{
                Cores: runtime.NumCPU(),
                Model: getCPUModel(),
        }
        
        info.Usage = getCPUUsage()
        info.Temperature = getCPUTemperature()
        
        return info
}

func getCPUModel() string {
        data, err := os.ReadFile("/proc/cpuinfo")
        if err != nil {
                return "N/A"
        }
        
        lines := strings.Split(string(data), "\n")
        for _, line := range lines {
                if strings.HasPrefix(line, "model name") {
                        parts := strings.SplitN(line, ":", 2)
                        if len(parts) == 2 {
                                return strings.TrimSpace(parts[1])
                        }
                }
        }
        return "N/A"
}

func getCPUUsage() float64 {
        stat1, err := readCPUStat()
        if err != nil {
                return 0
        }
        
        time.Sleep(100 * time.Millisecond)
        
        stat2, err := readCPUStat()
        if err != nil {
                return 0
        }
        
        idle := stat2[3] - stat1[3]
        total := (stat2[0] + stat2[1] + stat2[2] + stat2[3]) - (stat1[0] + stat1[1] + stat1[2] + stat1[3])
        
        if total == 0 {
                return 0
        }
        
        usage := 100.0 * (1.0 - float64(idle)/float64(total))
        return usage
}

func readCPUStat() ([]uint64, error) {
        data, err := os.ReadFile("/proc/stat")
        if err != nil {
                return nil, err
        }
        
        lines := strings.Split(string(data), "\n")
        for _, line := range lines {
                if strings.HasPrefix(line, "cpu ") {
                        fields := strings.Fields(line)
                        if len(fields) < 5 {
                                return nil, fmt.Errorf("invalid cpu stat format")
                        }
                        
                        stats := make([]uint64, 4)
                        for i := 0; i < 4; i++ {
                                val, err := strconv.ParseUint(fields[i+1], 10, 64)
                                if err != nil {
                                        return nil, err
                                }
                                stats[i] = val
                        }
                        return stats, nil
                }
        }
        return nil, fmt.Errorf("cpu stat not found")
}

func getCPUTemperature() float64 {
        paths := []string{
                "/sys/class/thermal/thermal_zone0/temp",
                "/sys/class/hwmon/hwmon0/temp1_input",
                "/sys/class/hwmon/hwmon1/temp1_input",
        }
        
        for _, path := range paths {
                data, err := os.ReadFile(path)
                if err != nil {
                        continue
                }
                
                temp, err := strconv.ParseFloat(strings.TrimSpace(string(data)), 64)
                if err != nil {
                        continue
                }
                
                if temp > 1000 {
                        temp = temp / 1000.0
                }
                
                if temp > 0 && temp < 200 {
                        return temp
                }
        }
        
        return 0
}

func getMemoryInfo() MemoryInfo {
        info := MemoryInfo{}
        
        data, err := os.ReadFile("/proc/meminfo")
        if err != nil {
                logger.Log.Debug("failed to read meminfo", "error", err)
                return info
        }
        
        lines := strings.Split(string(data), "\n")
        memData := make(map[string]uint64)
        
        for _, line := range lines {
                fields := strings.Fields(line)
                if len(fields) < 2 {
                        continue
                }
                
                key := strings.TrimSuffix(fields[0], ":")
                value, err := strconv.ParseUint(fields[1], 10, 64)
                if err != nil {
                        continue
                }
                
                memData[key] = value * 1024
        }
        
        info.Total = memData["MemTotal"]
        info.Free = memData["MemFree"] + memData["Buffers"] + memData["Cached"]
        info.Used = info.Total - info.Free
        
        if info.Total > 0 {
                info.UsedPercent = float64(info.Used) / float64(info.Total) * 100.0
        }
        
        return info
}

func getStorageInfo() StorageInfo {
        info := StorageInfo{}
        
        cmd := exec.Command("df", "-B1", "/")
        output, err := cmd.Output()
        if err != nil {
                logger.Log.Debug("failed to get storage info", "error", err)
                return info
        }
        
        lines := strings.Split(string(output), "\n")
        if len(lines) < 2 {
                return info
        }
        
        fields := strings.Fields(lines[1])
        if len(fields) < 4 {
                return info
        }
        
        total, _ := strconv.ParseUint(fields[1], 10, 64)
        used, _ := strconv.ParseUint(fields[2], 10, 64)
        free, _ := strconv.ParseUint(fields[3], 10, 64)
        
        info.Total = total
        info.Used = used
        info.Free = free
        
        if info.Total > 0 {
                info.UsedPercent = float64(info.Used) / float64(info.Total) * 100.0
        }
        
        return info
}

func getNetworkInfo() NetworkInfo {
        info := NetworkInfo{}
        
        data, err := os.ReadFile("/proc/net/dev")
        if err != nil {
                logger.Log.Debug("failed to read network stats", "error", err)
                return info
        }
        
        lines := strings.Split(string(data), "\n")
        for _, line := range lines {
                if !strings.Contains(line, ":") {
                        continue
                }
                
                parts := strings.Split(line, ":")
                if len(parts) != 2 {
                        continue
                }
                
                iface := strings.TrimSpace(parts[0])
                if iface == "lo" {
                        continue
                }
                
                fields := strings.Fields(parts[1])
                if len(fields) < 9 {
                        continue
                }
                
                rx, _ := strconv.ParseUint(fields[0], 10, 64)
                tx, _ := strconv.ParseUint(fields[8], 10, 64)
                
                info.BytesReceived += rx
                info.BytesSent += tx
        }
        
        return info
}
