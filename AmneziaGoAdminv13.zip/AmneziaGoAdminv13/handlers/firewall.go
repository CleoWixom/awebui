package handlers

import (
        "encoding/json"
        "html/template"
        "io/ioutil"
        "net/http"
        "os/exec"
        "strings"
)

type FirewallRule struct {
        Table    string `json:"table"`
        Chain    string `json:"chain"`
        Rule     string `json:"rule"`
        Handle   string `json:"handle,omitempty"`
}

type FirewallStatus struct {
        Forwarding     bool   `json:"forwarding"`
        Masquerading   bool   `json:"masquerading"`
        Rules          []FirewallRule `json:"rules"`
        SourceIface    string `json:"source_iface"`
        DestIface      string `json:"dest_iface"`
}

type ForwardingConfig struct {
        Enabled    bool   `json:"enabled"`
        SourceIface string `json:"source_iface"`
        DestIface   string `json:"dest_iface"`
}

type MasqueradeConfig struct {
        Enabled   bool   `json:"enabled"`
        Interface string `json:"interface"`
}

func FirewallPageHandler(w http.ResponseWriter, r *http.Request) {
        tmpl := template.Must(template.ParseFiles("templates/firewall.html", "templates/layout.html"))
        tmpl.ExecuteTemplate(w, "layout", nil)
}

func APIFirewallStatusHandler(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")

        status := FirewallStatus{
                Forwarding:   isIPForwardingEnabled(),
                Masquerading: isMasqueradingEnabled(),
                Rules:        getNftablesRules(),
                SourceIface:  "eth0",
                DestIface:    "eth1",
        }

        json.NewEncoder(w).Encode(status)
}

func APIFirewallToggleForwardingHandler(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")

        var config ForwardingConfig
        if err := json.NewDecoder(r.Body).Decode(&config); err != nil {
                w.WriteHeader(http.StatusBadRequest)
                json.NewEncoder(w).Encode(map[string]interface{}{
                        "success": false,
                        "message": "Invalid request",
                })
                return
        }

        originalState := isIPForwardingEnabled()
        
        if !setIPForwarding(config.Enabled) {
                w.WriteHeader(http.StatusInternalServerError)
                json.NewEncoder(w).Encode(map[string]interface{}{
                        "success": false,
                        "message": "Failed to toggle IP forwarding in sysctl",
                })
                return
        }

        if config.Enabled && config.SourceIface != "" && config.DestIface != "" {
                if !setupInterfaceForwarding(config.SourceIface, config.DestIface) {
                        setIPForwarding(originalState)
                        w.WriteHeader(http.StatusInternalServerError)
                        json.NewEncoder(w).Encode(map[string]interface{}{
                                "success": false,
                                "message": "Failed to setup nftables forwarding rules",
                        })
                        return
                }
        } else if !config.Enabled {
                exec.Command("nft", "flush", "chain", "inet", "amneziawg_filter", "forward").Run()
        }

        json.NewEncoder(w).Encode(map[string]interface{}{
                "success": true,
                "message": "IP forwarding " + map[bool]string{true: "enabled", false: "disabled"}[config.Enabled],
        })
}

func APIFirewallToggleMasqueradeHandler(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")

        var config MasqueradeConfig
        if err := json.NewDecoder(r.Body).Decode(&config); err != nil {
                w.WriteHeader(http.StatusBadRequest)
                json.NewEncoder(w).Encode(map[string]interface{}{
                        "success": false,
                        "message": "Invalid request",
                })
                return
        }

        if !setMasquerading(config.Enabled, config.Interface) {
                w.WriteHeader(http.StatusInternalServerError)
                json.NewEncoder(w).Encode(map[string]interface{}{
                        "success": false,
                        "message": "Failed to configure masquerading",
                })
                return
        }
        
        json.NewEncoder(w).Encode(map[string]interface{}{
                "success": true,
                "message": "Masquerading " + map[bool]string{true: "enabled", false: "disabled"}[config.Enabled],
        })
}

func APIFirewallAddRuleHandler(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")

        var rule FirewallRule
        if err := json.NewDecoder(r.Body).Decode(&rule); err != nil {
                w.WriteHeader(http.StatusBadRequest)
                json.NewEncoder(w).Encode(map[string]interface{}{
                        "success": false,
                        "message": "Invalid request",
                })
                return
        }

        args := []string{"add", "rule"}
        args = append(args, strings.Fields(rule.Table)...)
        args = append(args, rule.Chain)
        args = append(args, strings.Fields(rule.Rule)...)

        cmd := exec.Command("nft", args...)
        output, err := cmd.CombinedOutput()
        if err != nil {
                w.WriteHeader(http.StatusInternalServerError)
                json.NewEncoder(w).Encode(map[string]interface{}{
                        "success": false,
                        "message": "Failed to add rule: " + string(output),
                })
                return
        }

        json.NewEncoder(w).Encode(map[string]interface{}{
                "success": true,
                "message": "Rule added successfully",
        })
}

func APIFirewallDeleteRuleHandler(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")

        var rule FirewallRule
        if err := json.NewDecoder(r.Body).Decode(&rule); err != nil {
                w.WriteHeader(http.StatusBadRequest)
                json.NewEncoder(w).Encode(map[string]interface{}{
                        "success": false,
                        "message": "Invalid request",
                })
                return
        }

        if rule.Handle == "" {
                w.WriteHeader(http.StatusBadRequest)
                json.NewEncoder(w).Encode(map[string]interface{}{
                        "success": false,
                        "message": "Rule handle is required",
                })
                return
        }

        args := []string{"delete", "rule"}
        args = append(args, strings.Fields(rule.Table)...)
        args = append(args, rule.Chain, "handle", rule.Handle)

        cmd := exec.Command("nft", args...)
        output, err := cmd.CombinedOutput()
        if err != nil {
                w.WriteHeader(http.StatusInternalServerError)
                json.NewEncoder(w).Encode(map[string]interface{}{
                        "success": false,
                        "message": "Failed to delete rule: " + string(output),
                })
                return
        }

        json.NewEncoder(w).Encode(map[string]interface{}{
                "success": true,
                "message": "Rule deleted successfully",
        })
}

func APIFirewallGetConfigHandler(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")

        cmd := exec.Command("nft", "list", "ruleset")
        output, err := cmd.Output()
        if err != nil {
                w.WriteHeader(http.StatusInternalServerError)
                json.NewEncoder(w).Encode(map[string]interface{}{
                        "success": false,
                        "message": "Failed to read nftables config: " + err.Error(),
                })
                return
        }

        json.NewEncoder(w).Encode(map[string]interface{}{
                "success": true,
                "config":  string(output),
        })
}

func APIFirewallSaveConfigHandler(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")

        var request struct {
                Config string `json:"config"`
        }

        if err := json.NewDecoder(r.Body).Decode(&request); err != nil {
                w.WriteHeader(http.StatusBadRequest)
                json.NewEncoder(w).Encode(map[string]interface{}{
                        "success": false,
                        "message": "Invalid request",
                })
                return
        }

        tmpFile, err := ioutil.TempFile("", "nftables-*.conf")
        if err != nil {
                w.WriteHeader(http.StatusInternalServerError)
                json.NewEncoder(w).Encode(map[string]interface{}{
                        "success": false,
                        "message": "Failed to create temp file",
                })
                return
        }
        defer tmpFile.Close()

        if _, err := tmpFile.WriteString(request.Config); err != nil {
                w.WriteHeader(http.StatusInternalServerError)
                json.NewEncoder(w).Encode(map[string]interface{}{
                        "success": false,
                        "message": "Failed to write config",
                })
                return
        }

        cmd := exec.Command("nft", "-f", tmpFile.Name())
        output, err := cmd.CombinedOutput()
        if err != nil {
                w.WriteHeader(http.StatusInternalServerError)
                json.NewEncoder(w).Encode(map[string]interface{}{
                        "success": false,
                        "message": "Failed to apply config: " + string(output),
                })
                return
        }

        json.NewEncoder(w).Encode(map[string]interface{}{
                "success": true,
                "message": "Configuration applied successfully",
        })
}

func isIPForwardingEnabled() bool {
        data, err := ioutil.ReadFile("/proc/sys/net/ipv4/ip_forward")
        if err != nil {
                return false
        }
        return strings.TrimSpace(string(data)) == "1"
}

func setIPForwarding(enable bool) bool {
        value := "0"
        if enable {
                value = "1"
        }

        cmd := exec.Command("sysctl", "-w", "net.ipv4.ip_forward="+value)
        return cmd.Run() == nil
}

func isMasqueradingEnabled() bool {
        cmd := exec.Command("nft", "list", "table", "ip", "amneziawg_nat")
        output, err := cmd.Output()
        if err != nil {
                return false
        }
        return strings.Contains(string(output), "masquerade")
}

func setMasquerading(enable bool, iface string) bool {
        if enable {
                exec.Command("nft", "add", "table", "ip", "amneziawg_nat").Run()
                exec.Command("nft", "add", "chain", "ip", "amneziawg_nat", "postrouting", "{", "type", "nat", "hook", "postrouting", "priority", "100", ";", "}").Run()
                
                exec.Command("nft", "flush", "chain", "ip", "amneziawg_nat", "postrouting").Run()
                
                cmd := exec.Command("nft", "add", "rule", "ip", "amneziawg_nat", "postrouting", "oifname", iface, "masquerade")
                if err := cmd.Run(); err != nil {
                        return false
                }
                return true
        } else {
                exec.Command("nft", "flush", "chain", "ip", "amneziawg_nat", "postrouting").Run()
                return true
        }
}

func setupInterfaceForwarding(sourceIface, destIface string) bool {
        exec.Command("nft", "add", "table", "inet", "amneziawg_filter").Run()
        exec.Command("nft", "add", "chain", "inet", "amneziawg_filter", "forward", "{", "type", "filter", "hook", "forward", "priority", "0", ";", "}").Run()
        
        exec.Command("nft", "flush", "chain", "inet", "amneziawg_filter", "forward").Run()
        
        if err := exec.Command("nft", "add", "rule", "inet", "amneziawg_filter", "forward", "iifname", sourceIface, "oifname", destIface, "accept").Run(); err != nil {
                return false
        }
        if err := exec.Command("nft", "add", "rule", "inet", "amneziawg_filter", "forward", "iifname", destIface, "oifname", sourceIface, "ct", "state", "related,established", "accept").Run(); err != nil {
                return false
        }
        return true
}

func getNftablesRules() []FirewallRule {
        rules := []FirewallRule{}

        cmd := exec.Command("nft", "-a", "list", "ruleset")
        output, err := cmd.Output()
        if err != nil {
                return rules
        }

        lines := strings.Split(string(output), "\n")
        currentTable := ""
        currentChain := ""

        for _, line := range lines {
                line = strings.TrimSpace(line)

                if strings.HasPrefix(line, "table ") {
                        parts := strings.Fields(line)
                        if len(parts) >= 3 {
                                currentTable = parts[1] + " " + parts[2]
                        }
                } else if strings.HasPrefix(line, "chain ") {
                        parts := strings.Fields(line)
                        if len(parts) >= 2 {
                                currentChain = parts[1]
                        }
                } else if strings.Contains(line, "# handle ") && currentTable != "" && currentChain != "" {
                        parts := strings.Split(line, "# handle ")
                        if len(parts) == 2 {
                                rule := strings.TrimSpace(parts[0])
                                handle := strings.TrimSpace(parts[1])

                                if rule != "" && !strings.HasPrefix(rule, "type ") && !strings.HasPrefix(rule, "policy ") {
                                        rules = append(rules, FirewallRule{
                                                Table:  currentTable,
                                                Chain:  currentChain,
                                                Rule:   rule,
                                                Handle: handle,
                                        })
                                }
                        }
                }
        }

        return rules
}
