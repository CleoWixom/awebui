package main

import (
        "log"
        "net/http"

        "amneziawg-manager/handlers"
)

func main() {
        handlers.StartTunnelMonitor()

        http.HandleFunc("/", handlers.IndexHandler)
        http.HandleFunc("/tunnels", handlers.TunnelsHandler)
        http.HandleFunc("/files", func(w http.ResponseWriter, r *http.Request) {
                http.Redirect(w, r, "/tunnels", http.StatusMovedPermanently)
        })
        http.HandleFunc("/network", handlers.NetworkPageHandler)
        http.HandleFunc("/firewall", handlers.FirewallPageHandler)

        http.HandleFunc("/api/tunnels/list", handlers.APIListTunnelsHandler)
        http.HandleFunc("/api/tunnels/details", handlers.APITunnelDetailsHandler)
        http.HandleFunc("/api/tunnels/control", handlers.APITunnelControlHandler)
        http.HandleFunc("/api/tunnels/config/get", handlers.APIGetTunnelConfigHandler)
        http.HandleFunc("/api/tunnels/config/update", handlers.APIUpdateTunnelConfigHandler)

        http.HandleFunc("/api/routes/list", handlers.APIListRoutesHandler)
        http.HandleFunc("/api/routes/add", handlers.APIAddRouteHandler)
        http.HandleFunc("/api/routes/delete", handlers.APIDeleteRouteHandler)
        http.HandleFunc("/api/routes/filters", handlers.APIListFilterFilesHandler)
        http.HandleFunc("/api/routes/upload", handlers.APIUploadFilterFileHandler)
        http.HandleFunc("/api/routes/upload-cidr", handlers.APIUploadCidrFileHandler)
        http.HandleFunc("/api/routes/all", handlers.APIListAllRoutesHandler)

        http.HandleFunc("/api/files/list", handlers.APIListFilesHandler)
        http.HandleFunc("/api/files/get", handlers.APIGetFileHandler)
        http.HandleFunc("/api/files/save", handlers.APISaveFileHandler)
        http.HandleFunc("/api/files/delete", handlers.APIDeleteFileHandler)

        http.HandleFunc("/api/network/interfaces", handlers.APIListNetworkInterfacesHandler)
        http.HandleFunc("/api/network/config", handlers.APIGetNetworkConfigHandler)
        http.HandleFunc("/api/network/dns/config", handlers.APISaveDNSConfigHandler)
        http.HandleFunc("/api/network/dns/status", handlers.APIGetDNSStatusHandler)
        http.HandleFunc("/api/network/dhcp/config", handlers.APISaveDHCPConfigHandler)

        http.HandleFunc("/api/monitor/status", handlers.APIMonitorStatusHandler)
        http.HandleFunc("/api/monitor/control", handlers.APIMonitorControlHandler)
        http.HandleFunc("/api/monitor/tunnel", handlers.APIMonitorTunnelHandler)

        http.HandleFunc("/api/connections/map", handlers.APIConnectionsMapHandler)

        http.HandleFunc("/api/firewall/status", handlers.APIFirewallStatusHandler)
        http.HandleFunc("/api/firewall/forwarding", handlers.APIFirewallToggleForwardingHandler)
        http.HandleFunc("/api/firewall/masquerade", handlers.APIFirewallToggleMasqueradeHandler)
        http.HandleFunc("/api/firewall/rule/add", handlers.APIFirewallAddRuleHandler)
        http.HandleFunc("/api/firewall/rule/delete", handlers.APIFirewallDeleteRuleHandler)
        http.HandleFunc("/api/firewall/config", handlers.APIFirewallGetConfigHandler)
        http.HandleFunc("/api/firewall/config/save", handlers.APIFirewallSaveConfigHandler)

        http.HandleFunc("/api/system/requirements", handlers.APISystemRequirementsHandler)

        http.Handle("/static/", http.StripPrefix("/static/", http.FileServer(http.Dir("static"))))

        log.Println("Server starting on http://0.0.0.0:5000")
        log.Fatal(http.ListenAndServe("0.0.0.0:5000", nil))
}