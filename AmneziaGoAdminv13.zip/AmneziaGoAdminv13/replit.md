# AmneziaWG Manager

## Overview
A web-based management interface for AmneziaWG tunnels built with Go. This application provides complete control over AWG configurations and tunnel operations through a clean, professional administrative dashboard. Its primary purpose is to offer an intuitive web interface for administrators to add, edit, and delete AmneziaWG configurations, monitor tunnel status in real-time, start and stop individual tunnels, and manage configuration files directly. The project aims to simplify AmneziaWG tunnel management and enhance operational efficiency.

## User Preferences
Not specified.

## System Architecture

### Technology Stack
- **Backend**: Go 1.24
- **Frontend**: HTML templates with vanilla JavaScript
- **UI Framework**: Tabler.io 1.4.0 (official admin dashboard framework)
- **Icons**: Tabler SVG Icons
- **No Custom CSS**: Relies solely on official Tabler components and classes.

### Core Features
1.  **Dashboard**: Provides an overview with statistics and quick actions, including a Network Connections Map with jsVectorMap for visualizing connections, DHCP clients, and tunnel activity. Displays system requirements status card showing health of required dependencies (ifconfig, ss/netstat, amneziawg kernel module, awg-quick, awg).
2.  **Tunnel Management**: Allows starting/stopping tunnels, real-time status monitoring, detailed tunnel information (peers, transfer stats, handshake time), and management of configuration files. Features Routing Rules column showing routing mode (Default Gateway/Split Routing) with expandable spoiler displaying active routes for Split Routing mode.
3.  **Network & DNS**: Enables configuration of DNS servers, DHCP client management, and routing table display.
4.  **Firewall**: Offers `nftables`-based firewall management, including IP forwarding, Masquerading (NAT), Internet sharing, display of active `nftables` rules, and a configuration file editor. Uses isolated `amneziawg_filter` and `amneziawg_nat` tables to prevent conflicts. Interface selections use dynamic dropdowns populated from system interfaces.
5.  **File Management**: Provides capabilities to edit and manage `.conf` files within the `/etc/amnezia/amneziawg` directory, including uploading CIDR filter files.

### UI/UX Decisions
The application features a professional admin dashboard using **Tabler.io 1.4.0** components exclusively, including official Tabler SVG icons and color schemes. It adopts a **horizontal navigation layout** and a **responsive, mobile-first design**. The UI incorporates Tabler cards, tables, modals, badges, alerts, and notifications for a consistent and modern look. **Dark theme is enabled by default** via `data-bs-theme="dark"` on the body element, providing a modern, professional appearance that reduces eye strain during extended use. All buttons use **btn-sm** class for compact sizing. Each page includes informational descriptions explaining available options and settings to improve user understanding.

### System Design Choices
-   **Security**: Incorporates path traversal protection, input validation for tunnel names and file paths, and restricts files to `.conf` extensions. Sensitive operations use `exec.Command` with direct arguments to prevent command injection. Routing rules are uniquely commented for precise removal, and `ipset` naming uses SHA256 hashes to prevent kernel limit issues and collisions between tunnels.
-   **Configuration**: The server binds to `0.0.0.0:5000` and uses `/etc/amnezia/amneziawg` as the configuration directory.
-   **Permissions**: Requires appropriate permissions for `awg-quick` and `awg` commands.

## External Dependencies

-   **Go 1.24**: Backend programming language.
-   **Tabler.io 1.4.0**: Frontend UI framework (includes Bootstrap 5).
-   **jsVectorMap 1.5.3**: JavaScript library for interactive world map visualization.
-   **`awg-quick` and `awg` commands**: External utilities for AmneziaWG tunnel control.
-   **`nftables`**: Linux kernel packet filtering framework used for firewall management.
-   **`sysctl`**: Utility for modifying kernel parameters, used for IP forwarding.