
package handlers

import (
        "bufio"
        "context"
        "crypto/rand"
        "crypto/sha256"
        "encoding/hex"
        "encoding/json"
        "fmt"
        "net/http"
        "net/url"
        "os"
        "os/exec"
        "path/filepath"
        "strings"
        "sync"
        "time"

        "amneziawg-manager/logger"
        "amneziawg-manager/models"
        "amneziawg-manager/utils"
)

// ipsetMutex protects concurrent ipset operations (create, destroy, flush)
var ipsetMutex sync.Mutex

func generateRouteID() string {
        b := make([]byte, 8)
        if _, err := rand.Read(b); err != nil {
                logger.Log.Error("failed to generate random route ID", "error", err)
                // Fallback: use timestamp-based ID in case of entropy failure
                return fmt.Sprintf("%016x", time.Now().UnixNano())
        }
        return hex.EncodeToString(b)
}

// sanitizeTunnelNameForIpset converts tunnel name to ipset-safe short hash
// Ipset has 31-char limit; with configurable prefix + hash (6) + "_" (1) + routeID (16)
func sanitizeTunnelNameForIpset(name string) string {
        // Use SHA256 hash and take first 6 characters for uniqueness
        hash := sha256.Sum256([]byte(name))
        return hex.EncodeToString(hash[:])[:6]
}

func setupNftablesTable() error {
        commands := []struct {
                desc string
                args []string
        }{
                {"table", []string{"add", "table", "inet", cfg.Routing.TableName}},
                {"prerouting chain", []string{"add", "chain", "inet", cfg.Routing.TableName, "prerouting", "{", "type", "filter", "hook", "prerouting", "priority", "-100", ";", "}"}},
                {"output chain", []string{"add", "chain", "inet", cfg.Routing.TableName, "output", "{", "type", "filter", "hook", "output", "priority", "-100", ";", "}"}},
        }

        for _, cmdSpec := range commands {
                cmd := exec.Command("nft", cmdSpec.args...)
                if output, err := cmd.CombinedOutput(); err != nil {
                        // Check if error is because table/chain already exists
                        if strings.Contains(string(output), "File exists") || strings.Contains(string(output), "exists") {
                                logger.Log.Debug("nftables object already exists", "desc", cmdSpec.desc)
                                continue
                        }
                        // If nft command itself fails (not found, permission denied, etc), return error
                        logger.Log.Error("nftables setup failed", "desc", cmdSpec.desc, "error", err, "output", string(output))
                        return fmt.Errorf("failed to setup %s: %v", cmdSpec.desc, err)
                }
        }

        return nil
}

func createIpset(tunnelName string, routeID string, filterFile string) error {
        // Protect against concurrent ipset operations
        ipsetMutex.Lock()
        defer ipsetMutex.Unlock()

        // Namespace ipset by tunnel name hash to avoid collisions (ipset 31-char limit)
        // Format: prefix + hash6 + "_" + routeID
        ipsetName := cfg.Routing.IpsetPrefix + sanitizeTunnelNameForIpset(tunnelName) + "_" + routeID

        // Create ipset
        cmd := exec.Command("ipset", "create", ipsetName, "hash:net", "-exist")
        if err := cmd.Run(); err != nil {
                return fmt.Errorf("failed to create ipset: %v", err)
        }

        // Flush ipset
        cmd = exec.Command("ipset", "flush", ipsetName)
        if err := cmd.Run(); err != nil {
                return fmt.Errorf("failed to flush ipset: %v", err)
        }

        // Read filter file and add entries
        file, err := os.Open(filterFile)
        if err != nil {
                return fmt.Errorf("failed to open filter file: %v", err)
        }
        defer file.Close()

        scanner := bufio.NewScanner(file)
        for scanner.Scan() {
                line := strings.TrimSpace(scanner.Text())
                if line == "" || strings.HasPrefix(line, "#") {
                        continue
                }

                cmd = exec.Command("ipset", "add", ipsetName, line, "-exist")
                if err := cmd.Run(); err != nil {
                        logger.Log.Warn("failed to add IP to ipset", 
                                "ipset", ipsetName, "ip", line, "error", err)
                }
        }

        return nil
}

func destroyIpset(tunnelName string, routeID string) error {
        // Protect against concurrent ipset operations
        ipsetMutex.Lock()
        defer ipsetMutex.Unlock()

        // Namespace ipset by tunnel name hash to match creation (ipset 31-char limit)
        // Format: prefix + hash6 + "_" + routeID
        ipsetName := cfg.Routing.IpsetPrefix + sanitizeTunnelNameForIpset(tunnelName) + "_" + routeID
        cmd := exec.Command("ipset", "destroy", ipsetName)
        if err := cmd.Run(); err != nil {
                logger.Log.Debug("failed to destroy ipset (may not exist)", 
                        "ipset", ipsetName, "error", err)
                return err
        }
        return nil
}

func applyRoutingRules(tunnel *models.Tunnel) error {
        if tunnel.Mode != models.ModeNonGateway {
                return nil
        }

        // Setup nftables if not exists
        if err := setupNftablesTable(); err != nil {
                return fmt.Errorf("failed to setup nftables: %v", err)
        }

        for _, route := range tunnel.Routes {
                if !route.Enabled {
                        continue
                }

                // Skip routes without filter file - nothing to route
                if route.FilterFile == "" {
                        continue
                }

                // Namespace ipset by tunnel name hash to avoid collisions (ipset 31-char limit)
                // Format: prefix + hash6 + "_" + routeID
                ipsetName := cfg.Routing.IpsetPrefix + sanitizeTunnelNameForIpset(tunnel.Name) + "_" + route.ID

                // Create ipset from filter file
                if err := createIpset(tunnel.Name, route.ID, route.FilterFile); err != nil {
                        return err
                }

                // Create unique comment identifier: tunnel_name:route_id (safe characters only)
                commentID := fmt.Sprintf("%s:%s", tunnel.Name, route.ID)

                // Build nft command with proper escaping - use direct command args, not shell
                var nftArgs []string
                switch route.Action {
                case models.ActionDirect:
                        nftArgs = []string{"add", "rule", "inet", cfg.Routing.TableName, "prerouting", 
                                "ip", "saddr", "@" + ipsetName, "mark", "set", "0x1", "counter", "comment", commentID}
                case models.ActionTunnel:
                        if route.TargetTunnel != "" {
                                mark := getTunnelMark(route.TargetTunnel)
                                nftArgs = []string{"add", "rule", "inet", cfg.Routing.TableName, "prerouting",
                                        "ip", "saddr", "@" + ipsetName, "mark", "set", mark, "counter", "comment", commentID}
                        }
                case models.ActionBlock:
                        nftArgs = []string{"add", "rule", "inet", cfg.Routing.TableName, "prerouting",
                                "ip", "saddr", "@" + ipsetName, "drop", "counter", "comment", commentID}
                }

                if len(nftArgs) > 0 {
                        cmd := exec.Command("nft", nftArgs...)
                        if err := cmd.Run(); err != nil {
                                return fmt.Errorf("failed to apply nftables rule: %v", err)
                        }
                }
        }

        return nil
}

func clearRoutingRules(tunnel *models.Tunnel) error {
        // Remove nftables rules for this tunnel's routes only
        for _, route := range tunnel.Routes {
                // Create the same comment ID we used when adding the rule
                commentID := fmt.Sprintf("%s:%s", tunnel.Name, route.ID)
                
                // Get list of rules with handles from prerouting chain
                cmd := exec.Command("nft", "-a", "list", "chain", "inet", cfg.Routing.TableName, "prerouting")
                output, err := cmd.Output()
                if err == nil {
                        // Parse output to find rules with our comment
                        lines := strings.Split(string(output), "\n")
                        for _, line := range lines {
                                // Check if line contains our comment ID
                                if strings.Contains(line, "comment \""+commentID+"\"") && strings.Contains(line, "# handle ") {
                                        // Extract handle number
                                        parts := strings.Split(line, "# handle ")
                                        if len(parts) == 2 {
                                                handle := strings.TrimSpace(parts[1])
                                                // Delete rule by handle
                                                delCmd := exec.Command("nft", "delete", "rule", "inet", cfg.Routing.TableName, "prerouting", "handle", handle)
                                                if err := delCmd.Run(); err != nil {
                                                        logger.Log.Debug("failed to delete routing rule", "handle", handle, "error", err)
                                                }
                                        }
                                }
                        }
                }
                
                // Destroy ipset for this route (namespaced by tunnel name)
                destroyIpset(tunnel.Name, route.ID)
        }

        return nil
}

func getTunnelMark(tunnelName string) string {
        hash := 0
        for _, c := range tunnelName {
                hash = hash*31 + int(c)
        }
        return fmt.Sprintf("0x%x", (hash&0xFFFF)+cfg.Routing.MarkBase)
}

func checkDefaultGatewayConflict(tunnelName string) (bool, error) {
        tunnels, err := listTunnels()
        if err != nil {
                return false, err
        }

        for _, t := range tunnels {
                if t.Name == tunnelName {
                        continue
                }
                if t.Status == "up" {
                        config, err := loadTunnelConfig(t.Name)
                        if err != nil {
                                logger.Log.Warn("failed to load tunnel config for conflict check", "tunnel", t.Name, "error", err)
                                continue
                        }
                        if config != nil && config.Mode == models.ModeDefaultGateway {
                                return true, nil
                        }
                }
        }

        return false, nil
}

func loadTunnelConfig(name string) (*models.Tunnel, error) {
        filePath, err := validateFilePath(name + ".conf")
        if err != nil {
                return nil, err
        }

        metaPath := strings.TrimSuffix(filePath, ".conf") + ".meta.json"
        data, err := os.ReadFile(metaPath)
        if err != nil {
                return nil, err
        }

        var tunnel models.Tunnel
        if err := json.Unmarshal(data, &tunnel); err != nil {
                return nil, err
        }

        return &tunnel, nil
}

func saveTunnelConfig(tunnel *models.Tunnel) error {
        filePath, err := validateFilePath(tunnel.Name + ".conf")
        if err != nil {
                return err
        }

        metaPath := strings.TrimSuffix(filePath, ".conf") + ".meta.json"
        data, err := json.MarshalIndent(tunnel, "", "  ")
        if err != nil {
                return err
        }

        return utils.AtomicWriteFile(metaPath, data, 0600)
}

func APIGetTunnelConfigHandler(w http.ResponseWriter, r *http.Request) {
        name := r.URL.Query().Get("name")

        if err := validateTunnelName(name); err != nil {
                http.Error(w, err.Error(), http.StatusBadRequest)
                return
        }

        config, err := loadTunnelConfig(name)
        if err != nil {
                config = &models.Tunnel{
                        Name:   name,
                        Mode:   models.ModeNonGateway,
                        Routes: []models.Route{},
                }
        }

        w.Header().Set("Content-Type", "application/json")
        respondJSON(w, config)
}

func APIUpdateTunnelConfigHandler(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")
        
        var tunnel models.Tunnel
        if err := json.NewDecoder(r.Body).Decode(&tunnel); err != nil {
                respondError(w, http.StatusBadRequest, "Invalid request: "+err.Error())
                return
        }

        if err := validateTunnelName(tunnel.Name); err != nil {
                respondError(w, http.StatusBadRequest, err.Error())
                return
        }

        // Check for default gateway conflict
        if tunnel.Mode == models.ModeDefaultGateway {
                conflict, err := checkDefaultGatewayConflict(tunnel.Name)
                if err != nil {
                        respondError(w, http.StatusInternalServerError, err.Error())
                        return
                }
                if conflict {
                        respondError(w, http.StatusConflict, "Another tunnel is already running as default gateway")
                        return
                }
        }

        if err := saveTunnelConfig(&tunnel); err != nil {
                respondError(w, http.StatusInternalServerError, "Failed to save configuration: "+err.Error())
                return
        }

        w.Header().Set("Content-Type", "application/json")
        respondSuccess(w, "Configuration saved successfully")
}

func APIListRoutesHandler(w http.ResponseWriter, r *http.Request) {
        tunnelName := r.URL.Query().Get("tunnel")
        
        if err := validateTunnelName(tunnelName); err != nil {
                http.Error(w, err.Error(), http.StatusBadRequest)
                return
        }

        config, err := loadTunnelConfig(tunnelName)
        if err != nil {
                w.Header().Set("Content-Type", "application/json")
                respondJSON(w, []models.Route{})
                return
        }

        w.Header().Set("Content-Type", "application/json")
        respondJSON(w, config.Routes)
}

func APIAddRouteHandler(w http.ResponseWriter, r *http.Request) {
        var req struct {
                TunnelName string       `json:"tunnel_name"`
                Route      models.Route `json:"route"`
        }

        if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
                http.Error(w, err.Error(), http.StatusBadRequest)
                return
        }

        if err := validateTunnelName(req.TunnelName); err != nil {
                http.Error(w, err.Error(), http.StatusBadRequest)
                return
        }

        config, err := loadTunnelConfig(req.TunnelName)
        if err != nil {
                http.Error(w, "Tunnel configuration not found", http.StatusNotFound)
                return
        }

        if config.Mode != models.ModeNonGateway {
                http.Error(w, "Routing rules only available for non-gateway tunnels", http.StatusBadRequest)
                return
        }

        req.Route.ID = generateRouteID()
        config.Routes = append(config.Routes, req.Route)

        if err := saveTunnelConfig(config); err != nil {
                http.Error(w, "Failed to save route", http.StatusInternalServerError)
                return
        }

        w.Header().Set("Content-Type", "application/json")
        respondJSON(w, map[string]interface{}{
                "success": true,
                "message": "Route added successfully",
                "route":   req.Route,
        })
}

func APIDeleteRouteHandler(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")
        
        var req struct {
                TunnelName string `json:"tunnel_name"`
                RouteID    string `json:"route_id"`
        }

        if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
                respondError(w, http.StatusBadRequest, "Invalid request: "+err.Error())
                return
        }

        config, err := loadTunnelConfig(req.TunnelName)
        if err != nil {
                respondError(w, http.StatusNotFound, "Tunnel configuration not found")
                return
        }

        newRoutes := []models.Route{}
        for _, route := range config.Routes {
                if route.ID != req.RouteID {
                        newRoutes = append(newRoutes, route)
                } else {
                        // Destroy ipset for this route (namespaced by tunnel name)
                        destroyIpset(req.TunnelName, route.ID)
                }
        }

        config.Routes = newRoutes

        if err := saveTunnelConfig(config); err != nil {
                respondError(w, http.StatusInternalServerError, "Failed to delete route: "+err.Error())
                return
        }

        w.Header().Set("Content-Type", "application/json")
        respondSuccess(w, "Route deleted successfully")
}

func APIListFilterFilesHandler(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")
        
        filterFiles := []map[string]interface{}{}
        
        // List files from RoutesDir
        if err := os.MkdirAll(cfg.Paths.RoutesDir, 0755); err == nil {
                if files, err := os.ReadDir(cfg.Paths.RoutesDir); err == nil {
                        for _, file := range files {
                                if !file.IsDir() && strings.HasSuffix(file.Name(), ".txt") {
                                        info, err := file.Info()
                                        if err != nil {
                                                logger.Log.Warn("failed to get file info", "file", file.Name(), "error", err)
                                                continue
                                        }
                                        filterFiles = append(filterFiles, map[string]interface{}{
                                                "name": file.Name(),
                                                "path": filepath.Join(cfg.Paths.RoutesDir, file.Name()),
                                                "size": info.Size(),
                                                "type": "route",
                                        })
                                }
                        }
                }
        }
        
        // List files from CidrDbsDir
        if err := os.MkdirAll(cfg.Paths.CidrDbsDir, 0755); err == nil {
                if files, err := os.ReadDir(cfg.Paths.CidrDbsDir); err == nil {
                        for _, file := range files {
                                if !file.IsDir() && strings.HasSuffix(file.Name(), ".pt") {
                                        info, err := file.Info()
                                        if err != nil {
                                                logger.Log.Warn("failed to get file info", "file", file.Name(), "error", err)
                                                continue
                                        }
                                        filterFiles = append(filterFiles, map[string]interface{}{
                                                "name": file.Name(),
                                                "path": filepath.Join(cfg.Paths.CidrDbsDir, file.Name()),
                                                "size": info.Size(),
                                                "type": "cidr",
                                        })
                                }
                        }
                }
        }

        respondJSON(w, filterFiles)
}

func APIUploadFilterFileHandler(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")
        
        if err := r.ParseMultipartForm(10 << 20); err != nil {
                respondError(w, http.StatusBadRequest, "Invalid request: "+err.Error())
                return
        }

        file, header, err := r.FormFile("file")
        if err != nil {
                respondError(w, http.StatusBadRequest, "No file provided: "+err.Error())
                return
        }
        defer file.Close()

        if !strings.HasSuffix(header.Filename, ".txt") {
                respondError(w, http.StatusBadRequest, "Only .txt files are allowed")
                return
        }

        if err := os.MkdirAll(cfg.Paths.RoutesDir, 0755); err != nil {
                respondError(w, http.StatusInternalServerError, "Failed to create routes directory")
                return
        }

        filename := filepath.Base(header.Filename)
        filePath := filepath.Join(cfg.Paths.RoutesDir, filename)

        dst, err := os.Create(filePath)
        if err != nil {
                respondError(w, http.StatusInternalServerError, "Failed to save file: "+err.Error())
                return
        }
        defer dst.Close()

        if _, err := dst.ReadFrom(file); err != nil {
                respondError(w, http.StatusInternalServerError, "Failed to write file: "+err.Error())
                return
        }

        w.Header().Set("Content-Type", "application/json")
        respondJSON(w, map[string]interface{}{
                "success": true,
                "message": "Filter file uploaded successfully",
                "path":    filePath,
        })
}

func APIUploadCidrFileHandler(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")
        
        if err := r.ParseMultipartForm(10 << 20); err != nil {
                respondError(w, http.StatusBadRequest, "Invalid request: "+err.Error())
                return
        }

        // Get company name from form
        companyName := r.FormValue("company_name")
        if companyName == "" {
                respondError(w, http.StatusBadRequest, "Company name is required")
                return
        }

        // Sanitize company name
        companyName = strings.TrimSpace(companyName)
        companyName = strings.ToLower(companyName)
        companyName = strings.ReplaceAll(companyName, " ", "_")
        // Remove any special characters
        var sanitized strings.Builder
        for _, r := range companyName {
                if (r >= 'a' && r <= 'z') || (r >= '0' && r <= '9') || r == '_' || r == '-' {
                        sanitized.WriteRune(r)
                }
        }
        companyName = sanitized.String()
        
        if companyName == "" {
                respondError(w, http.StatusBadRequest, "Invalid company name")
                return
        }

        file, _, err := r.FormFile("file")
        if err != nil {
                respondError(w, http.StatusBadRequest, "No file provided: "+err.Error())
                return
        }
        defer file.Close()

        if err := os.MkdirAll(cfg.Paths.CidrDbsDir, 0755); err != nil {
                respondError(w, http.StatusInternalServerError, "Failed to create cidrdbs directory")
                return
        }

        // Generate filename: [company_name]_cidr.pt
        filename := fmt.Sprintf("%s_cidr.pt", companyName)
        filePath := filepath.Join(cfg.Paths.CidrDbsDir, filename)

        dst, err := os.Create(filePath)
        if err != nil {
                respondError(w, http.StatusInternalServerError, "Failed to save file: "+err.Error())
                return
        }
        defer dst.Close()

        if _, err := dst.ReadFrom(file); err != nil {
                respondError(w, http.StatusInternalServerError, "Failed to write file: "+err.Error())
                return
        }

        respondJSON(w, map[string]interface{}{
                "success": true,
                "message": "CIDR file uploaded successfully",
                "path":    filePath,
                "filename": filename,
        })
}

func APIListAllRoutesHandler(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")
        
        tunnels, err := listTunnels()
        if err != nil {
                w.WriteHeader(http.StatusInternalServerError)
                respondJSON(w, []interface{}{})
                return
        }

        allRoutes := []map[string]interface{}{}
        
        for _, tunnel := range tunnels {
                config, err := loadTunnelConfig(tunnel.Name)
                if err != nil || config == nil {
                        continue
                }
                
                if config.Mode != models.ModeNonGateway {
                        continue
                }
                
                for _, route := range config.Routes {
                        allRoutes = append(allRoutes, map[string]interface{}{
                                "tunnel_name":   tunnel.Name,
                                "id":           route.ID,
                                "name":         route.Name,
                                "filter_file":  route.FilterFile,
                                "action":       route.Action,
                                "target_tunnel": route.TargetTunnel,
                                "priority":     route.Priority,
                                "enabled":      route.Enabled,
                        })
                }
        }

        respondJSON(w, allRoutes)
}

// APIFetchBGPViewHandler fetches CIDR prefixes for a company from bgpview.io API
func APIFetchBGPViewHandler(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")
        
        var req struct {
                Company string `json:"company"`
        }
        
        if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
                respondError(w, http.StatusBadRequest, "Invalid request: "+err.Error())
                return
        }
        
        if req.Company == "" {
                respondError(w, http.StatusBadRequest, "Company name is required")
                return
        }
        
        company := strings.TrimSpace(req.Company)
        
        // Create context with timeout for API request
        ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
        defer cancel()
        
        // Build API URL with properly encoded query parameter
        apiURL := fmt.Sprintf("https://api.bgpview.io/search?query_term=%s", url.QueryEscape(company))
        
        // Create HTTP request with context
        httpReq, err := http.NewRequestWithContext(ctx, "GET", apiURL, nil)
        if err != nil {
                logger.Log.Error("failed to create bgpview request", "error", err)
                respondError(w, http.StatusInternalServerError, "Failed to create request")
                return
        }
        
        // Make the request
        client := &http.Client{Timeout: 15 * time.Second}
        resp, err := client.Do(httpReq)
        if err != nil {
                logger.Log.Error("bgpview api request failed", "error", err, "company", company)
                respondError(w, http.StatusServiceUnavailable, "Failed to fetch data from BGPView API: "+err.Error())
                return
        }
        defer resp.Body.Close()
        
        if resp.StatusCode != http.StatusOK {
                logger.Log.Error("bgpview api returned non-200", "status", resp.StatusCode, "company", company)
                respondError(w, http.StatusServiceUnavailable, fmt.Sprintf("BGPView API returned status %d", resp.StatusCode))
                return
        }
        
        // Parse BGPView response
        var bgpResp struct {
                Status        string `json:"status"`
                StatusMessage string `json:"status_message"`
                Data          struct {
                        IPv4Prefixes []struct {
                                Prefix      string `json:"prefix"`
                                IP          string `json:"ip"`
                                CIDR        int    `json:"cidr"`
                                Name        string `json:"name"`
                                Description string `json:"description"`
                                CountryCode string `json:"country_code"`
                        } `json:"ipv4_prefixes"`
                } `json:"data"`
        }
        
        if err := json.NewDecoder(resp.Body).Decode(&bgpResp); err != nil {
                logger.Log.Error("failed to parse bgpview response", "error", err)
                respondError(w, http.StatusInternalServerError, "Failed to parse BGPView response")
                return
        }
        
        if bgpResp.Status != "ok" {
                logger.Log.Warn("bgpview api error", "status", bgpResp.Status, "message", bgpResp.StatusMessage)
                respondError(w, http.StatusBadRequest, "BGPView API error: "+bgpResp.StatusMessage)
                return
        }
        
        // Extract prefixes
        prefixes := []string{}
        for _, prefix := range bgpResp.Data.IPv4Prefixes {
                if prefix.Prefix != "" {
                        prefixes = append(prefixes, prefix.Prefix)
                }
        }
        
        logger.Log.Info("fetched bgpview prefixes", "company", company, "count", len(prefixes))
        
        respondJSON(w, map[string]interface{}{
                "success":  true,
                "company":  company,
                "prefixes": prefixes,
                "count":    len(prefixes),
        })
}

// APISaveBGPViewCIDRHandler saves BGPView CIDR prefixes to a file
func APISaveBGPViewCIDRHandler(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")
        
        var req struct {
                Company  string   `json:"company"`
                Prefixes []string `json:"prefixes"`
        }
        
        if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
                respondError(w, http.StatusBadRequest, "Invalid request: "+err.Error())
                return
        }
        
        if req.Company == "" {
                respondError(w, http.StatusBadRequest, "Company name is required")
                return
        }
        
        if len(req.Prefixes) == 0 {
                respondError(w, http.StatusBadRequest, "No prefixes to save")
                return
        }
        
        // Sanitize company name (same as in APIUploadCidrFileHandler)
        companyName := strings.TrimSpace(req.Company)
        companyName = strings.ToLower(companyName)
        companyName = strings.ReplaceAll(companyName, " ", "_")
        
        // Remove any special characters, only allow alphanumeric, underscore, hyphen
        var sanitized strings.Builder
        for _, r := range companyName {
                if (r >= 'a' && r <= 'z') || (r >= '0' && r <= '9') || r == '_' || r == '-' {
                        sanitized.WriteRune(r)
                }
        }
        companyName = sanitized.String()
        
        if companyName == "" {
                respondError(w, http.StatusBadRequest, "Invalid company name")
                return
        }
        
        // Create cidrdbs directory
        if err := os.MkdirAll(cfg.Paths.CidrDbsDir, 0755); err != nil {
                logger.Log.Error("failed to create cidrdbs directory", "error", err)
                respondError(w, http.StatusInternalServerError, "Failed to create directory")
                return
        }
        
        // Generate safe filename with .pt extension
        filename := fmt.Sprintf("%s_cidr.pt", companyName)
        
        // Ensure filename is clean and prevent directory traversal
        if filepath.Base(filename) != filename || strings.Contains(filename, "..") {
                logger.Log.Error("invalid filename detected", "filename", filename)
                respondError(w, http.StatusBadRequest, "Invalid filename")
                return
        }
        
        filePath := filepath.Join(cfg.Paths.CidrDbsDir, filename)
        
        // Verify final path is within intended directory
        absPath, err := filepath.Abs(filePath)
        if err != nil {
                logger.Log.Error("failed to resolve absolute path", "error", err)
                respondError(w, http.StatusInternalServerError, "Path error")
                return
        }
        
        absCidrDbsDir, err := filepath.Abs(cfg.Paths.CidrDbsDir)
        if err != nil {
                logger.Log.Error("failed to resolve cidrdbs directory", "error", err)
                respondError(w, http.StatusInternalServerError, "Path error")
                return
        }
        
        if !strings.HasPrefix(absPath, absCidrDbsDir+string(filepath.Separator)) {
                logger.Log.Error("directory traversal attempt detected", "path", absPath, "expected_dir", absCidrDbsDir)
                respondError(w, http.StatusBadRequest, "Invalid file path")
                return
        }
        
        // Write prefixes to file using atomic write
        content := strings.Join(req.Prefixes, "\n") + "\n"
        if err := utils.AtomicWriteFile(filePath, []byte(content), 0644); err != nil {
                logger.Log.Error("failed to save cidr file", "error", err, "path", filePath)
                respondError(w, http.StatusInternalServerError, "Failed to save CIDR file")
                return
        }
        
        logger.Log.Info("saved bgpview cidr file", "company", req.Company, "filename", filename, "count", len(req.Prefixes))
        
        respondJSON(w, map[string]interface{}{
                "success":  true,
                "message":  "CIDR file saved successfully",
                "filename": filename,
                "path":     filePath,
                "count":    len(req.Prefixes),
        })
}
