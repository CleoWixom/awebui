# AmneziaWG Manager

## Overview
A web-based management interface for AmneziaWG tunnels built with Go. This application provides complete control over AWG configurations and tunnel operations through a clean, professional administrative dashboard. Its primary purpose is to offer an intuitive web interface for administrators to add, edit, and delete AmneziaWG configurations, monitor tunnel status in real-time, start and stop individual tunnels, and manage configuration files directly. The project aims to simplify AmneziaWG tunnel management and enhance operational efficiency.

## Recent Changes (October 2025)

### Fault-Tolerant Tunnel Monitoring System (October 26, 2025)
Implemented comprehensive fault-tolerant monitoring with automatic failover:
- **Tunnel Health Checks**: Periodic ping through tunnel interface to verify actual connectivity
- **Smart Restart Logic**: Connection → Health Check → Apply Routing Rules (only on success)
- **Automatic Failover**: After max restart attempts, switches to direct routing to preserve internet
- **Recovery Mechanism**: Periodic attempts to restore tunnel from fallback mode
- **Configurable Parameters**:
  - `MONITOR_TUNNEL_PING_HOST`: Host to ping through tunnel (default: 1.1.1.1)
  - `MONITOR_TUNNEL_PING_TIMEOUT`: Timeout for tunnel ping (default: 3s)
  - `MONITOR_TUNNEL_PING_INTERVAL`: How often to ping through tunnel (default: 10s)
  - `MONITOR_MAX_RESTART_ATTEMPTS`: Max restarts before fallback (default: 5)
  - `MONITOR_FALLBACK_TIMEOUT`: How long to wait before recovery attempt (default: 5m)
  - `MONITOR_RECOVERY_CHECK_INTERVAL`: Interval for recovery checks (default: 30s)
- **Enhanced Monitoring State**: Tracks tunnel health, fallback mode, ping statistics, routing state

### EN/RU Localization System (October 25, 2025)
Implemented comprehensive bilingual interface with automatic language detection:
- **Client-Side i18n**: JavaScript-based localization system (static/js/i18n.js) with complete EN/RU translations
- **Automatic Detection**: Browser language detection via navigator.language API
- **Language Switcher**: Dropdown menu in navigation bar with globe icon for EN/RU selection
- **Persistent Preference**: User language choice saved to localStorage
- **Comprehensive Coverage**: All UI elements, buttons, labels, and messages translated
- **Data Attributes**: HTML elements marked with data-i18n for dynamic translation
- **Live Switching**: Instant language switching without page reload

### System Information Dashboard (October 25, 2025)
Added comprehensive system monitoring to the Dashboard:
- **Real-time System Metrics**: Displays uptime, hostname, kernel version, and distribution name
- **Resource Monitoring**: Shows CPU usage (with temperature), RAM usage, storage usage, and network statistics
- **Visual Indicators**: Progress bars for CPU, RAM, and storage with color-coded warnings (green/yellow/red)
- **Live Data**: All metrics are fetched from `/proc` and system utilities, no hardcoded values
- **Refresh Capability**: Manual refresh button to update system information on demand
- **Responsive Layout**: Clean 8-column grid layout with icons and proper formatting

### Production-Ready Code Audit
Complete refactoring to production standards:
- **Configuration Management**: Implemented centralized configuration system with environment variable support (see `.env.example`)
- **Structured Logging**: Replaced all debug print statements with structured JSON logging using Go's `slog` package
- **No Mock Data**: Removed all hardcoded demo data, coordinates, and placeholders - all data is now dynamically retrieved
- **Dynamic Interface Detection**: Network interfaces are now auto-detected instead of hardcoded
- **GeoIP Integration**: Tunnel and connection locations are determined via real-time GeoIP lookups
- **Configurable Parameters**: All magic numbers and constants moved to configuration (timeouts, thresholds, intervals)
- **Error Handling**: Added comprehensive error logging and handling throughout the application

## User Preferences
Not specified.

## System Architecture

### Technology Stack
- **Backend**: Go 1.24
- **Frontend**: HTML templates with vanilla JavaScript
- **UI Framework**: Tabler.io 1.4.0 (official admin dashboard framework)
- **Icons**: Tabler SVG Icons
- **No Custom CSS**: Relies solely on official Tabler components and classes.

### Core Features
1.  **Dashboard**: Provides an overview with statistics and quick actions, including:
    - **System Information**: Real-time monitoring of uptime, hostname, kernel, distribution, CPU (usage & temperature), RAM, storage, and network statistics
    - **Network Connections Map**: jsVectorMap visualization of connections, DHCP clients, and tunnel activity
    - **System Requirements**: Status card showing health of required dependencies (ifconfig, ss/netstat, amneziawg kernel module, awg-quick, awg)
2.  **Tunnel Management**: Allows starting/stopping tunnels, real-time status monitoring, detailed tunnel information (peers, transfer stats, handshake time), and management of configuration files. Features Routing Rules column showing routing mode (Default Gateway/Split Routing) with expandable spoiler displaying active routes for Split Routing mode.
3.  **Network & DNS**: Enables configuration of DNS servers, DHCP client management, and routing table display.
4.  **Firewall**: Offers `nftables`-based firewall management, including IP forwarding, Masquerading (NAT), Internet sharing, display of active `nftables` rules, and a configuration file editor. Uses isolated `amneziawg_filter` and `amneziawg_nat` tables to prevent conflicts. Interface selections use dynamic dropdowns populated from system interfaces.
5.  **File Management**: Provides capabilities to edit and manage `.conf` files within the `/etc/amnezia/amneziawg` directory, including uploading CIDR filter files.

### UI/UX Decisions
The application features a professional admin dashboard using **Tabler.io 1.4.0** components exclusively, including official Tabler SVG icons and color schemes. It adopts a **horizontal navigation layout** and a **responsive, mobile-first design**. The UI incorporates Tabler cards, tables, modals, badges, alerts, and notifications for a consistent and modern look. **Dark theme is enabled by default** via `data-bs-theme="dark"` on the body element, providing a modern, professional appearance that reduces eye strain during extended use. All buttons use **btn-sm** class for compact sizing. Each page includes informational descriptions explaining available options and settings to improve user understanding.

### System Design Choices
-   **Security**: Incorporates path traversal protection, input validation for tunnel names and file paths, and restricts files to `.conf` extensions. Sensitive operations use `exec.Command` with direct arguments to prevent command injection. Routing rules are uniquely commented for precise removal, and `ipset` naming uses SHA256 hashes to prevent kernel limit issues and collisions between tunnels.
-   **Configuration**: 
    - Fully configurable via environment variables (see `.env.example`)
    - Default server binding: `0.0.0.0:5000` (configurable via `SERVER_HOST` and `SERVER_PORT`)
    - Default config directory: `/etc/amnezia/amneziawg` (configurable via `CONFIG_DIR`)
    - All timeouts, thresholds, and intervals are configurable
-   **Logging**: Structured JSON logging with configurable log levels (`LOG_LEVEL`: DEBUG, INFO, WARN, ERROR)
-   **Permissions**: Requires appropriate permissions for `awg-quick` and `awg` commands.
-   **Production Ready**: No debug output, no hardcoded values, no mock data - production-grade code throughout.

## Deployment & Installation

The project includes production-ready installation tools:

### Installation Files
- **Makefile**: Automated build, installation, and service management
  - `make build` - Build binary
  - `make install` - Install to system (`/usr/local/bin`, `/usr/local/share`)
  - `make enable` - Enable systemd autostart
  - `make start/stop/restart` - Service control
  - `make status` - View service status
  - `make uninstall` - Complete removal
  
- **amneziawg-manager.service**: Systemd unit file for system service
  - Automatic start on boot
  - Automatic restart on failure
  - Comprehensive environment configuration
  - Structured logging to journald
  
- **INSTALL.md**: Detailed installation and configuration guide
  - System requirements
  - Step-by-step installation
  - Configuration options
  - Troubleshooting guide
  - Security recommendations

### Installation Locations
- Binary: `/usr/local/bin/awg-manager`
- Web assets: `/usr/local/share/amneziawg-manager/`
- Configuration: `/etc/amnezia/amneziawg/`
- Routes: `/etc/amnezia/routes/`
- CIDR databases: `/var/lib/amneziawg/cidrdbs/`
- Service file: `/etc/systemd/system/amneziawg-manager.service`

## External Dependencies

-   **Go 1.24**: Backend programming language.
-   **Tabler.io 1.4.0**: Frontend UI framework (includes Bootstrap 5).
-   **jsVectorMap 1.5.3**: JavaScript library for interactive world map visualization.
-   **`awg-quick` and `awg` commands**: External utilities for AmneziaWG tunnel control.
-   **`nftables`**: Linux kernel packet filtering framework used for firewall management.
-   **`sysctl`**: Utility for modifying kernel parameters, used for IP forwarding.
-   **`ipset`**: IP sets for efficient routing rules management.