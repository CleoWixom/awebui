package main

import (
        "fmt"
        "log"
        "net/http"
        "os/exec"
        "strings"

        "amneziawg-manager/config"
        "amneziawg-manager/handlers"
        "amneziawg-manager/logger"
        "amneziawg-manager/renderer"
)

func main() {
        cfg := config.Load()
        renderer.Init(cfg)
        handlers.Init(cfg)
        
        printSystemRequirements()
        
        // Restore previously running tunnels
        handlers.RestoreTunnelStates()
        
        handlers.StartTunnelMonitor()

        http.HandleFunc("/", handlers.IndexHandler)
        http.HandleFunc("/tunnels", handlers.TunnelsHandler)
        http.HandleFunc("/network", handlers.NetworkPageHandler)
        http.HandleFunc("/firewall", handlers.FirewallPageHandler)

        http.HandleFunc("/api/tunnels/list", handlers.APIListTunnelsHandler)
        http.HandleFunc("/api/tunnels/details", handlers.APITunnelDetailsHandler)
        http.HandleFunc("/api/tunnels/control", handlers.APITunnelControlHandler)
        http.HandleFunc("/api/tunnels/config/get", handlers.APIGetTunnelConfigHandler)
        http.HandleFunc("/api/tunnels/config/update", handlers.APIUpdateTunnelConfigHandler)

        http.HandleFunc("/api/routes/list", handlers.APIListRoutesHandler)
        http.HandleFunc("/api/routes/add", handlers.APIAddRouteHandler)
        http.HandleFunc("/api/routes/delete", handlers.APIDeleteRouteHandler)
        http.HandleFunc("/api/routes/filters", handlers.APIListFilterFilesHandler)
        http.HandleFunc("/api/routes/upload", handlers.APIUploadFilterFileHandler)
        http.HandleFunc("/api/routes/upload-cidr", handlers.APIUploadCidrFileHandler)
        http.HandleFunc("/api/routes/all", handlers.APIListAllRoutesHandler)
        http.HandleFunc("/api/routes/bgpview/fetch", handlers.APIFetchBGPViewHandler)
        http.HandleFunc("/api/routes/bgpview/save", handlers.APISaveBGPViewCIDRHandler)

        http.HandleFunc("/api/files/list", handlers.APIListFilesHandler)
        http.HandleFunc("/api/files/get", handlers.APIGetFileHandler)
        http.HandleFunc("/api/files/save", handlers.APISaveFileHandler)
        http.HandleFunc("/api/files/delete", handlers.APIDeleteFileHandler)

        http.HandleFunc("/api/network/interfaces", handlers.APIListNetworkInterfacesHandler)
        http.HandleFunc("/api/network/config", handlers.APIGetNetworkConfigHandler)
        http.HandleFunc("/api/network/dns/config", handlers.APISaveDNSConfigHandler)
        http.HandleFunc("/api/network/dns/status", handlers.APIGetDNSStatusHandler)
        http.HandleFunc("/api/network/dhcp/config", handlers.APISaveDHCPConfigHandler)

        http.HandleFunc("/api/monitor/status", handlers.APIMonitorStatusHandler)
        http.HandleFunc("/api/monitor/control", handlers.APIMonitorControlHandler)
        http.HandleFunc("/api/monitor/tunnel", handlers.APIMonitorTunnelHandler)

        http.HandleFunc("/api/connections/map", handlers.APIConnectionsMapHandler)

        http.HandleFunc("/api/firewall/status", handlers.APIFirewallStatusHandler)
        http.HandleFunc("/api/firewall/forwarding", handlers.APIFirewallToggleForwardingHandler)
        http.HandleFunc("/api/firewall/masquerade", handlers.APIFirewallToggleMasqueradeHandler)
        http.HandleFunc("/api/firewall/rule/add", handlers.APIFirewallAddRuleHandler)
        http.HandleFunc("/api/firewall/rule/delete", handlers.APIFirewallDeleteRuleHandler)
        http.HandleFunc("/api/firewall/config", handlers.APIFirewallGetConfigHandler)
        http.HandleFunc("/api/firewall/config/save", handlers.APIFirewallSaveConfigHandler)

        http.HandleFunc("/api/system/requirements", handlers.APISystemRequirementsHandler)
        http.HandleFunc("/api/system/info", handlers.APISystemInfoHandler)

        http.Handle("/static/", http.StripPrefix("/static/", http.FileServer(http.Dir(cfg.Paths.StaticDir))))

        addr := fmt.Sprintf("%s:%s", cfg.Server.Host, cfg.Server.Port)
        logger.Log.Info("server starting", "address", addr)
        log.Fatal(http.ListenAndServe(addr, nil))
}

func printSystemRequirements() {
        fmt.Println("\n=== System Requirements Check ===")
        
        allMet := true
        
        // Check ifconfig/ip
        fmt.Print("• ifconfig/ip:          ")
        if _, err := exec.LookPath("ifconfig"); err == nil {
                fmt.Println("✓ installed (ifconfig)")
        } else if _, err := exec.LookPath("ip"); err == nil {
                fmt.Println("✓ installed (ip)")
        } else {
                fmt.Println("✗ not found")
        }
        
        // Check resolvconf
        fmt.Print("• resolvconf:           ")
        if _, err := exec.LookPath("resolvconf"); err == nil {
                fmt.Println("✓ installed")
        } else {
                fmt.Println("- not found (optional)")
        }
        
        // Check systemd-resolved
        fmt.Print("• systemd-resolved:     ")
        if cmd := exec.Command("systemctl", "is-active", "systemd-resolved"); cmd.Run() == nil {
                fmt.Println("✓ active")
        } else {
                fmt.Println("- inactive (optional)")
        }
        
        // Check ss/netstat
        fmt.Print("• ss/netstat:           ")
        if _, err := exec.LookPath("ss"); err == nil {
                fmt.Println("✓ installed (ss)")
        } else if _, err := exec.LookPath("netstat"); err == nil {
                fmt.Println("✓ installed (netstat)")
        } else {
                fmt.Println("✗ not found")
        }
        
        // Check amneziawg kernel module
        fmt.Print("• amneziawg module:     ")
        cmd := exec.Command("lsmod")
        if output, err := cmd.Output(); err == nil {
                if strings.Contains(string(output), "amneziawg") {
                        fmt.Println("✓ loaded")
                } else {
                        fmt.Println("✗ not loaded (run: modprobe amneziawg)")
                        allMet = false
                }
        } else {
                fmt.Println("✗ cannot check")
                allMet = false
        }
        
        // Check awg-quick
        fmt.Print("• awg-quick:            ")
        if _, err := exec.LookPath("awg-quick"); err == nil {
                fmt.Println("✓ installed")
        } else {
                fmt.Println("✗ not found (required)")
                allMet = false
        }
        
        // Check awg
        fmt.Print("• awg:                  ")
        if _, err := exec.LookPath("awg"); err == nil {
                fmt.Println("✓ installed")
        } else {
                fmt.Println("✗ not found (required)")
                allMet = false
        }
        
        fmt.Println("=================================")
        if allMet {
                fmt.Println("✓ All required components are installed")
        } else {
                fmt.Println("⚠ Some required components are missing")
        }
        fmt.Println()
}