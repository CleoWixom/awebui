package utils

import (
        "os"
)

// AtomicWriteFile writes data to a file atomically using a temporary file
// This prevents corruption if the write operation is interrupted
func AtomicWriteFile(filename string, data []byte, perm os.FileMode) error {
        tmpFile := filename + ".tmp"
        if err := os.WriteFile(tmpFile, data, perm); err != nil {
                return err
        }
        if err := os.Rename(tmpFile, filename); err != nil {
                os.Remove(tmpFile)
                return err
        }
        return nil
}

// Contains checks if a string slice contains a specific string
func Contains(slice []string, item string) bool {
        for _, s := range slice {
                if s == item {
                        return true
                }
        }
        return false
}

// RemoveString removes all occurrences of a string from a slice
func RemoveString(slice []string, item string) []string {
        result := []string{}
        for _, s := range slice {
                if s != item {
                        result = append(result, s)
                }
        }
        return result
}
