package config

import (
        "log"
        "os"
        "strconv"
        "time"
)

type Config struct {
        Server   ServerConfig
        Paths    PathsConfig
        Monitor  MonitorConfig
        External ExternalConfig
        Firewall FirewallConfig
        Routing  RoutingConfig
        Template TemplateConfig
}

type ServerConfig struct {
        Host string
        Port string
}

type PathsConfig struct {
        ConfigDir        string
        RoutesDir        string
        CidrDbsDir       string
        NetworkConfigDir string
        TemplatesDir     string
        StaticDir        string
        StateFile        string
}

type MonitorConfig struct {
        CheckInterval        time.Duration
        HandshakeThreshold   time.Duration
        FailCountThreshold   int
        RestartDelay         time.Duration
        ConnectivityHost     string
        ConnectivityTimeout  time.Duration
        TunnelPingHost       string
        TunnelPingTimeout    time.Duration
        TunnelPingInterval   time.Duration
        MaxRestartAttempts   int
        FallbackTimeout      time.Duration
        RecoveryCheckInterval time.Duration
}

type ExternalConfig struct {
        GeoIPURL     string
        GeoIPTimeout time.Duration
}

type FirewallConfig struct {
        FilterTableName string
        NATTableName    string
}

type RoutingConfig struct {
        TableName   string
        IpsetPrefix string
        MarkBase    int
}

type TemplateConfig struct {
        CacheEnabled bool
}

func Load() *Config {
        cfg := &Config{
                Server: ServerConfig{
                        Host: getEnv("SERVER_HOST", "0.0.0.0"),
                        Port: getEnv("SERVER_PORT", "5000"),
                },
                Paths: PathsConfig{
                        ConfigDir:        getEnv("CONFIG_DIR", "/etc/amnezia/amneziawg"),
                        RoutesDir:        getEnv("ROUTES_DIR", "/etc/amnezia/routes"),
                        CidrDbsDir:       getEnv("CIDR_DBS_DIR", "/var/lib/amneziawg/cidrdbs"),
                        NetworkConfigDir: getEnv("NETWORK_CONFIG_DIR", "/etc/amnezia/network"),
                        TemplatesDir:     getEnv("TEMPLATES_DIR", "templates"),
                        StaticDir:        getEnv("STATIC_DIR", "static"),
                        StateFile:        getEnv("STATE_FILE", "/var/lib/amneziawg/tunnel-state.json"),
                },
                Monitor: MonitorConfig{
                        CheckInterval:         getDurationEnv("MONITOR_CHECK_INTERVAL", 30*time.Second),
                        HandshakeThreshold:    getDurationEnv("MONITOR_HANDSHAKE_THRESHOLD", 3*time.Minute),
                        FailCountThreshold:    getIntEnv("MONITOR_FAIL_COUNT_THRESHOLD", 3),
                        RestartDelay:          getDurationEnv("MONITOR_RESTART_DELAY", 2*time.Second),
                        ConnectivityHost:      getEnv("MONITOR_CONNECTIVITY_HOST", "8.8.8.8"),
                        ConnectivityTimeout:   getDurationEnv("MONITOR_CONNECTIVITY_TIMEOUT", 2*time.Second),
                        TunnelPingHost:        getEnv("MONITOR_TUNNEL_PING_HOST", "1.1.1.1"),
                        TunnelPingTimeout:     getDurationEnv("MONITOR_TUNNEL_PING_TIMEOUT", 3*time.Second),
                        TunnelPingInterval:    getDurationEnv("MONITOR_TUNNEL_PING_INTERVAL", 10*time.Second),
                        MaxRestartAttempts:    getIntEnv("MONITOR_MAX_RESTART_ATTEMPTS", 5),
                        FallbackTimeout:       getDurationEnv("MONITOR_FALLBACK_TIMEOUT", 5*time.Minute),
                        RecoveryCheckInterval: getDurationEnv("MONITOR_RECOVERY_CHECK_INTERVAL", 30*time.Second),
                },
                External: ExternalConfig{
                        GeoIPURL:     getEnv("GEOIP_URL", "http://ip-api.com/json/%s?fields=status,country,countryCode,city,lat,lon"),
                        GeoIPTimeout: getDurationEnv("GEOIP_TIMEOUT", 5*time.Second),
                },
                Firewall: FirewallConfig{
                        FilterTableName: getEnv("FIREWALL_FILTER_TABLE", "amneziawg_filter"),
                        NATTableName:    getEnv("FIREWALL_NAT_TABLE", "amneziawg_nat"),
                },
                Routing: RoutingConfig{
                        TableName:   getEnv("ROUTING_TABLE_NAME", "awg_routing"),
                        IpsetPrefix: getEnv("ROUTING_IPSET_PREFIX", "ar_"),
                        MarkBase:    getIntEnv("ROUTING_MARK_BASE", 0x1000),
                },
                Template: TemplateConfig{
                        CacheEnabled: getBoolEnv("TEMPLATE_CACHE_ENABLED", false),
                },
        }
        
        validateConfig(cfg)
        return cfg
}

func validateConfig(cfg *Config) {
        const maxIpsetPrefixLen = 8
        if len(cfg.Routing.IpsetPrefix) > maxIpsetPrefixLen {
                log.Fatalf("FATAL: ROUTING_IPSET_PREFIX '%s' is too long (%d chars). Maximum allowed is %d chars.\n"+
                        "Ipset name format: prefix + hash(6) + '_' + routeID(16) must be ≤31 chars.\n"+
                        "Current prefix would result in %d chars which exceeds ipset 31-char limit.",
                        cfg.Routing.IpsetPrefix,
                        len(cfg.Routing.IpsetPrefix),
                        maxIpsetPrefixLen,
                        len(cfg.Routing.IpsetPrefix)+6+1+16)
        }
        
        if cfg.Routing.IpsetPrefix == "" {
                log.Fatal("FATAL: ROUTING_IPSET_PREFIX cannot be empty")
        }
        
        if cfg.Server.Port == "" {
                log.Fatal("FATAL: SERVER_PORT cannot be empty")
        }
        
        if cfg.Paths.ConfigDir == "" {
                log.Fatal("FATAL: CONFIG_DIR cannot be empty")
        }
}

func getEnv(key, defaultValue string) string {
        if value := os.Getenv(key); value != "" {
                return value
        }
        return defaultValue
}

func getIntEnv(key string, defaultValue int) int {
        if value := os.Getenv(key); value != "" {
                if intValue, err := strconv.Atoi(value); err == nil {
                        return intValue
                }
        }
        return defaultValue
}

func getDurationEnv(key string, defaultValue time.Duration) time.Duration {
        if value := os.Getenv(key); value != "" {
                if duration, err := time.ParseDuration(value); err == nil {
                        return duration
                }
        }
        return defaultValue
}

func getBoolEnv(key string, defaultValue bool) bool {
        if value := os.Getenv(key); value != "" {
                if boolValue, err := strconv.ParseBool(value); err == nil {
                        return boolValue
                }
        }
        return defaultValue
}
