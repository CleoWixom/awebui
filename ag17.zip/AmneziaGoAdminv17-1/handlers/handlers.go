package handlers

import (
        "context"
        "encoding/json"
        "fmt"
        "net/http"
        "os"
        "os/exec"
        "path/filepath"
        "strconv"
        "strings"
        "time"

        "amneziawg-manager/config"
        "amneziawg-manager/logger"
        "amneziawg-manager/models"
        "amneziawg-manager/renderer"
)

var cfg *config.Config

func Init(c *config.Config) {
        cfg = c
}

// Helper functions for JSON responses with error handling
// Note: HTTP status must be set before calling these functions, as Go's
// HTTP library doesn't allow changing status after response body writing begins.
// If encoding fails after writing starts, we log the error but can't send HTTP 500.

func respondJSON(w http.ResponseWriter, data interface{}) {
        if err := json.NewEncoder(w).Encode(data); err != nil {
                logger.Log.Error("failed to encode JSON response", "error", err)
        }
}

func respondError(w http.ResponseWriter, code int, message string) {
        w.WriteHeader(code)
        respondJSON(w, map[string]interface{}{
                "success": false,
                "message": message,
        })
}

func respondSuccess(w http.ResponseWriter, message string, extra ...map[string]interface{}) {
        response := map[string]interface{}{
                "success": true,
                "message": message,
        }
        for _, e := range extra {
                for k, v := range e {
                        response[k] = v
                }
        }
        respondJSON(w, response)
}

func validateAndSanitizeFilename(filename string) (string, error) {
        if filename == "" {
                return "", fmt.Errorf("filename is required")
        }

        filename = filepath.Base(filename)

        if strings.Contains(filename, "..") || strings.ContainsAny(filename, "/\\") {
                return "", fmt.Errorf("invalid filename")
        }

        if !strings.HasSuffix(filename, ".conf") {
                filename += ".conf"
        }

        return filename, nil
}

func validateFilePath(filename string) (string, error) {
        cleanName, err := validateAndSanitizeFilename(filename)
        if err != nil {
                return "", err
        }

        fullPath := filepath.Join(cfg.Paths.ConfigDir, cleanName)
        absPath, err := filepath.Abs(fullPath)
        if err != nil {
                return "", fmt.Errorf("invalid path")
        }

        absConfigDir, err := filepath.Abs(cfg.Paths.ConfigDir)
        if err != nil {
                return "", fmt.Errorf("invalid config directory")
        }

        if !strings.HasPrefix(absPath, absConfigDir+string(filepath.Separator)) && absPath != absConfigDir {
                return "", fmt.Errorf("path traversal attempt detected")
        }

        return fullPath, nil
}

func validateTunnelName(name string) error {
        if name == "" {
                return fmt.Errorf("tunnel name is required")
        }

        name = filepath.Base(name)

        if strings.ContainsAny(name, "/\\..") || strings.Contains(name, "..") {
                return fmt.Errorf("invalid tunnel name")
        }

        if len(name) > 64 {
                return fmt.Errorf("tunnel name too long")
        }

        return nil
}

func atomicWriteFile(filename string, data []byte, perm os.FileMode) error {
        tmpFile := filename + ".tmp"
        if err := os.WriteFile(tmpFile, data, perm); err != nil {
                return err
        }
        if err := os.Rename(tmpFile, filename); err != nil {
                os.Remove(tmpFile)
                return err
        }
        return nil
}

func IndexHandler(w http.ResponseWriter, r *http.Request) {
        renderer.RenderPage(w, "index", "layout", nil)
}

func TunnelsHandler(w http.ResponseWriter, r *http.Request) {
        renderer.RenderPage(w, "tunnels", "layout", nil)
}

func APIListTunnelsHandler(w http.ResponseWriter, r *http.Request) {
        tunnels, err := listTunnels()
        if err != nil {
                http.Error(w, err.Error(), http.StatusInternalServerError)
                return
        }

        w.Header().Set("Content-Type", "application/json")
        respondJSON(w, tunnels)
}

func APITunnelControlHandler(w http.ResponseWriter, r *http.Request) {
        var req struct {
                Name   string `json:"name"`
                Action string `json:"action"`
        }

        if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
                http.Error(w, err.Error(), http.StatusBadRequest)
                return
        }

        if err := validateTunnelName(req.Name); err != nil {
                http.Error(w, err.Error(), http.StatusBadRequest)
                return
        }

        if req.Action != "up" && req.Action != "down" {
                http.Error(w, "Invalid action: must be 'up' or 'down'", http.StatusBadRequest)
                return
        }

        config, err := loadTunnelConfig(req.Name)
        if err != nil {
                logger.Log.Warn("failed to load tunnel config", "tunnel", req.Name, "error", err)
        }

        // Check for default gateway conflict before starting
        if req.Action == "up" && config != nil && config.Mode == models.ModeDefaultGateway {
                conflict, err := checkDefaultGatewayConflict(req.Name)
                if err != nil {
                        http.Error(w, err.Error(), http.StatusInternalServerError)
                        return
                }
                if conflict {
                        http.Error(w, "Another tunnel is already running as default gateway. Please stop it first.", http.StatusConflict)
                        return
                }
        }

        ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
        defer cancel()
        cmd := exec.CommandContext(ctx, "awg-quick", req.Action, req.Name)
        output, err := cmd.CombinedOutput()
        if err != nil {
                w.Header().Set("Content-Type", "application/json")
                respondJSON(w, map[string]interface{}{
                        "success": false,
                        "message": string(output),
                        "error":   err.Error(),
                })
                return
        }

        // Apply routing rules after tunnel is up
        if req.Action == "up" && config != nil {
                if err := applyRoutingRules(config); err != nil {
                        w.Header().Set("Content-Type", "application/json")
                        respondError(w, http.StatusInternalServerError, "Tunnel started but routing rules failed: "+err.Error())
                        return
                }
        }

        // Clear routing rules when tunnel goes down
        if req.Action == "down" && config != nil {
                clearRoutingRules(config)
        }

        w.Header().Set("Content-Type", "application/json")
        respondSuccess(w, fmt.Sprintf("Tunnel %s %s successfully", req.Name, req.Action))
}

func APIListFilesHandler(w http.ResponseWriter, r *http.Request) {
        files, err := listConfigFiles()
        if err != nil {
                http.Error(w, err.Error(), http.StatusInternalServerError)
                return
        }

        w.Header().Set("Content-Type", "application/json")
        respondJSON(w, files)
}

func APIGetFileHandler(w http.ResponseWriter, r *http.Request) {
        filename := r.URL.Query().Get("name")

        filePath, err := validateFilePath(filename)
        if err != nil {
                http.Error(w, err.Error(), http.StatusBadRequest)
                return
        }

        content, err := os.ReadFile(filePath)
        if err != nil {
                http.Error(w, "File not found", http.StatusNotFound)
                return
        }

        w.Header().Set("Content-Type", "application/json")
        respondJSON(w, map[string]string{
                "name":    filepath.Base(filePath),
                "content": string(content),
        })
}

func APISaveFileHandler(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")

        var req struct {
                Name    string `json:"name"`
                Content string `json:"content"`
        }

        if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
                logger.Log.Error("failed to decode save file request", "error", err)
                respondError(w, http.StatusBadRequest, "Invalid request: "+err.Error())
                return
        }

        logger.Log.Info("saving file", "name", req.Name, "content_length", len(req.Content))

        filePath, err := validateFilePath(req.Name)
        if err != nil {
                logger.Log.Error("failed to validate file path", "name", req.Name, "error", err)
                respondError(w, http.StatusBadRequest, "Invalid file path: "+err.Error())
                return
        }

        if err := os.MkdirAll(cfg.Paths.ConfigDir, 0755); err != nil {
                logger.Log.Error("failed to create config directory", "dir", cfg.Paths.ConfigDir, "error", err)
                respondError(w, http.StatusInternalServerError, "Failed to create config directory: "+err.Error())
                return
        }

        if err := atomicWriteFile(filePath, []byte(req.Content), 0600); err != nil {
                logger.Log.Error("failed to write file", "path", filePath, "error", err)
                respondError(w, http.StatusInternalServerError, "Failed to save file: "+err.Error())
                return
        }

        logger.Log.Info("file saved successfully", "path", filePath)
        w.WriteHeader(http.StatusOK)
        respondSuccess(w, "File saved successfully")
}

func APIDeleteFileHandler(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")

        var req struct {
                Name string `json:"name"`
        }

        if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
                respondError(w, http.StatusBadRequest, "Invalid request: "+err.Error())
                return
        }

        filePath, err := validateFilePath(req.Name)
        if err != nil {
                respondError(w, http.StatusBadRequest, "Invalid file path: "+err.Error())
                return
        }

        if err := os.Remove(filePath); err != nil {
                respondError(w, http.StatusInternalServerError, "Failed to delete file: "+err.Error())
                return
        }

        w.WriteHeader(http.StatusOK)
        respondSuccess(w, "File deleted successfully")
}

func listTunnels() ([]models.Tunnel, error) {
        tunnels := []models.Tunnel{}

        if _, err := os.Stat(cfg.Paths.ConfigDir); os.IsNotExist(err) {
                return tunnels, nil
        }

        files, err := os.ReadDir(cfg.Paths.ConfigDir)
        if err != nil {
                return nil, err
        }

        for _, file := range files {
                if !file.IsDir() && strings.HasSuffix(file.Name(), ".conf") {
                        info, err := file.Info()
                        if err != nil {
                                logger.Log.Warn("failed to get file info", "file", file.Name(), "error", err)
                                continue
                        }
                        name := strings.TrimSuffix(file.Name(), ".conf")
                        status := getTunnelStatus(name)

                        tunnel := models.Tunnel{
                                Name: name,
                                Status: status,
                                LastUpdated: info.ModTime(),
                        }

                        // Extract interface name, server IP and country from config
                        configPath := filepath.Join(cfg.Paths.ConfigDir, file.Name())
                        if content, err := os.ReadFile(configPath); err == nil {
                                configStr := string(content)

                                // Extract interface name (from filename or config)
                                tunnel.Interface = name

                                // Extract server IP from Endpoint in [Peer] section
                                lines := strings.Split(configStr, "\n")
                                inPeerSection := false
                                for _, line := range lines {
                                        line = strings.TrimSpace(line)
                                        if strings.HasPrefix(line, "[Peer]") {
                                                inPeerSection = true
                                                continue
                                        }
                                        if inPeerSection && strings.HasPrefix(line, "Endpoint") {
                                                parts := strings.Split(line, "=")
                                                if len(parts) == 2 {
                                                        endpoint := strings.TrimSpace(parts[1])
                                                        // Extract IP from "IP:Port" format
                                                        if ipPort := strings.Split(endpoint, ":"); len(ipPort) > 0 {
                                                                tunnel.ServerIP = ipPort[0]
                                                                // Try to determine country from IP (simple heuristic)
                                                                tunnel.Country = getCountryFromIP(ipPort[0])
                                                        }
                                                }
                                                break
                                        }
                                }
                        }

                        tunnels = append(tunnels, tunnel)
                }
        }

        return tunnels, nil
}

func getCountryFromIP(ip string) string {
        if ip == "" || ip == "N/A" {
                return ""
        }

        url := fmt.Sprintf(cfg.External.GeoIPURL, ip)
        
        ctx, cancel := context.WithTimeout(context.Background(), cfg.External.GeoIPTimeout)
        defer cancel()
        
        req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
        if err != nil {
                logger.Log.Debug("geoip request creation failed", "ip", ip, "error", err)
                return ""
        }
        
        client := &http.Client{
                Timeout: cfg.External.GeoIPTimeout,
        }
        
        resp, err := client.Do(req)
        if err != nil {
                logger.Log.Debug("geoip lookup failed", "ip", ip, "error", err)
                return ""
        }
        defer resp.Body.Close()

        if resp.StatusCode != http.StatusOK {
                logger.Log.Debug("geoip returned non-200", "ip", ip, "status", resp.StatusCode)
                return ""
        }

        var result struct {
                CountryCode string `json:"countryCode"`
        }

        if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
                logger.Log.Debug("failed to decode geoip response", "ip", ip, "error", err)
                return ""
        }

        return result.CountryCode
}

func getTunnelStatus(name string) string {
        ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
        defer cancel()
        cmd := exec.CommandContext(ctx, "awg", "show", name)
        err := cmd.Run()
        if err != nil {
                return "down"
        }
        return "up"
}

func getTunnelDetails(name string) (*models.Tunnel, error) {
        ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
        defer cancel()
        cmd := exec.CommandContext(ctx, "awg", "show", name)
        output, err := cmd.CombinedOutput()
        if err != nil {
                return nil, fmt.Errorf("tunnel not running or not found")
        }

        tunnel := &models.Tunnel{
                Name: name,
                Status: "up",
                Peers: []models.Peer{},
        }

        lines := strings.Split(string(output), "\n")
        var currentPeer *models.Peer

        for _, line := range lines {
                line = strings.TrimSpace(line)
                if line == "" {
                        continue
                }

                parts := strings.SplitN(line, ":", 2)
                if len(parts) != 2 {
                        continue
                }

                key := strings.TrimSpace(parts[0])
                value := strings.TrimSpace(parts[1])

                switch key {
                case "interface":
                        tunnel.Interface = value
                case "public key":
                        tunnel.PublicKey = value
                case "listening port":
                        if port, err := strconv.Atoi(value); err == nil {
                                tunnel.ListenPort = port
                        }
                case "peer":
                        if currentPeer != nil {
                                tunnel.Peers = append(tunnel.Peers, *currentPeer)
                        }
                        currentPeer = &models.Peer{
                                PublicKey: value,
                        }
                case "endpoint":
                        if currentPeer != nil {
                                currentPeer.Endpoint = value
                        }
                case "allowed ips":
                        if currentPeer != nil {
                                currentPeer.AllowedIPs = value
                        }
                case "latest handshake":
                        if currentPeer != nil && value != "(none)" {
                                if duration, err := parseDuration(value); err == nil {
                                        currentPeer.LatestHandshake = time.Now().Add(-duration)
                                }
                        }
                case "transfer":
                        if currentPeer != nil {
                                parts := strings.Split(value, ",")
                                for _, part := range parts {
                                        part = strings.TrimSpace(part)
                                        if strings.Contains(part, "received") {
                                                if bytes, err := parseBytes(part); err == nil {
                                                        currentPeer.TransferRx = bytes
                                                }
                                        } else if strings.Contains(part, "sent") {
                                                if bytes, err := parseBytes(part); err == nil {
                                                        currentPeer.TransferTx = bytes
                                                }
                                        }
                                }
                        }
                case "persistent keepalive":
                        if currentPeer != nil && value != "off" {
                                if keepalive, err := strconv.Atoi(strings.TrimSuffix(value, " seconds")); err == nil {
                                        currentPeer.PersistentKeepalive = keepalive
                                }
                        }
                }
        }

        if currentPeer != nil {
                tunnel.Peers = append(tunnel.Peers, *currentPeer)
        }

        return tunnel, nil
}

func parseDuration(s string) (time.Duration, error) {
        s = strings.TrimSpace(s)
        parts := strings.Fields(s)

        var total time.Duration
        for i := 0; i < len(parts)-1; i += 2 {
                value, err := strconv.Atoi(parts[i])
                if err != nil {
                        continue
                }
                unit := parts[i+1]

                switch {
                case strings.HasPrefix(unit, "day"):
                        total += time.Duration(value) * 24 * time.Hour
                case strings.HasPrefix(unit, "hour"):
                        total += time.Duration(value) * time.Hour
                case strings.HasPrefix(unit, "minute"):
                        total += time.Duration(value) * time.Minute
                case strings.HasPrefix(unit, "second"):
                        total += time.Duration(value) * time.Second
                }
        }

        return total, nil
}

func parseBytes(s string) (int64, error) {
        s = strings.TrimSpace(s)
        parts := strings.Fields(s)

        for i, part := range parts {
                if _, err := strconv.ParseFloat(part, 64); err == nil {
                        if i+1 < len(parts) {
                                value, _ := strconv.ParseFloat(part, 64)
                                unit := parts[i+1]

                                switch unit {
                                case "B":
                                        return int64(value), nil
                                case "KiB":
                                        return int64(value * 1024), nil
                                case "MiB":
                                        return int64(value * 1024 * 1024), nil
                                case "GiB":
                                        return int64(value * 1024 * 1024 * 1024), nil
                                case "TiB":
                                        return int64(value * 1024 * 1024 * 1024 * 1024), nil
                                }
                        }
                }
        }

        return 0, fmt.Errorf("unable to parse bytes")
}

func APITunnelDetailsHandler(w http.ResponseWriter, r *http.Request) {
        name := r.URL.Query().Get("name")

        if err := validateTunnelName(name); err != nil {
                http.Error(w, err.Error(), http.StatusBadRequest)
                return
        }

        tunnel, err := getTunnelDetails(name)
        if err != nil {
                http.Error(w, err.Error(), http.StatusNotFound)
                return
        }

        w.Header().Set("Content-Type", "application/json")
        respondJSON(w, tunnel)
}

func listConfigFiles() ([]models.ConfigFile, error) {
        files := []models.ConfigFile{}

        if _, err := os.Stat(cfg.Paths.ConfigDir); os.IsNotExist(err) {
                return files, nil
        }

        dirFiles, err := os.ReadDir(cfg.Paths.ConfigDir)
        if err != nil {
                return nil, err
        }

        for _, file := range dirFiles {
                if !file.IsDir() && strings.HasSuffix(file.Name(), ".conf") {
                        info, err := file.Info()
                        if err != nil {
                                logger.Log.Warn("failed to get file info", "file", file.Name(), "error", err)
                                continue
                        }
                        configFile := models.ConfigFile{
                                Name: file.Name(),
                                Path: filepath.Join(cfg.Paths.ConfigDir, file.Name()),
                                Size: info.Size(),
                                ModTime: info.ModTime(),
                        }
                        files = append(files, configFile)
                }
        }

        return files, nil
}

func APIListNetworkInterfacesHandler(w http.ResponseWriter, r *http.Request) {
        cmd := exec.Command("ip", "-json", "addr", "show")
        output, err := cmd.Output()
        if err != nil {
                http.Error(w, "Failed to get network interfaces", http.StatusInternalServerError)
                return
        }

        var interfaces []map[string]interface{}
        if err := json.Unmarshal(output, &interfaces); err != nil {
                http.Error(w, "Failed to parse network interfaces", http.StatusInternalServerError)
                return
        }

        w.Header().Set("Content-Type", "application/json")
        respondJSON(w, interfaces)
}

type SystemRequirement struct {
        Name      string `json:"name"`
        Required  bool   `json:"required"`
        Installed bool   `json:"installed"`
        Version   string `json:"version,omitempty"`
        Path      string `json:"path,omitempty"`
        Error     string `json:"error,omitempty"`
}

func APISystemRequirementsHandler(w http.ResponseWriter, r *http.Request) {
        requirements := []SystemRequirement{}

        // Check ifconfig
        ifconfigReq := checkCommand("ifconfig", "--version", false)
        if !ifconfigReq.Installed {
                ipReq := checkCommand("ip", "-V", false)
                if ipReq.Installed {
                        ipReq.Name = "ip (ifconfig alternative)"
                        requirements = append(requirements, ipReq)
                } else {
                        ifconfigReq.Name = "ifconfig/ip"
                        ifconfigReq.Error = "Neither ifconfig nor ip found"
                        requirements = append(requirements, ifconfigReq)
                }
        } else {
                requirements = append(requirements, ifconfigReq)
        }

        // Check resolvconf
        resolvconfReq := checkCommand("resolvconf", "--version", false)
        requirements = append(requirements, resolvconfReq)

        // Check systemd-resolved
        systemdResolvedReq := SystemRequirement{
                Name:     "systemd-resolved",
                Required: false,
        }
        resolvedCmd := exec.Command("systemctl", "is-active", "systemd-resolved")
        if output, err := resolvedCmd.Output(); err == nil {
                status := strings.TrimSpace(string(output))
                if status == "active" {
                        systemdResolvedReq.Installed = true
                        systemdResolvedReq.Version = "active"
                } else {
                        systemdResolvedReq.Installed = false
                        systemdResolvedReq.Error = "Service status: " + status
                }
        } else {
                systemdResolvedReq.Installed = false
                systemdResolvedReq.Error = "Service not found or not installed"
        }
        requirements = append(requirements, systemdResolvedReq)

        // Check ss or netstat
        ssReq := checkCommand("ss", "-V", false)
        if !ssReq.Installed {
                netstatReq := checkCommand("netstat", "--version", false)
                if netstatReq.Installed {
                        netstatReq.Name = "netstat (ss alternative)"
                        requirements = append(requirements, netstatReq)
                } else {
                        ssReq.Name = "ss/netstat"
                        ssReq.Error = "Neither ss nor netstat found"
                        requirements = append(requirements, ssReq)
                }
        } else {
                requirements = append(requirements, ssReq)
        }

        // Check amneziawg kernel module
        moduleReq := SystemRequirement{
                Name:     "amneziawg kernel module",
                Required: true,
        }
        modprobeCmd := exec.Command("lsmod")
        if output, err := modprobeCmd.Output(); err == nil {
                if strings.Contains(string(output), "amneziawg") {
                        moduleReq.Installed = true
                        moduleReq.Version = "loaded"
                } else {
                        moduleReq.Installed = false
                        moduleReq.Error = "Module not loaded (run: modprobe amneziawg)"
                }
        } else {
                moduleReq.Installed = false
                moduleReq.Error = "Cannot check kernel modules: " + err.Error()
        }
        requirements = append(requirements, moduleReq)

        // Check awg-quick
        awgQuickReq := checkCommand("awg-quick", "help", true)
        requirements = append(requirements, awgQuickReq)

        // Check awg
        awgReq := checkCommand("awg", "help", true)
        requirements = append(requirements, awgReq)

        w.Header().Set("Content-Type", "application/json")
        respondJSON(w, map[string]interface{}{
                "requirements": requirements,
                "all_met":      allRequirementsMet(requirements),
        })
}

func checkCommand(name string, versionArg string, required bool) SystemRequirement {
        req := SystemRequirement{
                Name:     name,
                Required: required,
        }

        cmdPath, err := exec.LookPath(name)
        if err != nil {
                req.Installed = false
                req.Error = "Command not found in PATH"
                return req
        }

        req.Installed = true
        req.Path = cmdPath

        cmd := exec.Command(name, versionArg)
        output, err := cmd.CombinedOutput()
        if err == nil {
                lines := strings.Split(string(output), "\n")
                if len(lines) > 0 {
                        req.Version = strings.TrimSpace(lines[0])
                }
        } else {
                req.Version = "installed (version check failed)"
        }

        return req
}

func allRequirementsMet(requirements []SystemRequirement) bool {
        for _, req := range requirements {
                if req.Required && !req.Installed {
                        return false
                }
        }
        return true
}