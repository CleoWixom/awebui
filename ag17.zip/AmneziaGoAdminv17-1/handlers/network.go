
package handlers

import (
        "encoding/json"
        "fmt"
        "net"
        "net/http"
        "os"
        "os/exec"
        "path/filepath"
        "strings"

        "amneziawg-manager/logger"
        "amneziawg-manager/renderer"
)

type DNSConfig struct {
        Resolver   string   `json:"resolver"`
        Servers    []string `json:"servers"`
        DNSSEC     bool     `json:"dnssec"`
        DNSOverTLS bool     `json:"dns_over_tls"`
        MDNS       bool     `json:"mdns"`
}

type DHCPServerConfig struct {
        Interface  string `json:"interface"`
        RangeStart string `json:"range_start"`
        RangeEnd   string `json:"range_end"`
        Netmask    string `json:"netmask"`
        Gateway    string `json:"gateway"`
        LeaseTime  int    `json:"lease_time"`
}

type DHCPRelayConfig struct {
        Server     string   `json:"server"`
        Interfaces []string `json:"interfaces"`
}

type DHCPConfig struct {
        Mode   string            `json:"mode"`
        Server *DHCPServerConfig `json:"server,omitempty"`
        Relay  *DHCPRelayConfig  `json:"relay,omitempty"`
}

type NetworkConfig struct {
        DNS  *DNSConfig  `json:"dns,omitempty"`
        DHCP *DHCPConfig `json:"dhcp,omitempty"`
}

func isValidIP(ip string) bool {
        if ip == "" {
                return true
        }
        return net.ParseIP(ip) != nil
}

func NetworkPageHandler(w http.ResponseWriter, r *http.Request) {
        renderer.RenderPage(w, "network", "layout", nil)
}

func APIGetNetworkConfigHandler(w http.ResponseWriter, r *http.Request) {
        configPath := filepath.Join(cfg.Paths.NetworkConfigDir, "config.json")
        
        var config NetworkConfig
        if data, err := os.ReadFile(configPath); err == nil {
                if err := json.Unmarshal(data, &config); err != nil {
                        logger.Log.Error("failed to parse network config", "error", err)
                        config = NetworkConfig{}
                }
        } else {
                config = NetworkConfig{}
        }
        
        w.Header().Set("Content-Type", "application/json")
        respondJSON(w, config)
}

func APISaveDNSConfigHandler(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")
        
        var dnsConfig DNSConfig
        if err := json.NewDecoder(r.Body).Decode(&dnsConfig); err != nil {
                respondError(w, http.StatusBadRequest, "Invalid request: "+err.Error())
                return
        }
        
        for _, server := range dnsConfig.Servers {
                if !isValidIP(server) {
                        respondError(w, http.StatusBadRequest, fmt.Sprintf("Invalid DNS server IP address: %s", server))
                        return
                }
        }
        
        if err := os.MkdirAll(cfg.Paths.NetworkConfigDir, 0755); err != nil {
                logger.Log.Error("failed to create network config directory", "error", err)
                respondError(w, http.StatusInternalServerError, "Failed to create config directory: "+err.Error())
                return
        }
        
        configPath := filepath.Join(cfg.Paths.NetworkConfigDir, "config.json")
        var fullConfig NetworkConfig
        if data, err := os.ReadFile(configPath); err == nil {
                if err := json.Unmarshal(data, &fullConfig); err != nil {
                        logger.Log.Warn("failed to parse existing network config, using empty config", "error", err)
                }
        }
        fullConfig.DNS = &dnsConfig
        
        data, err := json.MarshalIndent(fullConfig, "", "  ")
        if err != nil {
                logger.Log.Error("failed to marshal DNS config", "error", err)
                respondError(w, http.StatusInternalServerError, "Failed to serialize configuration: "+err.Error())
                return
        }
        
        if err := atomicWriteFile(configPath, data, 0600); err != nil {
                logger.Log.Error("failed to write DNS config file", "error", err)
                respondError(w, http.StatusInternalServerError, "Failed to save configuration: "+err.Error())
                return
        }
        
        if err := applyDNSConfig(&dnsConfig); err != nil {
                respondError(w, http.StatusInternalServerError, "Configuration saved but failed to apply: "+err.Error())
                return
        }
        
        respondSuccess(w, "DNS configuration saved and applied successfully")
}

func APISaveDHCPConfigHandler(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")
        
        var dhcpConfig DHCPConfig
        if err := json.NewDecoder(r.Body).Decode(&dhcpConfig); err != nil {
                respondError(w, http.StatusBadRequest, "Invalid request: "+err.Error())
                return
        }
        
        if dhcpConfig.Server != nil {
                if !isValidIP(dhcpConfig.Server.RangeStart) {
                        respondError(w, http.StatusBadRequest, fmt.Sprintf("Invalid DHCP range start IP: %s", dhcpConfig.Server.RangeStart))
                        return
                }
                if !isValidIP(dhcpConfig.Server.RangeEnd) {
                        respondError(w, http.StatusBadRequest, fmt.Sprintf("Invalid DHCP range end IP: %s", dhcpConfig.Server.RangeEnd))
                        return
                }
                if !isValidIP(dhcpConfig.Server.Gateway) {
                        respondError(w, http.StatusBadRequest, fmt.Sprintf("Invalid gateway IP: %s", dhcpConfig.Server.Gateway))
                        return
                }
        }
        
        if dhcpConfig.Relay != nil {
                if !isValidIP(dhcpConfig.Relay.Server) {
                        respondError(w, http.StatusBadRequest, fmt.Sprintf("Invalid relay server IP: %s", dhcpConfig.Relay.Server))
                        return
                }
        }
        
        if err := os.MkdirAll(cfg.Paths.NetworkConfigDir, 0755); err != nil {
                logger.Log.Error("failed to create network config directory", "error", err)
                respondError(w, http.StatusInternalServerError, "Failed to create config directory: "+err.Error())
                return
        }
        
        configPath := filepath.Join(cfg.Paths.NetworkConfigDir, "config.json")
        var fullConfig NetworkConfig
        if data, err := os.ReadFile(configPath); err == nil {
                if err := json.Unmarshal(data, &fullConfig); err != nil {
                        logger.Log.Warn("failed to parse existing network config, using empty config", "error", err)
                }
        }
        fullConfig.DHCP = &dhcpConfig
        
        data, err := json.MarshalIndent(fullConfig, "", "  ")
        if err != nil {
                logger.Log.Error("failed to marshal DHCP config", "error", err)
                respondError(w, http.StatusInternalServerError, "Failed to serialize configuration: "+err.Error())
                return
        }
        
        if err := atomicWriteFile(configPath, data, 0600); err != nil {
                logger.Log.Error("failed to write DHCP config file", "error", err)
                respondError(w, http.StatusInternalServerError, "Failed to save configuration: "+err.Error())
                return
        }
        
        if err := applyDHCPConfig(&dhcpConfig); err != nil {
                respondError(w, http.StatusInternalServerError, "Configuration saved but failed to apply: "+err.Error())
                return
        }
        
        respondSuccess(w, "DHCP configuration saved and applied successfully")
}

func APIGetDNSStatusHandler(w http.ResponseWriter, r *http.Request) {
        cmd := exec.Command("resolvectl", "status")
        output, err := cmd.CombinedOutput()
        if err != nil {
                cmd = exec.Command("cat", "/etc/resolv.conf")
                output, err = cmd.Output()
                if err != nil {
                        logger.Log.Error("failed to get DNS status", "error", err)
                        http.Error(w, "Failed to retrieve DNS status", http.StatusInternalServerError)
                        return
                }
        }
        
        w.Header().Set("Content-Type", "text/plain")
        if _, err := w.Write(output); err != nil {
                logger.Log.Error("failed to write DNS status response", "error", err)
        }
}

func applyDNSConfig(config *DNSConfig) error {
        if config.Resolver == "systemd-resolved" {
                var conf strings.Builder
                conf.WriteString("[Resolve]\n")
                if len(config.Servers) > 0 {
                        conf.WriteString("DNS=" + strings.Join(config.Servers, " ") + "\n")
                }
                if config.DNSSEC {
                        conf.WriteString("DNSSEC=yes\n")
                }
                if config.DNSOverTLS {
                        conf.WriteString("DNSOverTLS=yes\n")
                }
                if config.MDNS {
                        conf.WriteString("MulticastDNS=yes\n")
                }
                
                if err := atomicWriteFile("/etc/systemd/resolved.conf.d/custom.conf", []byte(conf.String()), 0644); err != nil {
                        return err
                }
                
                exec.Command("systemctl", "restart", "systemd-resolved").Run()
        } else {
                var conf strings.Builder
                for _, server := range config.Servers {
                        conf.WriteString("nameserver " + server + "\n")
                }
                
                if err := atomicWriteFile("/etc/resolv.conf", []byte(conf.String()), 0644); err != nil {
                        return err
                }
        }
        
        return nil
}

func applyDHCPConfig(config *DHCPConfig) error {
        if config.Mode == "server" && config.Server != nil {
                var conf strings.Builder
                conf.WriteString(fmt.Sprintf("subnet %s netmask %s {\n", 
                        config.Server.RangeStart, config.Server.Netmask))
                conf.WriteString(fmt.Sprintf("  range %s %s;\n", 
                        config.Server.RangeStart, config.Server.RangeEnd))
                conf.WriteString(fmt.Sprintf("  option routers %s;\n", config.Server.Gateway))
                conf.WriteString(fmt.Sprintf("  default-lease-time %d;\n", config.Server.LeaseTime))
                conf.WriteString("}\n")
                
                if err := atomicWriteFile("/etc/dhcp/dhcpd.conf", []byte(conf.String()), 0644); err != nil {
                        return err
                }
                
                exec.Command("systemctl", "restart", "isc-dhcp-server").Run()
        } else if config.Mode == "relay" && config.Relay != nil {
                args := []string{"-d", config.Relay.Server}
                args = append(args, config.Relay.Interfaces...)
                
                exec.Command("systemctl", "stop", "isc-dhcp-server").Run()
                exec.Command("dhcrelay", args...).Start()
        } else {
                exec.Command("systemctl", "stop", "isc-dhcp-server").Run()
        }
        
        return nil
}
