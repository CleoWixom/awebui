# AmneziaWG Manager

## Overview
AmneziaWG Manager is a web-based interface designed to simplify the management of AmneziaWG tunnels. It provides a comprehensive administrative dashboard for adding, editing, deleting, and monitoring AmneziaWG configurations and operations. The project aims to enhance operational efficiency and offer an intuitive web interface for administrators to control tunnel status, manage configuration files, and oversee network settings.

## Recent Changes

### October 27, 2025 - Code Optimization & CDN Migration
- **Migrated all CDN dependencies to local files** for improved security and availability:
  - Tabler.io 1.4.0 CSS/JS (Bootstrap 5 included)
  - jQuery 3.7.1
  - DataTables 2.1.8 with responsive extension
  - jsVectorMap 1.5.3 with world map data
- **Fixed critical error handling issues**:
  - `setupNftablesTable()` now properly propagates nft command failures instead of silently swallowing them
  - Added proper error checking in `applyRoutingRules()` to catch nftables setup failures
- **Improved concurrency safety**:
  - Added `ipsetMutex` to protect `createIpset()` and `destroyIpset()` against race conditions during concurrent route creation
- **Verified UI responsiveness**: Layout uses proper Bootstrap responsive classes (navbar-expand-md, d-none d-md-flex, col-md-6 col-lg-3)
- **Code quality**: No unused code detected; all helpers and structs are actively used

### Known Technical Debt
- `getDefaultInterfaces()` in `handlers/firewall.go` duplicates interface detection logic (non-critical, isolated)

## User Preferences
Not specified.

## System Architecture

### Technology Stack
- **Backend**: Go 1.24
- **Frontend**: HTML templates with vanilla JavaScript
- **UI Framework**: Tabler.io 1.4.0 (official admin dashboard framework)
- **Icons**: Tabler SVG Icons
- **CSS**: Relies solely on official Tabler components and classes, no custom CSS.

### Core Features
1.  **Dashboard**: Offers an overview of system statistics, including uptime, hostname, kernel, distribution, CPU usage (with temperature), RAM, storage, and network stats. It also features a `jsVectorMap` visualization of network connections and a status card for system requirements.
2.  **Tunnel Management**: Enables starting/stopping tunnels, real-time status monitoring, detailed tunnel information (peers, transfer stats, handshake time), and management of configuration files. Includes a "Routing Rules" column displaying the routing mode and active routes for Split Routing.
3.  **Network & DNS**: Allows configuration of DNS servers, DHCP client management, and displays routing tables.
4.  **Firewall**: Provides `nftables`-based firewall management, including IP forwarding, Masquerading (NAT), Internet sharing, display of active `nftables` rules, and a configuration file editor. It uses isolated `amneziawg_filter` and `amneziawg_nat` tables.
5.  **File Management**: Facilitates editing and managing `.conf` files within `/etc/amnezia/amneziawg`, including uploading CIDR filter files.

### UI/UX Decisions
The application utilizes **Tabler.io 1.4.0** components, official Tabler SVG icons, and color schemes, presenting a professional admin dashboard. It features a **horizontal navigation layout** and a **responsive, mobile-first design**. The UI incorporates Tabler cards, tables, modals, badges, alerts, and notifications. A **dark theme is enabled by default** via `data-bs-theme="dark"`. All buttons use the `btn-sm` class for compactness. Each page includes informational descriptions to improve user understanding.

### System Design Choices
-   **Configuration**: Fully configurable via environment variables (`.env.example`). Defaults include `SERVER_HOST` (0.0.0.0), `SERVER_PORT` (5000), and `CONFIG_DIR` (/etc/amnezia/amneziawg). All timeouts, thresholds, and intervals are configurable.
-   **Logging**: Structured JSON logging using Go's `slog` with configurable log levels (DEBUG, INFO, WARN, ERROR).
-   **Security**: Includes path traversal protection, input validation, restriction of files to `.conf` extensions, and use of `exec.Command` with direct arguments to prevent command injection. `ipset` naming uses SHA256 hashes to avoid collisions.
-   **Tunnel Persistence**: Automatically restores tunnel running states after reboots/restarts, saving state to `/var/lib/amneziawg/tunnel-state.json`.
-   **Fault-Tolerant Monitoring**: Implements health checks via periodic pings through tunnel interfaces, smart restart logic, automatic failover to direct routing, and recovery mechanisms with configurable parameters.
-   **Localization**: Comprehensive EN/RU localization system with client-side i18n, automatic browser language detection, a language switcher, and persistent user preferences saved to `localStorage`.
-   **Code Quality**: Centralized utility functions in a `utils` package, atomic file write operations, and refactored handlers for maintainability.
-   **Network Interface State Normalization**: Robust logic to accurately report network interface UP/DOWN states based on administrative and carrier flags.
-   **Production Readiness**: No debug output, hardcoded values, or mock data; dynamic interface detection and GeoIP integration for tunnel and connection locations.

## External Dependencies

-   **Go 1.24**: Backend programming language.
-   **Tabler.io 1.4.0**: Frontend UI framework (includes Bootstrap 5).
-   **jsVectorMap 1.5.3**: JavaScript library for interactive world map visualization.
-   **`awg-quick` and `awg` commands**: External utilities for AmneziaWG tunnel control.
-   **`nftables`**: Linux kernel packet filtering framework for firewall management.
-   **`sysctl`**: Utility for modifying kernel parameters, used for IP forwarding.
-   **`ipset`**: IP sets for efficient routing rules management.