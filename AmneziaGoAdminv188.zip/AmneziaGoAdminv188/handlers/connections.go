package handlers

import (
        "encoding/json"
        "fmt"
        "io"
        "net"
        "net/http"
        "os/exec"
        "regexp"
        "strings"
        "sync"
        "time"

        "amneziawg-manager/logger"
)

type Connection struct {
        DeviceName    string `json:"device_name"`
        DeviceType    string `json:"device_type"`
        SourceIP      string `json:"source_ip"`
        SourceCountry string `json:"source_country"`
        DestIP        string `json:"dest_ip"`
        DestCountry   string `json:"dest_country"`
        Protocol      string `json:"protocol"`
        Status        string `json:"status"`
}

type MapMarker struct {
        Coords []float64 `json:"coords"`
        Name   string    `json:"name"`
}

type MapLine struct {
        From  string                 `json:"from"`
        To    string                 `json:"to"`
        Style map[string]interface{} `json:"style,omitempty"`
}

type ConnectionsMapResponse struct {
        Markers     []MapMarker  `json:"markers"`
        Lines       []MapLine    `json:"lines"`
        Connections []Connection `json:"connections"`
}

type IPLocation struct {
        IP        string
        Country   string
        City      string
        Latitude  float64
        Longitude float64
}

type ActiveConnection struct {
        LocalIP    string
        RemoteIP   string
        RemotePort string
        Protocol   string
        State      string
}

func APIConnectionsMapHandler(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")

        activeConns := getActiveNetworkConnections()
        
        response := ConnectionsMapResponse{
                Markers:     getMapMarkersFromConnections(activeConns),
                Lines:       getMapLinesFromConnections(activeConns),
                Connections: getActiveConnections(),
        }

        respondJSON(w, response)
}

func getMapMarkersFromConnections(activeConns []ActiveConnection) []MapMarker {
        markers := []MapMarker{}

        localIP := getLocalIP()
        if localIP != "" {
                location := getIPGeolocation(localIP)
                coords := []float64{0, 0}
                locationName := "Local Network"
                
                if location.Latitude != 0 && location.Longitude != 0 {
                        coords = []float64{location.Latitude, location.Longitude}
                        if location.City != "" {
                                locationName = location.City + " (Local)"
                        }
                } else {
                        logger.Log.Warn("failed to get geolocation for local IP, using default coordinates", "ip", localIP)
                }
                
                markers = append(markers, MapMarker{
                        Coords: coords,
                        Name:   locationName,
                })
        }

        processedIPs := make(map[string]bool)
        
        for _, conn := range activeConns {
                if processedIPs[conn.RemoteIP] {
                        continue
                }
                
                if isPrivateIP(conn.RemoteIP) {
                        continue
                }
                
                location := getIPGeolocation(conn.RemoteIP)
                if location.City != "" && location.Latitude != 0 && location.Longitude != 0 {
                        markers = append(markers, MapMarker{
                                Coords: []float64{location.Latitude, location.Longitude},
                                Name:   location.City,
                        })
                        
                        processedIPs[conn.RemoteIP] = true
                        
                        if len(markers) >= 11 {
                                break
                        }
                }
        }

        return markers
}

func getMapLinesFromConnections(activeConns []ActiveConnection) []MapLine {
        lines := []MapLine{}
        
        processedIPs := make(map[string]bool)
        
        colorScheme := []string{"#ef4444", "#10b981", "#f59e0b", "#8b5cf6", "#06b6d4", "#ec4899"}
        colorIndex := 0
        
        for _, conn := range activeConns {
                if processedIPs[conn.RemoteIP] {
                        continue
                }
                
                if isPrivateIP(conn.RemoteIP) {
                        continue
                }
                
                location := getIPGeolocation(conn.RemoteIP)
                if location.City != "" {
                        lines = append(lines, MapLine{
                                From: "Local Network",
                                To:   location.City,
                                Style: map[string]interface{}{
                                        "stroke":      colorScheme[colorIndex%len(colorScheme)],
                                        "strokeWidth": 2,
                                },
                        })
                        
                        processedIPs[conn.RemoteIP] = true
                        colorIndex++
                        
                        if len(lines) >= 10 {
                                break
                        }
                }
        }
        
        return lines
}

func getActiveConnections() []Connection {
        connections := []Connection{}

        dhcpClients := getDHCPClients()
        connections = append(connections, dhcpClients...)

        tunnelConns := getTunnelConnections()
        connections = append(connections, tunnelConns...)

        return connections
}

func getDHCPClients() []Connection {
        connections := []Connection{}

        cmd := exec.Command("cat", "/var/lib/dhcp/dhcpd.leases")
        output, err := cmd.Output()
        if err != nil {
                return connections
        }

        lines := strings.Split(string(output), "\n")
        var currentIP string
        var currentHostname string

        for _, line := range lines {
                line = strings.TrimSpace(line)
                
                if strings.HasPrefix(line, "lease ") {
                        parts := strings.Fields(line)
                        if len(parts) >= 2 {
                                currentIP = parts[1]
                        }
                }
                
                if strings.Contains(line, "client-hostname") {
                        parts := strings.Split(line, "\"")
                        if len(parts) >= 2 {
                                currentHostname = parts[1]
                        }
                }
                
                if currentIP != "" && currentHostname != "" {
                        connections = append(connections, Connection{
                                DeviceName:    currentHostname,
                                DeviceType:    "pc",
                                SourceIP:      currentIP,
                                SourceCountry: "",
                                DestIP:        "LAN",
                                DestCountry:   "",
                                Protocol:      "DHCP",
                                Status:        "direct",
                        })
                        currentIP = ""
                        currentHostname = ""
                }
        }

        return connections
}

func getTunnelConnections() []Connection {
        connections := []Connection{}

        activeConns := getActiveNetworkConnections()
        
        processedRemoteIPs := make(map[string]bool)
        
        for _, conn := range activeConns {
                if processedRemoteIPs[conn.RemoteIP] {
                        continue
                }
                
                if isPrivateIP(conn.RemoteIP) {
                        continue
                }
                
                hostname := getHostname(conn.RemoteIP)
                destDisplay := conn.RemoteIP
                if hostname != "" && hostname != conn.RemoteIP {
                        destDisplay = fmt.Sprintf("%s (%s)", conn.RemoteIP, hostname)
                }
                
                location := getIPGeolocation(conn.RemoteIP)
                
                connections = append(connections, Connection{
                        DeviceName:    "System",
                        DeviceType:    "server",
                        SourceIP:      conn.LocalIP,
                        SourceCountry: "",
                        DestIP:        destDisplay,
                        DestCountry:   location.Country,
                        Protocol:      conn.Protocol,
                        Status:        "established",
                })
                
                processedRemoteIPs[conn.RemoteIP] = true
                
                if len(connections) >= 10 {
                        break
                }
        }

        return connections
}

func getHostname(ip string) string {
        names, err := net.LookupAddr(ip)
        if err != nil || len(names) == 0 {
                return ""
        }
        
        hostname := strings.TrimSuffix(names[0], ".")
        return hostname
}

func getLocalIP() string {
        cmd := exec.Command("hostname", "-I")
        output, err := cmd.Output()
        if err != nil {
                return ""
        }

        ips := strings.Fields(string(output))
        if len(ips) > 0 {
                return ips[0]
        }

        return ""
}

func getActiveNetworkConnections() []ActiveConnection {
        connections := []ActiveConnection{}
        
        cmd := exec.Command("ss", "-tn", "state", "established")
        output, err := cmd.Output()
        if err != nil {
                return connections
        }
        
        lines := strings.Split(string(output), "\n")
        ipv4Regex := regexp.MustCompile(`(\d+\.\d+\.\d+\.\d+):(\d+)`)
        ipv6Regex := regexp.MustCompile(`\[([0-9a-fA-F:]+)\]:(\d+)`)
        
        for _, line := range lines {
                if !strings.Contains(line, "ESTAB") && !strings.Contains(line, ":") {
                        continue
                }
                
                protocol := "TCP"
                if strings.Contains(line, "udp") {
                        protocol = "UDP"
                }
                
                ipv4Matches := ipv4Regex.FindAllStringSubmatch(line, -1)
                if len(ipv4Matches) >= 2 {
                        localIP := ipv4Matches[0][1]
                        remoteIP := ipv4Matches[1][1]
                        remotePort := ipv4Matches[1][2]
                        
                        connections = append(connections, ActiveConnection{
                                LocalIP:    localIP,
                                RemoteIP:   remoteIP,
                                RemotePort: remotePort,
                                Protocol:   protocol,
                                State:      "ESTABLISHED",
                        })
                        continue
                }
                
                ipv6Matches := ipv6Regex.FindAllStringSubmatch(line, -1)
                if len(ipv6Matches) >= 2 {
                        localIP := ipv6Matches[0][1]
                        remoteIP := ipv6Matches[1][1]
                        remotePort := ipv6Matches[1][2]
                        
                        connections = append(connections, ActiveConnection{
                                LocalIP:    localIP,
                                RemoteIP:   remoteIP,
                                RemotePort: remotePort,
                                Protocol:   protocol,
                                State:      "ESTABLISHED",
                        })
                }
        }
        
        return connections
}

func isPrivateIP(ip string) bool {
        parsedIP := net.ParseIP(ip)
        if parsedIP == nil {
                return true
        }
        
        privateRanges := []string{
                "10.0.0.0/8",
                "172.16.0.0/12",
                "192.168.0.0/16",
                "127.0.0.0/8",
                "169.254.0.0/16",
                "::1/128",
                "fc00::/7",
                "fe80::/10",
        }
        
        for _, cidr := range privateRanges {
                _, network, err := net.ParseCIDR(cidr)
                if err != nil {
                        continue
                }
                if network.Contains(parsedIP) {
                        return true
                }
        }
        
        return false
}

var (
        geoCache     = make(map[string]IPLocation)
        geoCacheMu   sync.RWMutex
        cacheTimeout = 3600 * time.Second
)

func getIPGeolocation(ip string) IPLocation {
        geoCacheMu.RLock()
        if cached, exists := geoCache[ip]; exists {
                geoCacheMu.RUnlock()
                return cached
        }
        geoCacheMu.RUnlock()
        
        location := IPLocation{IP: ip}
        
        client := &http.Client{Timeout: cfg.External.GeoIPTimeout}
        resp, err := client.Get(fmt.Sprintf(cfg.External.GeoIPURL, ip))
        if err != nil {
                logger.Log.Debug("failed to fetch geolocation", "ip", ip, "error", err)
                return location
        }
        defer resp.Body.Close()
        
        body, err := io.ReadAll(resp.Body)
        if err != nil {
                logger.Log.Debug("failed to read geolocation response", "ip", ip, "error", err)
                return location
        }
        
        var result map[string]interface{}
        if err := json.Unmarshal(body, &result); err != nil {
                logger.Log.Debug("failed to parse geolocation response", "ip", ip, "error", err)
                return location
        }
        
        if status, ok := result["status"].(string); ok && status == "success" {
                if country, ok := result["country"].(string); ok {
                        location.Country = country
                }
                if city, ok := result["city"].(string); ok {
                        location.City = city
                }
                if lat, ok := result["lat"].(float64); ok {
                        location.Latitude = lat
                }
                if lon, ok := result["lon"].(float64); ok {
                        location.Longitude = lon
                }
                
                geoCacheMu.Lock()
                geoCache[ip] = location
                geoCacheMu.Unlock()
                
                go func(ipAddr string, timeout time.Duration) {
                        time.Sleep(timeout)
                        geoCacheMu.Lock()
                        delete(geoCache, ipAddr)
                        geoCacheMu.Unlock()
                }(ip, cacheTimeout)
        }
        
        return location
}
