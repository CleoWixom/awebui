
package handlers

import (
	"encoding/json"
	"fmt"
	"net/http"
	"os/exec"
	"sync"
	"time"
)

type TunnelMonitor struct {
	running    bool
	tunnels    map[string]*MonitoredTunnel
	mu         sync.RWMutex
	stopChan   chan bool
	checkInterval time.Duration
}

type MonitoredTunnel struct {
	Name           string    `json:"name"`
	Enabled        bool      `json:"enabled"`
	Status         string    `json:"status"`
	LastCheck      time.Time `json:"last_check"`
	LastHandshake  time.Time `json:"last_handshake"`
	FailCount      int       `json:"fail_count"`
	RestartCount   int       `json:"restart_count"`
	Issue          string    `json:"issue,omitempty"`
	InternetOk     bool      `json:"internet_ok"`
}

var globalMonitor = &TunnelMonitor{
	tunnels:       make(map[string]*MonitoredTunnel),
	checkInterval: 30 * time.Second,
	stopChan:      make(chan bool),
}

func StartTunnelMonitor() {
	globalMonitor.mu.Lock()
	if globalMonitor.running {
		globalMonitor.mu.Unlock()
		return
	}
	globalMonitor.running = true
	globalMonitor.mu.Unlock()

	go globalMonitor.monitorLoop()
}

func StopTunnelMonitor() {
	globalMonitor.mu.Lock()
	if !globalMonitor.running {
		globalMonitor.mu.Unlock()
		return
	}
	globalMonitor.running = false
	globalMonitor.mu.Unlock()
	globalMonitor.stopChan <- true
}

func (m *TunnelMonitor) monitorLoop() {
	ticker := time.NewTicker(m.checkInterval)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			m.checkAllTunnels()
		case <-m.stopChan:
			return
		}
	}
}

func (m *TunnelMonitor) checkAllTunnels() {
	tunnels, err := listTunnels()
	if err != nil {
		return
	}

	for _, tunnel := range tunnels {
		m.mu.RLock()
		monitored, exists := m.tunnels[tunnel.Name]
		m.mu.RUnlock()

		if !exists || !monitored.Enabled {
			continue
		}

		m.checkTunnel(tunnel.Name)
	}
}

func (m *TunnelMonitor) checkTunnel(name string) {
	m.mu.Lock()
	defer m.mu.Unlock()

	monitored := m.tunnels[name]
	if monitored == nil {
		return
	}

	monitored.LastCheck = time.Now()

	internetOk := checkInternetConnectivity()
	monitored.InternetOk = internetOk

	status := getTunnelStatus(name)
	monitored.Status = status

	if status == "down" {
		monitored.FailCount++
		
		if !internetOk {
			monitored.Issue = "No internet connectivity"
			return
		}

		details, err := getTunnelDetails(name)
		if err == nil && len(details.Peers) > 0 {
			peer := details.Peers[0]
			
			timeSinceHandshake := time.Since(peer.LatestHandshake)
			if timeSinceHandshake > 3*time.Minute {
				monitored.Issue = fmt.Sprintf("No handshake for %v", timeSinceHandshake.Round(time.Second))
			}
		}

		if monitored.FailCount >= 3 {
			fmt.Printf("Attempting to restart tunnel %s (fail count: %d)\n", name, monitored.FailCount)
			
			cmd := exec.Command("awg-quick", "down", name)
			cmd.Run()
			time.Sleep(2 * time.Second)
			
			cmd = exec.Command("awg-quick", "up", name)
			if err := cmd.Run(); err != nil {
				monitored.Issue = "Failed to restart: " + err.Error()
			} else {
				monitored.RestartCount++
				monitored.FailCount = 0
				monitored.Issue = ""
				
				config, _ := loadTunnelConfig(name)
				if config != nil {
					applyRoutingRules(config)
				}
			}
		}
	} else {
		if monitored.FailCount > 0 {
			monitored.Issue = ""
		}
		monitored.FailCount = 0
	}
}

func checkInternetConnectivity() bool {
	cmd := exec.Command("ping", "-c", "1", "-W", "2", "8.8.8.8")
	err := cmd.Run()
	return err == nil
}

func APIMonitorStatusHandler(w http.ResponseWriter, r *http.Request) {
	globalMonitor.mu.RLock()
	defer globalMonitor.mu.RUnlock()

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"running":  globalMonitor.running,
		"tunnels":  globalMonitor.tunnels,
		"interval": globalMonitor.checkInterval.Seconds(),
	})
}

func APIMonitorControlHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")

	var req struct {
		Action string `json:"action"`
	}

	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		json.NewEncoder(w).Encode(map[string]interface{}{
			"success": false,
			"message": "Invalid request",
		})
		return
	}

	switch req.Action {
	case "start":
		StartTunnelMonitor()
		json.NewEncoder(w).Encode(map[string]interface{}{
			"success": true,
			"message": "Monitor started",
		})
	case "stop":
		StopTunnelMonitor()
		json.NewEncoder(w).Encode(map[string]interface{}{
			"success": true,
			"message": "Monitor stopped",
		})
	default:
		json.NewEncoder(w).Encode(map[string]interface{}{
			"success": false,
			"message": "Invalid action",
		})
	}
}

func APIMonitorTunnelHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")

	var req struct {
		Name    string `json:"name"`
		Enabled bool   `json:"enabled"`
	}

	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		json.NewEncoder(w).Encode(map[string]interface{}{
			"success": false,
			"message": "Invalid request",
		})
		return
	}

	if err := validateTunnelName(req.Name); err != nil {
		json.NewEncoder(w).Encode(map[string]interface{}{
			"success": false,
			"message": err.Error(),
		})
		return
	}

	globalMonitor.mu.Lock()
	if req.Enabled {
		globalMonitor.tunnels[req.Name] = &MonitoredTunnel{
			Name:    req.Name,
			Enabled: true,
			Status:  getTunnelStatus(req.Name),
		}
	} else {
		if monitored, exists := globalMonitor.tunnels[req.Name]; exists {
			monitored.Enabled = false
		}
	}
	globalMonitor.mu.Unlock()

	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
		"message": fmt.Sprintf("Monitoring %s for %s", 
			map[bool]string{true: "enabled", false: "disabled"}[req.Enabled], req.Name),
	})
}
