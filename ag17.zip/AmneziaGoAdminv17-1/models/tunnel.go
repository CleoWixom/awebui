package models

import (
	"time"
)

type TunnelMode string

const (
	ModeNonGateway     TunnelMode = "non-gateway"      // Can run multiple, supports split routing
	ModeDefaultGateway TunnelMode = "default-gateway"  // Only one can run
)

type RoutingAction string

const (
	ActionDirect   RoutingAction = "direct"    // Direct connection
	ActionTunnel   RoutingAction = "tunnel"    // Forward to selected tunnel
	ActionBlock    RoutingAction = "block"     // Block traffic
)

type Tunnel struct {
	Name        string     `json:"name"`
	Interface   string     `json:"interface"`
	Address     string     `json:"address"`
	ListenPort  int        `json:"listen_port"`
	PrivateKey  string     `json:"private_key"`
	PublicKey   string     `json:"public_key"`
	Status      string     `json:"status"`
	Mode        TunnelMode `json:"mode"`
	LastUpdated time.Time  `json:"last_updated"`
	ServerIP    string     `json:"server_ip,omitempty"`
	Country     string     `json:"country,omitempty"`
	Peers       []Peer     `json:"peers,omitempty"`
	Routes      []Route    `json:"routes,omitempty"`
}

type Route struct {
	ID            string        `json:"id"`
	Name          string        `json:"name"`
	FilterFile    string        `json:"filter_file"`    // Path to CIDR/IP list file
	Action        RoutingAction `json:"action"`
	TargetTunnel  string        `json:"target_tunnel,omitempty"` // For ActionTunnel
	Priority      int           `json:"priority"`
	Enabled       bool          `json:"enabled"`
}

type Peer struct {
	PublicKey         string    `json:"public_key"`
	AllowedIPs        string    `json:"allowed_ips"`
	Endpoint          string    `json:"endpoint"`
	LatestHandshake   time.Time `json:"latest_handshake,omitempty"`
	TransferRx        int64     `json:"transfer_rx"`
	TransferTx        int64     `json:"transfer_tx"`
	PersistentKeepalive int     `json:"persistent_keepalive,omitempty"`
}

type ConfigFile struct {
	Name    string    `json:"name"`
	Path    string    `json:"path"`
	Content string    `json:"content"`
	Size    int64     `json:"size"`
	ModTime time.Time `json:"mod_time"`
}