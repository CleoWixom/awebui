package handlers

import (
        "context"
        "encoding/json"
        "fmt"
        "os"
        "os/exec"
        "path/filepath"
        "sync"
        "time"

        "amneziawg-manager/logger"
        "amneziawg-manager/utils"
)

// TunnelState represents the saved state of tunnels
type TunnelState struct {
        RunningTunnels []string  `json:"running_tunnels"`
        LastUpdated    time.Time `json:"last_updated"`
}

var (
        stateMutex sync.RWMutex
)

// SaveTunnelState saves the current state of running tunnels to disk
func SaveTunnelState(tunnelName string, isUp bool) error {
        stateMutex.Lock()
        defer stateMutex.Unlock()

        // Read current state
        state, err := readStateFile()
        if err != nil {
                // If file doesn't exist, create new state
                state = &TunnelState{
                        RunningTunnels: []string{},
                        LastUpdated:    time.Now(),
                }
        }

        // Update state based on action
        if isUp {
                // Add tunnel if not already in the list
                if !utils.Contains(state.RunningTunnels, tunnelName) {
                        state.RunningTunnels = append(state.RunningTunnels, tunnelName)
                }
        } else {
                // Remove tunnel from the list
                state.RunningTunnels = utils.RemoveString(state.RunningTunnels, tunnelName)
        }

        state.LastUpdated = time.Now()

        // Write updated state to file
        return writeStateFile(state)
}

// RestoreTunnelStates restores previously running tunnels on startup
func RestoreTunnelStates() {
        logger.Log.Info("restoring tunnel states")
        
        stateMutex.RLock()
        state, err := readStateFile()
        stateMutex.RUnlock()
        
        if err != nil {
                logger.Log.Info("no tunnel state to restore", "error", err)
                return
        }

        if len(state.RunningTunnels) == 0 {
                logger.Log.Info("no tunnels to restore")
                return
        }

        logger.Log.Info("restoring tunnels", "count", len(state.RunningTunnels))
        
        for _, tunnelName := range state.RunningTunnels {
                // Restore each tunnel with a delay to avoid overwhelming the system
                go func(name string) {
                        time.Sleep(500 * time.Millisecond) // Small delay between tunnel starts
                        
                        if err := restoreTunnel(name); err != nil {
                                logger.Log.Error("failed to restore tunnel", "tunnel", name, "error", err)
                        } else {
                                logger.Log.Info("tunnel restored successfully", "tunnel", name)
                        }
                }(tunnelName)
        }
}

// restoreTunnel brings up a single tunnel
func restoreTunnel(tunnelName string) error {
        // Load tunnel config to check mode and routing rules
        config, err := loadTunnelConfig(tunnelName)
        if err != nil {
                logger.Log.Warn("failed to load tunnel config during restore", "tunnel", tunnelName, "error", err)
                // Continue anyway, try to bring up the tunnel without routing rules
        }

        // Check for default gateway conflict before starting
        if config != nil && config.Mode == "default-gateway" {
                conflict, err := checkDefaultGatewayConflict(tunnelName)
                if err != nil {
                        return fmt.Errorf("failed to check default gateway conflict: %v", err)
                }
                if conflict {
                        logger.Log.Warn("skipping tunnel restore due to default gateway conflict", "tunnel", tunnelName)
                        return fmt.Errorf("another default gateway tunnel is already running")
                }
        }

        // Bring up the tunnel using awg-quick
        ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
        defer cancel()
        
        cmd := exec.CommandContext(ctx, "awg-quick", "up", tunnelName)
        output, err := cmd.CombinedOutput()
        if err != nil {
                return fmt.Errorf("awg-quick failed: %v, output: %s", err, string(output))
        }

        // Apply routing rules if configured
        if config != nil {
                if err := applyRoutingRules(config); err != nil {
                        logger.Log.Error("failed to apply routing rules during restore", "tunnel", tunnelName, "error", err)
                        // Don't fail the restore, just log the error
                }
        }

        return nil
}

// readStateFile reads the tunnel state from disk
func readStateFile() (*TunnelState, error) {
        stateFile := cfg.Paths.StateFile
        
        data, err := os.ReadFile(stateFile)
        if err != nil {
                return nil, err
        }

        var state TunnelState
        if err := json.Unmarshal(data, &state); err != nil {
                return nil, err
        }

        return &state, nil
}

// writeStateFile writes the tunnel state to disk
func writeStateFile(state *TunnelState) error {
        stateFile := cfg.Paths.StateFile
        
        // Create directory if it doesn't exist
        dir := filepath.Dir(stateFile)
        if err := os.MkdirAll(dir, 0755); err != nil {
                return fmt.Errorf("failed to create state directory: %v", err)
        }

        data, err := json.MarshalIndent(state, "", "  ")
        if err != nil {
                return err
        }

        if err := utils.AtomicWriteFile(stateFile, data, 0600); err != nil {
                return err
        }

        logger.Log.Debug("tunnel state saved", "file", stateFile)
        return nil
}
