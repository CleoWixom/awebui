
package handlers

import (
        "context"
        "encoding/json"
        "fmt"
        "net/http"
        "os/exec"
        "sync"
        "time"

        "amneziawg-manager/logger"
)

type TunnelMonitor struct {
        running    bool
        tunnels    map[string]*MonitoredTunnel
        mu         sync.RWMutex
        stopChan   chan bool
        checkInterval time.Duration
}

type MonitoredTunnel struct {
        Name              string    `json:"name"`
        Enabled           bool      `json:"enabled"`
        Status            string    `json:"status"`
        LastCheck         time.Time `json:"last_check"`
        LastHandshake     time.Time `json:"last_handshake"`
        FailCount         int       `json:"fail_count"`
        RestartCount      int       `json:"restart_count"`
        Issue             string    `json:"issue,omitempty"`
        InternetOk        bool      `json:"internet_ok"`
        TunnelHealthy     bool      `json:"tunnel_healthy"`
        LastPingCheck     time.Time `json:"last_ping_check"`
        PingFailCount     int       `json:"ping_fail_count"`
        InFallbackMode    bool      `json:"in_fallback_mode"`
        FallbackSince     time.Time `json:"fallback_since,omitempty"`
        TotalRestarts     int       `json:"total_restarts"`
        RoutingApplied    bool      `json:"routing_applied"`
}

var globalMonitor *TunnelMonitor

func initMonitor() {
        if globalMonitor == nil {
                globalMonitor = &TunnelMonitor{
                        tunnels:       make(map[string]*MonitoredTunnel),
                        checkInterval: cfg.Monitor.CheckInterval,
                        stopChan:      make(chan bool),
                }
        }
}

func StartTunnelMonitor() {
        initMonitor()
        globalMonitor.mu.Lock()
        if globalMonitor.running {
                globalMonitor.mu.Unlock()
                return
        }
        globalMonitor.running = true
        globalMonitor.mu.Unlock()

        logger.Log.Info("tunnel monitor started", "check_interval", cfg.Monitor.CheckInterval)
        go globalMonitor.monitorLoop()
}

func StopTunnelMonitor() {
        globalMonitor.mu.Lock()
        if !globalMonitor.running {
                globalMonitor.mu.Unlock()
                return
        }
        globalMonitor.running = false
        globalMonitor.mu.Unlock()
        globalMonitor.stopChan <- true
}

func (m *TunnelMonitor) monitorLoop() {
        ticker := time.NewTicker(m.checkInterval)
        defer ticker.Stop()

        for {
                select {
                case <-ticker.C:
                        m.checkAllTunnels()
                case <-m.stopChan:
                        return
                }
        }
}

func (m *TunnelMonitor) checkAllTunnels() {
        tunnels, err := listTunnels()
        if err != nil {
                logger.Log.Error("failed to list tunnels in monitor", "error", err)
                return
        }

        for _, tunnel := range tunnels {
                m.mu.RLock()
                monitored, exists := m.tunnels[tunnel.Name]
                m.mu.RUnlock()

                if !exists || !monitored.Enabled {
                        continue
                }

                m.checkTunnel(tunnel.Name)
        }
}

func (m *TunnelMonitor) checkTunnel(name string) {
        m.mu.Lock()
        defer m.mu.Unlock()

        monitored := m.tunnels[name]
        if monitored == nil {
                return
        }

        monitored.LastCheck = time.Now()

        internetOk := checkInternetConnectivity()
        monitored.InternetOk = internetOk

        if !internetOk {
                monitored.Issue = "No internet connectivity"
                return
        }

        if monitored.InFallbackMode {
                if time.Since(monitored.FallbackSince) >= cfg.Monitor.FallbackTimeout {
                        logger.Log.Info("attempting recovery from fallback mode", "tunnel", name, 
                                "time_in_fallback", time.Since(monitored.FallbackSince).Round(time.Second))
                        
                        if attemptRecovery(m, monitored, name) {
                                return
                        }
                        
                        monitored.FallbackSince = time.Now()
                }
                return
        }

        status := getTunnelStatus(name)
        monitored.Status = status

        if status == "down" {
                monitored.TunnelHealthy = false
                monitored.FailCount++
                
                details, err := getTunnelDetails(name)
                if err == nil && len(details.Peers) > 0 {
                        peer := details.Peers[0]
                        timeSinceHandshake := time.Since(peer.LatestHandshake)
                        if timeSinceHandshake > cfg.Monitor.HandshakeThreshold {
                                monitored.Issue = fmt.Sprintf("No handshake for %v", timeSinceHandshake.Round(time.Second))
                        }
                }

                if monitored.FailCount >= cfg.Monitor.FailCountThreshold {
                        if monitored.TotalRestarts >= cfg.Monitor.MaxRestartAttempts {
                                enterFallbackMode(m, monitored, name)
                                return
                        }

                        logger.Log.Info("attempting to restart tunnel", "tunnel", name, 
                                "fail_count", monitored.FailCount, 
                                "total_restarts", monitored.TotalRestarts)
                        
                        ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
                        cmd := exec.CommandContext(ctx, "awg-quick", "down", name)
                        if err := cmd.Run(); err != nil {
                                logger.Log.Warn("failed to bring tunnel down before restart", "tunnel", name, "error", err)
                        }
                        cancel()
                        time.Sleep(cfg.Monitor.RestartDelay)
                        
                        ctx, cancel = context.WithTimeout(context.Background(), 30*time.Second)
                        cmd = exec.CommandContext(ctx, "awg-quick", "up", name)
                        if err := cmd.Run(); err != nil {
                                monitored.Issue = "Failed to restart: " + err.Error()
                                logger.Log.Error("tunnel restart failed", "tunnel", name, "error", err)
                                monitored.TotalRestarts++
                                cancel()
                        } else {
                                cancel()
                                monitored.RestartCount++
                                monitored.TotalRestarts++
                                monitored.FailCount = 0
                                
                                time.Sleep(2 * time.Second)
                                
                                details, err := getTunnelDetails(name)
                                if err != nil {
                                        logger.Log.Warn("failed to get tunnel details after restart", "tunnel", name, "error", err)
                                        return
                                }
                                
                                if checkTunnelConnectivity(details.Interface) {
                                        logger.Log.Info("tunnel restarted and connectivity verified", "tunnel", name, 
                                                "restart_count", monitored.RestartCount,
                                                "total_restarts", monitored.TotalRestarts)
                                        
                                        config, err := loadTunnelConfig(name)
                                        if err != nil {
                                                logger.Log.Warn("failed to load tunnel config after restart", "tunnel", name, "error", err)
                                        } else if config != nil {
                                                if err := applyRoutingRules(config); err != nil {
                                                        logger.Log.Error("failed to apply routing rules after restart", "tunnel", name, "error", err)
                                                } else {
                                                        monitored.RoutingApplied = true
                                                        monitored.TunnelHealthy = true
                                                        monitored.Issue = ""
                                                        logger.Log.Info("routing rules applied successfully", "tunnel", name)
                                                }
                                        }
                                } else {
                                        logger.Log.Warn("tunnel restarted but connectivity check failed", "tunnel", name)
                                        monitored.Issue = "Tunnel up but connectivity check failed"
                                        monitored.TunnelHealthy = false
                                }
                        }
                }
        } else {
                details, err := getTunnelDetails(name)
                if err != nil {
                        logger.Log.Warn("failed to get tunnel details", "tunnel", name, "error", err)
                        return
                }

                if time.Since(monitored.LastPingCheck) >= cfg.Monitor.TunnelPingInterval {
                        monitored.LastPingCheck = time.Now()
                        
                        if checkTunnelConnectivity(details.Interface) {
                                monitored.TunnelHealthy = true
                                monitored.PingFailCount = 0
                                
                                if monitored.FailCount > 0 || monitored.Issue != "" {
                                        monitored.Issue = ""
                                }
                                monitored.FailCount = 0
                        } else {
                                monitored.TunnelHealthy = false
                                monitored.PingFailCount++
                                monitored.Issue = fmt.Sprintf("Tunnel connectivity check failed (fail count: %d)", monitored.PingFailCount)
                                logger.Log.Warn("tunnel connectivity check failed", "tunnel", name, "ping_fail_count", monitored.PingFailCount)
                                
                                if monitored.PingFailCount >= cfg.Monitor.FailCountThreshold {
                                        monitored.FailCount = cfg.Monitor.FailCountThreshold
                                }
                        }
                }
        }
}

func checkInternetConnectivity() bool {
        timeout := fmt.Sprintf("%.0f", cfg.Monitor.ConnectivityTimeout.Seconds())
        ctx, cancel := context.WithTimeout(context.Background(), cfg.Monitor.ConnectivityTimeout+5*time.Second)
        defer cancel()
        cmd := exec.CommandContext(ctx, "ping", "-c", "1", "-W", timeout, cfg.Monitor.ConnectivityHost)
        err := cmd.Run()
        return err == nil
}

func checkTunnelConnectivity(interfaceName string) bool {
        if interfaceName == "" {
                return false
        }
        
        timeout := fmt.Sprintf("%.0f", cfg.Monitor.TunnelPingTimeout.Seconds())
        ctx, cancel := context.WithTimeout(context.Background(), cfg.Monitor.TunnelPingTimeout+5*time.Second)
        defer cancel()
        cmd := exec.CommandContext(ctx, "ping", "-I", interfaceName, "-c", "1", "-W", timeout, cfg.Monitor.TunnelPingHost)
        err := cmd.Run()
        
        if err != nil {
                logger.Log.Debug("tunnel ping failed", "interface", interfaceName, "host", cfg.Monitor.TunnelPingHost, "error", err)
                return false
        }
        
        logger.Log.Debug("tunnel ping successful", "interface", interfaceName, "host", cfg.Monitor.TunnelPingHost)
        return true
}

func enterFallbackMode(m *TunnelMonitor, monitored *MonitoredTunnel, tunnelName string) {
        if monitored.InFallbackMode {
                return
        }
        
        logger.Log.Warn("entering fallback mode - removing routing rules to preserve internet", 
                "tunnel", tunnelName, 
                "total_restarts", monitored.TotalRestarts,
                "fail_count", monitored.FailCount)
        
        config, err := loadTunnelConfig(tunnelName)
        if err == nil && config != nil {
                if err := clearRoutingRules(config); err != nil {
                        logger.Log.Error("failed to clear routing rules for fallback", "tunnel", tunnelName, "error", err)
                }
        }
        
        monitored.InFallbackMode = true
        monitored.FallbackSince = time.Now()
        monitored.RoutingApplied = false
        monitored.Issue = "Fallback mode: routing disabled, using direct connection"
}

func attemptRecovery(m *TunnelMonitor, monitored *MonitoredTunnel, tunnelName string) bool {
        logger.Log.Info("attempting tunnel recovery from fallback mode", "tunnel", tunnelName)
        
        ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
        cmd := exec.CommandContext(ctx, "awg-quick", "down", tunnelName)
        if err := cmd.Run(); err != nil {
                logger.Log.Warn("failed to bring tunnel down during recovery", "tunnel", tunnelName, "error", err)
        }
        cancel()
        time.Sleep(cfg.Monitor.RestartDelay)
        
        ctx, cancel = context.WithTimeout(context.Background(), 30*time.Second)
        defer cancel()
        cmd = exec.CommandContext(ctx, "awg-quick", "up", tunnelName)
        if err := cmd.Run(); err != nil {
                logger.Log.Error("tunnel restart failed during recovery", "tunnel", tunnelName, "error", err)
                return false
        }
        
        time.Sleep(2 * time.Second)
        
        details, err := getTunnelDetails(tunnelName)
        if err != nil {
                logger.Log.Error("failed to get tunnel details after recovery", "tunnel", tunnelName, "error", err)
                return false
        }
        
        if !checkTunnelConnectivity(details.Interface) {
                logger.Log.Warn("tunnel connectivity check failed after recovery", "tunnel", tunnelName)
                return false
        }
        
        config, err := loadTunnelConfig(tunnelName)
        if err != nil {
                logger.Log.Warn("failed to load tunnel config during recovery", "tunnel", tunnelName, "error", err)
                return false
        }
        
        if config != nil {
                if err := applyRoutingRules(config); err != nil {
                        logger.Log.Error("failed to apply routing rules during recovery", "tunnel", tunnelName, "error", err)
                        return false
                }
        }
        
        logger.Log.Info("tunnel recovered successfully", "tunnel", tunnelName)
        monitored.InFallbackMode = false
        monitored.FallbackSince = time.Time{}
        monitored.RoutingApplied = true
        monitored.FailCount = 0
        monitored.PingFailCount = 0
        monitored.Issue = ""
        monitored.TunnelHealthy = true
        
        return true
}

func APIMonitorStatusHandler(w http.ResponseWriter, r *http.Request) {
        globalMonitor.mu.RLock()
        defer globalMonitor.mu.RUnlock()

        w.Header().Set("Content-Type", "application/json")
        if err := json.NewEncoder(w).Encode(map[string]interface{}{
                "running":  globalMonitor.running,
                "tunnels":  globalMonitor.tunnels,
                "interval": globalMonitor.checkInterval.Seconds(),
        }); err != nil {
                logger.Log.Error("failed to encode monitor status response", "error", err)
        }
}

func APIMonitorControlHandler(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")

        var req struct {
                Action string `json:"action"`
        }

        if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
                respondError(w, http.StatusBadRequest, "Invalid request")
                return
        }

        switch req.Action {
        case "start":
                StartTunnelMonitor()
                respondSuccess(w, "Monitor started")
        case "stop":
                StopTunnelMonitor()
                respondSuccess(w, "Monitor stopped")
        default:
                respondError(w, http.StatusBadRequest, "Invalid action")
        }
}

func APIMonitorTunnelHandler(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")

        var req struct {
                Name    string `json:"name"`
                Enabled bool   `json:"enabled"`
        }

        if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
                respondError(w, http.StatusBadRequest, "Invalid request")
                return
        }

        if err := validateTunnelName(req.Name); err != nil {
                respondError(w, http.StatusBadRequest, err.Error())
                return
        }

        globalMonitor.mu.Lock()
        if req.Enabled {
                globalMonitor.tunnels[req.Name] = &MonitoredTunnel{
                        Name:    req.Name,
                        Enabled: true,
                        Status:  getTunnelStatus(req.Name),
                }
        } else {
                if monitored, exists := globalMonitor.tunnels[req.Name]; exists {
                        monitored.Enabled = false
                }
        }
        globalMonitor.mu.Unlock()

        respondSuccess(w, fmt.Sprintf("Monitoring %s for %s", 
                map[bool]string{true: "enabled", false: "disabled"}[req.Enabled], req.Name))
}
