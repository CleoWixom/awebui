
package handlers

import (
	"encoding/json"
	"fmt"
	"html/template"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
)

const NetworkConfigDir = "./config/network"

type DNSConfig struct {
	Resolver   string   `json:"resolver"`
	Servers    []string `json:"servers"`
	DNSSEC     bool     `json:"dnssec"`
	DNSOverTLS bool     `json:"dns_over_tls"`
	MDNS       bool     `json:"mdns"`
}

type DHCPServerConfig struct {
	Interface  string `json:"interface"`
	RangeStart string `json:"range_start"`
	RangeEnd   string `json:"range_end"`
	Netmask    string `json:"netmask"`
	Gateway    string `json:"gateway"`
	LeaseTime  int    `json:"lease_time"`
}

type DHCPRelayConfig struct {
	Server     string   `json:"server"`
	Interfaces []string `json:"interfaces"`
}

type DHCPConfig struct {
	Mode   string            `json:"mode"`
	Server *DHCPServerConfig `json:"server,omitempty"`
	Relay  *DHCPRelayConfig  `json:"relay,omitempty"`
}

type NetworkConfig struct {
	DNS  *DNSConfig  `json:"dns,omitempty"`
	DHCP *DHCPConfig `json:"dhcp,omitempty"`
}

func NetworkPageHandler(w http.ResponseWriter, r *http.Request) {
	tmpl := template.Must(template.ParseFiles("templates/network.html", "templates/layout.html"))
	tmpl.ExecuteTemplate(w, "layout", nil)
}

func APIGetNetworkConfigHandler(w http.ResponseWriter, r *http.Request) {
	configPath := filepath.Join(NetworkConfigDir, "config.json")
	
	var config NetworkConfig
	if data, err := os.ReadFile(configPath); err == nil {
		json.Unmarshal(data, &config)
	} else {
		config = NetworkConfig{}
	}
	
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(config)
}

func APISaveDNSConfigHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	
	var dnsConfig DNSConfig
	if err := json.NewDecoder(r.Body).Decode(&dnsConfig); err != nil {
		json.NewEncoder(w).Encode(map[string]interface{}{
			"success": false,
			"message": "Invalid request: " + err.Error(),
		})
		return
	}
	
	if err := os.MkdirAll(NetworkConfigDir, 0755); err != nil {
		json.NewEncoder(w).Encode(map[string]interface{}{
			"success": false,
			"message": "Failed to create config directory: " + err.Error(),
		})
		return
	}
	
	configPath := filepath.Join(NetworkConfigDir, "config.json")
	var fullConfig NetworkConfig
	if data, err := os.ReadFile(configPath); err == nil {
		json.Unmarshal(data, &fullConfig)
	}
	fullConfig.DNS = &dnsConfig
	
	data, _ := json.MarshalIndent(fullConfig, "", "  ")
	if err := os.WriteFile(configPath, data, 0600); err != nil {
		json.NewEncoder(w).Encode(map[string]interface{}{
			"success": false,
			"message": "Failed to save configuration: " + err.Error(),
		})
		return
	}
	
	if err := applyDNSConfig(&dnsConfig); err != nil {
		json.NewEncoder(w).Encode(map[string]interface{}{
			"success": false,
			"message": "Configuration saved but failed to apply: " + err.Error(),
		})
		return
	}
	
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
		"message": "DNS configuration saved and applied successfully",
	})
}

func APISaveDHCPConfigHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	
	var dhcpConfig DHCPConfig
	if err := json.NewDecoder(r.Body).Decode(&dhcpConfig); err != nil {
		json.NewEncoder(w).Encode(map[string]interface{}{
			"success": false,
			"message": "Invalid request: " + err.Error(),
		})
		return
	}
	
	if err := os.MkdirAll(NetworkConfigDir, 0755); err != nil {
		json.NewEncoder(w).Encode(map[string]interface{}{
			"success": false,
			"message": "Failed to create config directory: " + err.Error(),
		})
		return
	}
	
	configPath := filepath.Join(NetworkConfigDir, "config.json")
	var fullConfig NetworkConfig
	if data, err := os.ReadFile(configPath); err == nil {
		json.Unmarshal(data, &fullConfig)
	}
	fullConfig.DHCP = &dhcpConfig
	
	data, _ := json.MarshalIndent(fullConfig, "", "  ")
	if err := os.WriteFile(configPath, data, 0600); err != nil {
		json.NewEncoder(w).Encode(map[string]interface{}{
			"success": false,
			"message": "Failed to save configuration: " + err.Error(),
		})
		return
	}
	
	if err := applyDHCPConfig(&dhcpConfig); err != nil {
		json.NewEncoder(w).Encode(map[string]interface{}{
			"success": false,
			"message": "Configuration saved but failed to apply: " + err.Error(),
		})
		return
	}
	
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
		"message": "DHCP configuration saved and applied successfully",
	})
}

func APIGetDNSStatusHandler(w http.ResponseWriter, r *http.Request) {
	cmd := exec.Command("resolvectl", "status")
	output, err := cmd.CombinedOutput()
	if err != nil {
		cmd = exec.Command("cat", "/etc/resolv.conf")
		output, _ = cmd.Output()
	}
	
	w.Header().Set("Content-Type", "text/plain")
	w.Write(output)
}

func applyDNSConfig(config *DNSConfig) error {
	if config.Resolver == "systemd-resolved" {
		var conf strings.Builder
		conf.WriteString("[Resolve]\n")
		if len(config.Servers) > 0 {
			conf.WriteString("DNS=" + strings.Join(config.Servers, " ") + "\n")
		}
		if config.DNSSEC {
			conf.WriteString("DNSSEC=yes\n")
		}
		if config.DNSOverTLS {
			conf.WriteString("DNSOverTLS=yes\n")
		}
		if config.MDNS {
			conf.WriteString("MulticastDNS=yes\n")
		}
		
		if err := os.WriteFile("/etc/systemd/resolved.conf.d/custom.conf", []byte(conf.String()), 0644); err != nil {
			return err
		}
		
		exec.Command("systemctl", "restart", "systemd-resolved").Run()
	} else {
		var conf strings.Builder
		for _, server := range config.Servers {
			conf.WriteString("nameserver " + server + "\n")
		}
		
		if err := os.WriteFile("/etc/resolv.conf", []byte(conf.String()), 0644); err != nil {
			return err
		}
	}
	
	return nil
}

func applyDHCPConfig(config *DHCPConfig) error {
	if config.Mode == "server" && config.Server != nil {
		var conf strings.Builder
		conf.WriteString(fmt.Sprintf("subnet %s netmask %s {\n", 
			config.Server.RangeStart, config.Server.Netmask))
		conf.WriteString(fmt.Sprintf("  range %s %s;\n", 
			config.Server.RangeStart, config.Server.RangeEnd))
		conf.WriteString(fmt.Sprintf("  option routers %s;\n", config.Server.Gateway))
		conf.WriteString(fmt.Sprintf("  default-lease-time %d;\n", config.Server.LeaseTime))
		conf.WriteString("}\n")
		
		if err := os.WriteFile("/etc/dhcp/dhcpd.conf", []byte(conf.String()), 0644); err != nil {
			return err
		}
		
		exec.Command("systemctl", "restart", "isc-dhcp-server").Run()
	} else if config.Mode == "relay" && config.Relay != nil {
		args := []string{"-d", config.Relay.Server}
		args = append(args, config.Relay.Interfaces...)
		
		exec.Command("systemctl", "stop", "isc-dhcp-server").Run()
		exec.Command("dhcrelay", args...).Start()
	} else {
		exec.Command("systemctl", "stop", "isc-dhcp-server").Run()
	}
	
	return nil
}
