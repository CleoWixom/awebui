# Инструкция по установке AmneziaWG Manager

## Требования

- DietPI или любой Linux дистрибутив с systemd
- Go 1.24 или новее (только для сборки)
- Установленные утилиты: `awg`, `awg-quick`, `nftables`, `ipset`
- Root права для установки

## Быстрая установка

### 1. Сборка и установка

```bash
# Сборка бинарного файла
make build

# Установка в систему (требует root)
sudo make install
```

### 2. Включение и запуск сервиса

```bash
# Включить автозапуск при старте системы
sudo make enable

# Запустить сервис
sudo make start

# Проверить статус
sudo make status
```

### 3. Доступ к веб-интерфейсу

Откройте в браузере: `http://your-server-ip:5000`

## Детальные команды Makefile

### Сборка

```bash
# Собрать бинарный файл
make build

# Очистить артефакты сборки
make clean
```

### Установка/Удаление

```bash
# Установить приложение в систему
sudo make install

# Удалить приложение из системы (сохраняет конфигурационные файлы)
sudo make uninstall
```

### Управление сервисом

```bash
# Включить автозапуск
sudo make enable

# Отключить автозапуск
sudo make disable

# Запустить сервис
sudo make start

# Остановить сервис
sudo make stop

# Перезапустить сервис
sudo make restart

# Показать статус сервиса
sudo make status
```

## Структура установки

После установки файлы будут расположены:

- **Бинарный файл**: `/usr/local/bin/awg-manager`
- **Web ресурсы**: `/usr/local/share/amneziawg-manager/`
- **Конфигурация туннелей**: `/etc/amnezia/amneziawg/`
- **Правила маршрутизации**: `/etc/amnezia/routes/`
- **CIDR базы**: `/var/lib/amneziawg/cidrdbs/`
- **Сетевые настройки**: `/etc/amnezia/network/`
- **Systemd сервис**: `/etc/systemd/system/amneziawg-manager.service`

## Настройка сервиса

### Изменение порта или других параметров

Отредактируйте файл сервиса:

```bash
sudo nano /etc/systemd/system/amneziawg-manager.service
```

Найдите секцию `[Service]` и измените нужные переменные окружения, например:

```ini
Environment="SERVER_PORT=8080"
Environment="MONITOR_MAX_RESTART_ATTEMPTS=10"
```

После изменений:

```bash
sudo systemctl daemon-reload
sudo make restart
```

### Доступные переменные окружения

#### Сервер
- `SERVER_HOST` - IP адрес для прослушивания (по умолчанию: 0.0.0.0)
- `SERVER_PORT` - Порт сервера (по умолчанию: 5000)

#### Мониторинг туннелей
- `MONITOR_CHECK_INTERVAL` - Интервал проверки туннелей (по умолчанию: 30s)
- `MONITOR_TUNNEL_PING_HOST` - Хост для проверки связи через туннель (по умолчанию: 1.1.1.1)
- `MONITOR_TUNNEL_PING_INTERVAL` - Интервал ping через туннель (по умолчанию: 10s)
- `MONITOR_MAX_RESTART_ATTEMPTS` - Максимум попыток перезапуска (по умолчанию: 5)
- `MONITOR_FALLBACK_TIMEOUT` - Время в fallback режиме перед попыткой восстановления (по умолчанию: 5m)

Полный список параметров см. в файле `amneziawg-manager.service`

## Просмотр логов

```bash
# Просмотр логов в реальном времени
sudo journalctl -u amneziawg-manager -f

# Просмотр последних 100 строк логов
sudo journalctl -u amneziawg-manager -n 100

# Просмотр логов за сегодня
sudo journalctl -u amneziawg-manager --since today
```

## Обновление

```bash
# Остановить сервис
sudo make stop

# Собрать новую версию
make build

# Переустановить
sudo make install

# Запустить сервис
sudo make start
```

## Удаление

```bash
# Полностью удалить приложение
sudo make uninstall

# Удалить также конфигурационные файлы (опционально)
sudo rm -rf /etc/amnezia
sudo rm -rf /var/lib/amneziawg
```

## Troubleshooting

### Сервис не запускается

1. Проверьте логи:
```bash
sudo journalctl -u amneziawg-manager -n 50
```

2. Убедитесь, что порт 5000 свободен:
```bash
sudo netstat -tlnp | grep 5000
```

3. Проверьте права доступа:
```bash
ls -la /usr/local/bin/awg-manager
ls -la /usr/local/share/amneziawg-manager/
```

### Веб-интерфейс недоступен

1. Проверьте статус сервиса:
```bash
sudo make status
```

2. Проверьте firewall:
```bash
sudo iptables -L -n | grep 5000
# или для nftables
sudo nft list ruleset | grep 5000
```

3. Откройте порт если нужно:
```bash
# Для iptables
sudo iptables -A INPUT -p tcp --dport 5000 -j ACCEPT

# Для nftables
sudo nft add rule inet filter input tcp dport 5000 accept
```

## Безопасность

⚠️ **Важно**: Приложение работает с правами root, так как требуется управление сетевыми интерфейсами.

Рекомендации:
1. Используйте firewall для ограничения доступа к порту 5000
2. Настройте reverse proxy (nginx, caddy) с SSL/TLS
3. Используйте VPN или ограничьте доступ по IP

Пример настройки с nginx:

```nginx
server {
    listen 80;
    server_name awg.example.com;
    
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

## Поддержка

Для получения помощи:
- Создайте issue на GitHub
- Проверьте логи: `sudo journalctl -u amneziawg-manager -n 100`
- Убедитесь, что все зависимости установлены
