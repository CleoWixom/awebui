package renderer

import (
        "html/template"
        "net/http"
        "sync"

        "amneziawg-manager/config"
        "amneziawg-manager/logger"
)

type TemplateRenderer struct {
        cache        map[string]*template.Template
        cacheMutex   sync.RWMutex
        cacheEnabled bool
        templatesDir string
}

var (
        defaultRenderer *TemplateRenderer
        once            sync.Once
)

func Init(cfg *config.Config) {
        once.Do(func() {
                defaultRenderer = &TemplateRenderer{
                        cache:        make(map[string]*template.Template),
                        cacheEnabled: cfg.Template.CacheEnabled,
                        templatesDir: cfg.Paths.TemplatesDir,
                }
                logger.Log.Info("template renderer initialized", 
                        "cache_enabled", defaultRenderer.cacheEnabled,
                        "templates_dir", defaultRenderer.templatesDir)
        })
}

func GetRenderer() *TemplateRenderer {
        if defaultRenderer == nil {
                panic("renderer not initialized: call Init() first")
        }
        return defaultRenderer
}

func (tr *TemplateRenderer) getTemplate(name string, files ...string) (*template.Template, error) {
        if tr.cacheEnabled {
                tr.cacheMutex.RLock()
                tmpl, exists := tr.cache[name]
                tr.cacheMutex.RUnlock()
                
                if exists {
                        return tmpl, nil
                }
        }

        tmpl, err := template.ParseFiles(files...)
        if err != nil {
                return nil, err
        }

        if tr.cacheEnabled {
                tr.cacheMutex.Lock()
                tr.cache[name] = tmpl
                tr.cacheMutex.Unlock()
        }

        return tmpl, nil
}

func (tr *TemplateRenderer) RenderPage(w http.ResponseWriter, templateName string, layoutName string, data interface{}) error {
        templateFiles := []string{
                tr.templatesDir + "/" + templateName + ".html",
                tr.templatesDir + "/layout.html",
        }

        tmpl, err := tr.getTemplate(templateName, templateFiles...)
        if err != nil {
                logger.Log.Error("failed to parse template", "template", templateName, "error", err)
                http.Error(w, "Internal Server Error", http.StatusInternalServerError)
                return err
        }

        if err := tmpl.ExecuteTemplate(w, layoutName, data); err != nil {
                logger.Log.Error("failed to execute template", "template", templateName, "layout", layoutName, "error", err)
                http.Error(w, "Internal Server Error", http.StatusInternalServerError)
                return err
        }

        return nil
}

func (tr *TemplateRenderer) ClearCache() {
        if tr.cacheEnabled {
                tr.cacheMutex.Lock()
                tr.cache = make(map[string]*template.Template)
                tr.cacheMutex.Unlock()
                logger.Log.Info("template cache cleared")
        }
}

func (tr *TemplateRenderer) IsCacheEnabled() bool {
        return tr.cacheEnabled
}

func RenderPage(w http.ResponseWriter, templateName string, layoutName string, data interface{}) error {
        return GetRenderer().RenderPage(w, templateName, layoutName, data)
}

func ClearCache() {
        GetRenderer().ClearCache()
}

func IsCacheEnabled() bool {
        return GetRenderer().IsCacheEnabled()
}
