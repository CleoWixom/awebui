function setActiveNavItem() {
    const path = window.location.pathname;
    const navItems = document.querySelectorAll('.nav-link');

    navItems.forEach(item => {
        item.classList.remove('active');
        if (item.getAttribute('href') === path) {
            item.classList.add('active');
        }
    });
}

// Notification function using Tabler's built-in toast
function showNotification(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `alert alert-${type} alert-dismissible`;
    toast.setAttribute('role', 'alert');
    toast.innerHTML = `
        <div class="d-flex">
            <div>${message}</div>
        </div>
        <a class="btn-close" aria-label="close"></a>
    `;

    const container = document.querySelector('.page-body .container-xl');
    if (container) {
        const closeBtn = toast.querySelector('.btn-close');
        closeBtn.addEventListener('click', () => toast.remove());
        
        container.insertBefore(toast, container.firstChild);
        setTimeout(() => toast.remove(), 5000);
    }
}

// Copy to clipboard function
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        showNotification('Copied to clipboard!', 'success');
    }).catch(err => {
        showNotification('Failed to copy: ' + err.message, 'danger');
    });
}

// Format bytes to human readable
function formatBytes(bytes, decimals = 2) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

// Update page title
function updatePageTitle(title) {
    const pageTitle = document.getElementById('page-title');
    if (pageTitle) {
        pageTitle.textContent = title;
    }
    document.title = title + ' - AmneziaWG Manager';
}

// Set active nav item
function setActiveNav(path) {
    document.querySelectorAll('.navbar-nav .nav-link').forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === path) {
            link.classList.add('active');
        }
    });
}

// Initialize page based on current path
document.addEventListener('DOMContentLoaded', function() {
    const path = window.location.pathname;
    setActiveNav(path);

    const titles = {
        '/': 'Dashboard',
        '/tunnels': 'Tunnel Management',
        '/files': 'Configuration Files',
        '/network': 'Network & DNS'
    };

    if (titles[path]) {
        updatePageTitle(titles[path]);
    }
});