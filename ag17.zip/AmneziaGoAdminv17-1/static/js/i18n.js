// i18n - Internationalization system for EN/RU localization
const i18n = {
    // Current language
    currentLang: 'en',
    
    // Translation dictionaries
    translations: {
        en: {
            // Navigation
            'nav.dashboard': 'Dashboard',
            'nav.tunnels': 'Tunnels',
            'nav.network': 'Network & DNS',
            'nav.firewall': 'Firewall',
            'nav.system_online': 'System Online',
            
            // Common buttons
            'btn.refresh': 'Refresh',
            'btn.cancel': 'Cancel',
            'btn.close': 'Close',
            'btn.save': 'Save',
            'btn.apply': 'Apply',
            'btn.delete': 'Delete',
            'btn.edit': 'Edit',
            'btn.view_all': 'View All',
            'btn.new_file': 'New File',
            'btn.upload': 'Upload',
            'btn.add': 'Add',
            'btn.go': 'Go',
            'btn.check': 'Check',
            'btn.start': 'Start',
            'btn.stop': 'Stop',
            
            // Dashboard page
            'dashboard.title': 'Dashboard',
            'dashboard.overview.title': 'Dashboard Overview',
            'dashboard.overview.desc': 'Welcome to AmneziaWG Manager! This dashboard provides real-time status of your VPN tunnels and network interfaces.',
            'dashboard.overview.total_tunnels': 'Total Tunnels',
            'dashboard.overview.active_inactive': 'Active/Inactive Tunnels',
            'dashboard.overview.network_interfaces': 'Network Interfaces',
            'dashboard.overview.network_map': 'Network Connections Map',
            'dashboard.system_info': 'System Information',
            'dashboard.total_tunnels': 'Total Tunnels',
            'dashboard.active_tunnels': 'Active Tunnels',
            'dashboard.inactive_tunnels': 'Inactive Tunnels',
            'dashboard.config_files': 'Config Files',
            'dashboard.recent_tunnels': 'Recent Tunnels',
            'dashboard.network_interfaces': 'Network Interfaces',
            'dashboard.network_map': 'Network Connections Map',
            'dashboard.quick_actions': 'Quick Actions',
            'dashboard.system_requirements': 'System Requirements',
            'dashboard.about': 'About',
            'dashboard.about.desc': 'AmneziaWG Manager is a web interface for managing AmneziaWG VPN tunnels with advanced routing capabilities.',
            'dashboard.about.non_gateway': 'Non-Gateway Mode',
            'dashboard.about.non_gateway_desc': 'Multiple tunnels with split routing',
            'dashboard.about.default_gateway': 'Default Gateway',
            'dashboard.about.default_gateway_desc': 'Route all traffic through VPN',
            'dashboard.about.split_routing': 'Split Routing',
            'dashboard.about.split_routing_desc': 'Define custom routing rules',
            'dashboard.actions.manage_tunnels': 'Manage Tunnels',
            'dashboard.actions.manage_tunnels_desc': 'Start, stop, and configure VPN tunnels',
            'dashboard.actions.config_files': 'Configuration Files',
            'dashboard.actions.config_files_desc': 'Edit tunnel configuration files',
            
            // System info
            'system.uptime': 'Uptime',
            'system.hostname': 'Hostname',
            'system.kernel': 'Kernel',
            'system.distro': 'Distribution',
            'system.cpu': 'CPU',
            'system.ram': 'RAM',
            'system.storage': 'Storage',
            'system.network': 'Network',
            'system.loading': 'Loading system information...',
            'system.checking': 'Checking system requirements...',
            
            // Tunnels page
            'tunnels.title': 'Tunnel Management',
            'tunnels.tab_tunnels': 'Tunnels',
            'tunnels.tab_files': 'Configuration Files',
            'tunnels.country': 'Country',
            'tunnels.server_ip': 'Server IP',
            'tunnels.ping': 'Ping (ms)',
            'tunnels.last_updated': 'Last Updated',
            'tunnels.status': 'Status',
            'tunnels.routing_rules': 'Routing Rules',
            'tunnels.actions': 'Actions',
            'tunnels.active': 'Active',
            'tunnels.stopped': 'Stopped',
            'tunnels.running': 'Running',
            'tunnels.about.title': 'About Tunnel Management',
            'tunnels.about.desc': 'This interface allows you to control AmneziaWG tunnels with advanced routing capabilities using nftables and ipset.',
            'tunnels.about.non_gateway': 'Non-Gateway Mode',
            'tunnels.about.non_gateway_desc': 'Multiple tunnels can run simultaneously with split routing rules',
            'tunnels.about.default_gateway': 'Default Gateway Mode',
            'tunnels.about.default_gateway_desc': 'Only one tunnel can be active at a time, all traffic routes through it',
            'tunnels.about.split_routing': 'Split Routing',
            'tunnels.about.split_routing_desc': 'Define rules based on CIDR/IP lists to direct, tunnel, or block traffic',
            
            // Tunnel details modal
            'tunnels.details.title': 'Tunnel Details',
            'tunnels.config.title': 'Tunnel Configuration',
            'tunnels.config.mode': 'Tunnel Mode',
            'tunnels.config.mode.non_gateway': 'Non-Gateway (Split Routing)',
            'tunnels.config.mode.default_gateway': 'Default Gateway',
            'tunnels.config.mode.hint': 'Non-gateway allows multiple tunnels and split routing. Default gateway allows only one active tunnel.',
            'tunnels.config.routing.title': 'Split Routing Rules',
            'tunnels.config.routing.add_route': 'Add Route',
            'tunnels.config.routing.upload_filter': 'Upload Filter',
            'tunnels.config.save': 'Save Configuration',
            
            // Add route modal
            'route.add.title': 'Add Routing Rule',
            'route.name': 'Rule Name',
            'route.name.placeholder': 'e.g., Block Ads',
            'route.filter_file': 'Filter File (CIDR/IP List)',
            'route.action': 'Action',
            'route.action.direct': 'Direct Connection',
            'route.action.tunnel': 'Forward to Tunnel',
            'route.action.block': 'Block',
            'route.target_tunnel': 'Target Tunnel',
            'route.priority': 'Priority',
            'route.priority.hint': 'Lower numbers = higher priority',
            
            // Upload filter modal
            'filter.upload.title': 'Upload Filter File',
            'filter.file': 'Filter File (.txt)',
            'filter.file.hint': 'File should contain one CIDR or IP per line. Lines starting with # are ignored.',
            
            // Upload CIDR modal
            'cidr.upload.title': 'Upload CIDR File',
            'cidr.company_name': 'Company Name',
            'cidr.company_name.placeholder': 'e.g., google, facebook',
            'cidr.company_name.hint': 'The file will be saved as [company_name]_cidr.pt',
            'cidr.file': 'CIDR File',
            'cidr.file.hint': 'File should contain one CIDR or IP per line. Lines starting with # are ignored.',
            'cidr.upload': 'Upload CIDR',
            
            // Files page
            'files.title': 'Configuration Files',
            'files.management.title': 'Configuration Files Management',
            'files.management.desc': 'Manage AmneziaWG configuration files directly through the web interface.',
            'files.management.new_file': 'New File',
            'files.management.new_file_desc': 'Create new tunnel configuration files with standard WireGuard format',
            'files.management.edit': 'Edit',
            'files.management.edit_desc': 'Modify existing configurations directly in the browser',
            'files.management.delete': 'Delete',
            'files.management.delete_desc': 'Remove unused configuration files (tunnel must be stopped first)',
            'files.management.format': 'Format',
            'files.management.format_desc': 'Standard WireGuard/AmneziaWG .conf format with [Interface] and [Peer] sections',
            'files.file_name': 'File Name',
            'files.path': 'Path',
            'files.size': 'Size',
            'files.modified': 'Last Modified',
            'files.no_files': 'No configuration files found. Click "New File" to create one.',
            'files.editor.title': 'Edit Configuration',
            'files.editor.new': 'New Configuration File',
            'files.editor.name': 'File Name',
            'files.editor.name.placeholder': 'tunnel.conf',
            'files.editor.content': 'Configuration',
            'files.save': 'Save File',
            
            // Network page
            'network.title': 'Network & DNS',
            'network.config.title': 'Network & DNS Configuration',
            'network.config.desc': 'Configure system-wide DNS settings and DHCP server for your VPN network.',
            'network.config.dns_resolver': 'DNS Resolver',
            'network.config.dns_resolver_desc': 'Choose between resolvconf or systemd-resolved for DNS management',
            'network.config.dns_servers': 'DNS Servers',
            'network.config.dns_servers_desc': 'Set custom DNS servers (one per line), supports DoT and DNSSEC',
            'network.config.dhcp_server': 'DHCP Server',
            'network.config.dhcp_server_desc': 'Enable DHCP server on tunnel interfaces to assign IPs automatically',
            'network.config.dhcp_relay': 'DHCP Relay',
            'network.config.dhcp_relay_desc': 'Forward DHCP requests to another server',
            'network.dns.title': 'DNS Configuration',
            'network.dns.resolver': 'DNS Resolver',
            'network.dns.servers': 'DNS Servers',
            'network.dns.servers.placeholder': '8.8.8.8\n1.1.1.1',
            'network.dns.dnssec': 'Enable DNSSEC',
            'network.dns.dns_over_tls': 'Enable DNS-over-TLS',
            'network.dns.mdns': 'Enable mDNS',
            'network.dns.save': 'Save DNS Configuration',
            'network.dns.status': 'Current DNS Status',
            'network.dhcp.title': 'DHCP Server',
            'network.dhcp.mode': 'DHCP Mode',
            'network.dhcp.mode.disabled': 'Disabled',
            'network.dhcp.mode.server': 'DHCP Server',
            'network.dhcp.mode.relay': 'DHCP Relay',
            'network.dhcp.interface': 'Interface',
            'network.dhcp.range_start': 'IP Range Start',
            'network.dhcp.range_start.placeholder': '192.168.1.100',
            'network.dhcp.range_end': 'IP Range End',
            'network.dhcp.range_end.placeholder': '192.168.1.200',
            'network.dhcp.netmask': 'Subnet Mask',
            'network.dhcp.netmask.placeholder': '255.255.255.0',
            'network.dhcp.gateway': 'Gateway',
            'network.dhcp.gateway.placeholder': '192.168.1.1',
            'network.dhcp.lease_time': 'Lease Time (seconds)',
            'network.dhcp.relay_server': 'DHCP Server IP',
            'network.dhcp.relay_server.placeholder': '192.168.1.1',
            'network.dhcp.relay_interfaces': 'Relay Interfaces',
            'network.dhcp.relay_interfaces.placeholder': 'eth0 eth1',
            'network.dhcp.save': 'Save DHCP Configuration',
            
            // Firewall page
            'firewall.title': 'Firewall',
            'firewall.config.title': 'Firewall & Routing Configuration',
            'firewall.config.desc': 'Configure IP forwarding, NAT masquerading, and firewall rules using nftables.',
            'firewall.config.forwarding': 'IP Forwarding',
            'firewall.config.forwarding_desc': 'Enable packet forwarding between network interfaces',
            'firewall.config.masquerading': 'Masquerading (NAT)',
            'firewall.config.masquerading_desc': 'Enable source NAT for internet sharing through VPN tunnels',
            'firewall.config.internet_sharing': 'Internet Sharing',
            'firewall.config.internet_sharing_desc': 'Quick setup to share internet connection from one interface to another',
            'firewall.config.rules': 'Firewall Rules',
            'firewall.config.rules_desc': 'View and manage nftables rules (advanced users)',
            'firewall.config.routing_rules': 'Split Routing Rules',
            'firewall.config.routing_rules_desc': 'View routing rules configured for each tunnel',
            'firewall.forwarding.title': 'IP Forwarding',
            'firewall.forwarding.enable': 'Enable IP Forwarding',
            'firewall.forwarding.source': 'Source Interface',
            'firewall.forwarding.dest': 'Destination Interface',
            'firewall.masquerading.title': 'Masquerading (NAT)',
            'firewall.masquerading.enable': 'Enable Masquerading',
            'firewall.masquerading.interface': 'Output Interface',
            'firewall.masquerading.hint': 'Interface for internet sharing (usually WAN interface)',
            'firewall.sharing.title': 'Internet Sharing',
            'firewall.sharing.desc': 'Share internet connection from one interface to another using NAT and forwarding.',
            'firewall.sharing.from': 'From',
            'firewall.sharing.to': 'To',
            'firewall.sharing.setup': 'Setup Internet Sharing',
            'firewall.rules.title': 'Firewall Rules (nftables)',
            'firewall.rules.table': 'Table',
            'firewall.rules.chain': 'Chain',
            'firewall.rules.rule': 'Rule',
            'firewall.rules.handle': 'Handle',
            'firewall.rules.no_rules': 'No rules found',
            'firewall.rules.loading': 'Loading rules...',
            'firewall.routing.title': 'Split Routing Rules (nftables & ipset)',
            'firewall.routing.tunnel': 'Tunnel',
            'firewall.routing.route_name': 'Route Name',
            'firewall.routing.filter_file': 'Filter File',
            'firewall.routing.action': 'Action',
            'firewall.routing.target': 'Target',
            'firewall.routing.priority': 'Priority',
            'firewall.routing.status': 'Status',
            'firewall.routing.enabled': 'Enabled',
            'firewall.routing.disabled': 'Disabled',
            'firewall.routing.no_rules': 'No routing rules configured',
            'firewall.routing.loading': 'Loading routing rules...',
            'firewall.editor.title': 'Configuration Editor',
            'firewall.editor.load': 'Load Current Config',
            'firewall.editor.save': 'Save & Apply',
            'firewall.editor.warning': 'Warning',
            'firewall.editor.warning.text': 'Editing nftables configuration directly can break your firewall. Make sure you understand the syntax before applying changes.',
            
            // Table headers
            'table.name': 'Name',
            'table.status': 'Status',
            'table.actions': 'Actions',
            'table.interface': 'Interface',
            'table.state': 'State',
            'table.ip_addresses': 'IP Addresses',
            'table.mac_address': 'MAC Address',
            'table.device': 'Device',
            'table.source': 'Source',
            'table.destination': 'Destination',
            'table.protocol': 'Protocol',
            
            // Status messages
            'status.loading': 'Loading...',
            'status.no_data': 'No data available',
            'status.error': 'Error loading data',
            
            // Notifications
            'notify.copied': 'Copied to clipboard!',
            'notify.copy_failed': 'Failed to copy',
            'notify.save_success': 'Saved successfully',
            'notify.save_error': 'Error saving',
            'notify.delete_confirm': 'Are you sure you want to delete',
            
            // Footer
            'footer.copyright': 'Copyright &copy; 2025',
            'footer.tools': 'AmneziaWG Tools'
        },
        
        ru: {
            // Navigation
            'nav.dashboard': 'Панель управления',
            'nav.tunnels': 'Туннели',
            'nav.network': 'Сеть и DNS',
            'nav.firewall': 'Файрвол',
            'nav.system_online': 'Система в сети',
            
            // Common buttons
            'btn.refresh': 'Обновить',
            'btn.cancel': 'Отмена',
            'btn.close': 'Закрыть',
            'btn.save': 'Сохранить',
            'btn.apply': 'Применить',
            'btn.delete': 'Удалить',
            'btn.edit': 'Редактировать',
            'btn.view_all': 'Смотреть все',
            'btn.new_file': 'Новый файл',
            'btn.upload': 'Загрузить',
            'btn.add': 'Добавить',
            'btn.go': 'Перейти',
            'btn.check': 'Проверить',
            'btn.start': 'Запустить',
            'btn.stop': 'Остановить',
            
            // Dashboard page
            'dashboard.title': 'Панель управления',
            'dashboard.overview.title': 'Обзор панели управления',
            'dashboard.overview.desc': 'Добро пожаловать в AmneziaWG Manager! Эта панель показывает текущий статус ваших VPN-туннелей и сетевых интерфейсов.',
            'dashboard.overview.total_tunnels': 'Всего туннелей',
            'dashboard.overview.active_inactive': 'Активные/неактивные туннели',
            'dashboard.overview.network_interfaces': 'Сетевые интерфейсы',
            'dashboard.overview.network_map': 'Карта сетевых подключений',
            'dashboard.system_info': 'Информация о системе',
            'dashboard.total_tunnels': 'Всего туннелей',
            'dashboard.active_tunnels': 'Активные туннели',
            'dashboard.inactive_tunnels': 'Неактивные туннели',
            'dashboard.config_files': 'Файлы конфигурации',
            'dashboard.recent_tunnels': 'Недавние туннели',
            'dashboard.network_interfaces': 'Сетевые интерфейсы',
            'dashboard.network_map': 'Карта сетевых подключений',
            'dashboard.quick_actions': 'Быстрые действия',
            'dashboard.system_requirements': 'Требования системы',
            'dashboard.about': 'О программе',
            'dashboard.about.desc': 'AmneziaWG Manager — это веб-интерфейс для управления VPN-туннелями AmneziaWG с расширенными возможностями маршрутизации.',
            'dashboard.about.non_gateway': 'Режим без шлюза',
            'dashboard.about.non_gateway_desc': 'Несколько туннелей с раздельной маршрутизацией',
            'dashboard.about.default_gateway': 'Шлюз по умолчанию',
            'dashboard.about.default_gateway_desc': 'Весь трафик через VPN',
            'dashboard.about.split_routing': 'Раздельная маршрутизация',
            'dashboard.about.split_routing_desc': 'Настройка пользовательских правил маршрутизации',
            'dashboard.actions.manage_tunnels': 'Управление туннелями',
            'dashboard.actions.manage_tunnels_desc': 'Запуск, остановка и настройка VPN-туннелей',
            'dashboard.actions.config_files': 'Файлы конфигурации',
            'dashboard.actions.config_files_desc': 'Редактирование файлов конфигурации туннелей',
            
            // System info
            'system.uptime': 'Время работы',
            'system.hostname': 'Имя хоста',
            'system.kernel': 'Ядро',
            'system.distro': 'Дистрибутив',
            'system.cpu': 'ЦП',
            'system.ram': 'ОЗУ',
            'system.storage': 'Хранилище',
            'system.network': 'Сеть',
            'system.loading': 'Загрузка информации о системе...',
            'system.checking': 'Проверка системных требований...',
            
            // Tunnels page
            'tunnels.title': 'Управление туннелями',
            'tunnels.tab_tunnels': 'Туннели',
            'tunnels.tab_files': 'Файлы конфигурации',
            'tunnels.country': 'Страна',
            'tunnels.server_ip': 'IP сервера',
            'tunnels.ping': 'Пинг (мс)',
            'tunnels.last_updated': 'Последнее обновление',
            'tunnels.status': 'Статус',
            'tunnels.routing_rules': 'Правила маршрутизации',
            'tunnels.actions': 'Действия',
            'tunnels.active': 'Активен',
            'tunnels.stopped': 'Остановлен',
            'tunnels.running': 'Работает',
            'tunnels.about.title': 'Об управлении туннелями',
            'tunnels.about.desc': 'Этот интерфейс позволяет управлять туннелями AmneziaWG с расширенными возможностями маршрутизации через nftables и ipset.',
            'tunnels.about.non_gateway': 'Режим без шлюза',
            'tunnels.about.non_gateway_desc': 'Несколько туннелей могут работать одновременно с правилами раздельной маршрутизации',
            'tunnels.about.default_gateway': 'Режим шлюза по умолчанию',
            'tunnels.about.default_gateway_desc': 'Только один туннель может быть активным одновременно, весь трафик идёт через него',
            'tunnels.about.split_routing': 'Раздельная маршрутизация',
            'tunnels.about.split_routing_desc': 'Определение правил на основе списков CIDR/IP для направления, туннелирования или блокировки трафика',
            
            // Tunnel details modal
            'tunnels.details.title': 'Детали туннеля',
            'tunnels.config.title': 'Конфигурация туннеля',
            'tunnels.config.mode': 'Режим туннеля',
            'tunnels.config.mode.non_gateway': 'Без шлюза (раздельная маршрутизация)',
            'tunnels.config.mode.default_gateway': 'Шлюз по умолчанию',
            'tunnels.config.mode.hint': 'Режим без шлюза позволяет использовать несколько туннелей и раздельную маршрутизацию. Режим шлюза по умолчанию позволяет использовать только один активный туннель.',
            'tunnels.config.routing.title': 'Правила раздельной маршрутизации',
            'tunnels.config.routing.add_route': 'Добавить маршрут',
            'tunnels.config.routing.upload_filter': 'Загрузить фильтр',
            'tunnels.config.save': 'Сохранить конфигурацию',
            
            // Add route modal
            'route.add.title': 'Добавить правило маршрутизации',
            'route.name': 'Имя правила',
            'route.name.placeholder': 'например, Блокировка рекламы',
            'route.filter_file': 'Файл фильтра (список CIDR/IP)',
            'route.action': 'Действие',
            'route.action.direct': 'Прямое подключение',
            'route.action.tunnel': 'Направить в туннель',
            'route.action.block': 'Блокировать',
            'route.target_tunnel': 'Целевой туннель',
            'route.priority': 'Приоритет',
            'route.priority.hint': 'Меньшее число = выше приоритет',
            
            // Upload filter modal
            'filter.upload.title': 'Загрузить файл фильтра',
            'filter.file': 'Файл фильтра (.txt)',
            'filter.file.hint': 'Файл должен содержать один CIDR или IP на строку. Строки, начинающиеся с #, игнорируются.',
            
            // Upload CIDR modal
            'cidr.upload.title': 'Загрузить файл CIDR',
            'cidr.company_name': 'Название компании',
            'cidr.company_name.placeholder': 'например, google, facebook',
            'cidr.company_name.hint': 'Файл будет сохранён как [company_name]_cidr.pt',
            'cidr.file': 'Файл CIDR',
            'cidr.file.hint': 'Файл должен содержать один CIDR или IP на строку. Строки, начинающиеся с #, игнорируются.',
            'cidr.upload': 'Загрузить CIDR',
            
            // Files page
            'files.title': 'Файлы конфигурации',
            'files.management.title': 'Управление файлами конфигурации',
            'files.management.desc': 'Управление файлами конфигурации AmneziaWG непосредственно через веб-интерфейс.',
            'files.management.new_file': 'Новый файл',
            'files.management.new_file_desc': 'Создание новых файлов конфигурации туннелей в стандартном формате WireGuard',
            'files.management.edit': 'Редактировать',
            'files.management.edit_desc': 'Изменение существующих конфигураций прямо в браузере',
            'files.management.delete': 'Удалить',
            'files.management.delete_desc': 'Удаление неиспользуемых файлов конфигурации (сначала нужно остановить туннель)',
            'files.management.format': 'Формат',
            'files.management.format_desc': 'Стандартный формат WireGuard/AmneziaWG .conf с секциями [Interface] и [Peer]',
            'files.file_name': 'Имя файла',
            'files.path': 'Путь',
            'files.size': 'Размер',
            'files.modified': 'Последнее изменение',
            'files.no_files': 'Файлы конфигурации не найдены. Нажмите "Новый файл" для создания.',
            'files.editor.title': 'Редактирование конфигурации',
            'files.editor.new': 'Новый файл конфигурации',
            'files.editor.name': 'Имя файла',
            'files.editor.name.placeholder': 'tunnel.conf',
            'files.editor.content': 'Конфигурация',
            'files.save': 'Сохранить файл',
            
            // Network page
            'network.title': 'Сеть и DNS',
            'network.config.title': 'Конфигурация сети и DNS',
            'network.config.desc': 'Настройка DNS на уровне системы и DHCP-сервера для вашей VPN-сети.',
            'network.config.dns_resolver': 'DNS-резолвер',
            'network.config.dns_resolver_desc': 'Выбор между resolvconf и systemd-resolved для управления DNS',
            'network.config.dns_servers': 'DNS-серверы',
            'network.config.dns_servers_desc': 'Установка пользовательских DNS-серверов (один на строку), поддержка DoT и DNSSEC',
            'network.config.dhcp_server': 'DHCP-сервер',
            'network.config.dhcp_server_desc': 'Включение DHCP-сервера на интерфейсах туннелей для автоматического назначения IP',
            'network.config.dhcp_relay': 'DHCP-ретранслятор',
            'network.config.dhcp_relay_desc': 'Пересылка DHCP-запросов на другой сервер',
            'network.dns.title': 'Конфигурация DNS',
            'network.dns.resolver': 'DNS-резолвер',
            'network.dns.servers': 'DNS-серверы',
            'network.dns.servers.placeholder': '8.8.8.8\n1.1.1.1',
            'network.dns.dnssec': 'Включить DNSSEC',
            'network.dns.dns_over_tls': 'Включить DNS-over-TLS',
            'network.dns.mdns': 'Включить mDNS',
            'network.dns.save': 'Сохранить конфигурацию DNS',
            'network.dns.status': 'Текущий статус DNS',
            'network.dhcp.title': 'DHCP-сервер',
            'network.dhcp.mode': 'Режим DHCP',
            'network.dhcp.mode.disabled': 'Отключён',
            'network.dhcp.mode.server': 'DHCP-сервер',
            'network.dhcp.mode.relay': 'DHCP-ретранслятор',
            'network.dhcp.interface': 'Интерфейс',
            'network.dhcp.range_start': 'Начало диапазона IP',
            'network.dhcp.range_start.placeholder': '192.168.1.100',
            'network.dhcp.range_end': 'Конец диапазона IP',
            'network.dhcp.range_end.placeholder': '192.168.1.200',
            'network.dhcp.netmask': 'Маска подсети',
            'network.dhcp.netmask.placeholder': '255.255.255.0',
            'network.dhcp.gateway': 'Шлюз',
            'network.dhcp.gateway.placeholder': '192.168.1.1',
            'network.dhcp.lease_time': 'Время аренды (секунды)',
            'network.dhcp.relay_server': 'IP DHCP-сервера',
            'network.dhcp.relay_server.placeholder': '192.168.1.1',
            'network.dhcp.relay_interfaces': 'Интерфейсы ретранслятора',
            'network.dhcp.relay_interfaces.placeholder': 'eth0 eth1',
            'network.dhcp.save': 'Сохранить конфигурацию DHCP',
            
            // Firewall page
            'firewall.title': 'Файрвол',
            'firewall.config.title': 'Конфигурация файрвола и маршрутизации',
            'firewall.config.desc': 'Настройка пересылки IP, NAT masquerading и правил файрвола с использованием nftables.',
            'firewall.config.forwarding': 'Пересылка IP',
            'firewall.config.forwarding_desc': 'Включение пересылки пакетов между сетевыми интерфейсами',
            'firewall.config.masquerading': 'Masquerading (NAT)',
            'firewall.config.masquerading_desc': 'Включение source NAT для совместного использования интернета через VPN-туннели',
            'firewall.config.internet_sharing': 'Общий доступ к интернету',
            'firewall.config.internet_sharing_desc': 'Быстрая настройка для совместного использования интернет-соединения между интерфейсами',
            'firewall.config.rules': 'Правила файрвола',
            'firewall.config.rules_desc': 'Просмотр и управление правилами nftables (для продвинутых пользователей)',
            'firewall.config.routing_rules': 'Правила раздельной маршрутизации',
            'firewall.config.routing_rules_desc': 'Просмотр правил маршрутизации, настроенных для каждого туннеля',
            'firewall.forwarding.title': 'Пересылка IP',
            'firewall.forwarding.enable': 'Включить пересылку IP',
            'firewall.forwarding.source': 'Исходный интерфейс',
            'firewall.forwarding.dest': 'Целевой интерфейс',
            'firewall.masquerading.title': 'Masquerading (NAT)',
            'firewall.masquerading.enable': 'Включить Masquerading',
            'firewall.masquerading.interface': 'Выходной интерфейс',
            'firewall.masquerading.hint': 'Интерфейс для совместного использования интернета (обычно WAN-интерфейс)',
            'firewall.sharing.title': 'Общий доступ к интернету',
            'firewall.sharing.desc': 'Совместное использование интернет-соединения между интерфейсами с помощью NAT и пересылки.',
            'firewall.sharing.from': 'Откуда',
            'firewall.sharing.to': 'Куда',
            'firewall.sharing.setup': 'Настроить общий доступ',
            'firewall.rules.title': 'Правила файрвола (nftables)',
            'firewall.rules.table': 'Таблица',
            'firewall.rules.chain': 'Цепочка',
            'firewall.rules.rule': 'Правило',
            'firewall.rules.handle': 'Дескриптор',
            'firewall.rules.no_rules': 'Правила не найдены',
            'firewall.rules.loading': 'Загрузка правил...',
            'firewall.routing.title': 'Правила раздельной маршрутизации (nftables & ipset)',
            'firewall.routing.tunnel': 'Туннель',
            'firewall.routing.route_name': 'Имя маршрута',
            'firewall.routing.filter_file': 'Файл фильтра',
            'firewall.routing.action': 'Действие',
            'firewall.routing.target': 'Цель',
            'firewall.routing.priority': 'Приоритет',
            'firewall.routing.status': 'Статус',
            'firewall.routing.enabled': 'Включено',
            'firewall.routing.disabled': 'Отключено',
            'firewall.routing.no_rules': 'Правила маршрутизации не настроены',
            'firewall.routing.loading': 'Загрузка правил маршрутизации...',
            'firewall.editor.title': 'Редактор конфигурации',
            'firewall.editor.load': 'Загрузить текущую конфигурацию',
            'firewall.editor.save': 'Сохранить и применить',
            'firewall.editor.warning': 'Внимание',
            'firewall.editor.warning.text': 'Прямое редактирование конфигурации nftables может нарушить работу файрвола. Убедитесь, что понимаете синтаксис перед применением изменений.',
            
            // Table headers
            'table.name': 'Имя',
            'table.status': 'Статус',
            'table.actions': 'Действия',
            'table.interface': 'Интерфейс',
            'table.state': 'Состояние',
            'table.ip_addresses': 'IP-адреса',
            'table.mac_address': 'MAC-адрес',
            'table.device': 'Устройство',
            'table.source': 'Источник',
            'table.destination': 'Назначение',
            'table.protocol': 'Протокол',
            
            // Status messages
            'status.loading': 'Загрузка...',
            'status.no_data': 'Нет данных',
            'status.error': 'Ошибка загрузки данных',
            
            // Notifications
            'notify.copied': 'Скопировано в буфер обмена!',
            'notify.copy_failed': 'Не удалось скопировать',
            'notify.save_success': 'Успешно сохранено',
            'notify.save_error': 'Ошибка сохранения',
            'notify.delete_confirm': 'Вы уверены, что хотите удалить',
            
            // Footer
            'footer.copyright': 'Авторские права &copy; 2025',
            'footer.tools': 'Инструменты AmneziaWG'
        }
    },
    
    // Initialize i18n system
    init: function() {
        // Detect browser language
        const browserLang = (navigator.language || navigator.userLanguage).toLowerCase();
        const langCode = browserLang.startsWith('ru') ? 'ru' : 'en';
        
        // Check if language is stored in localStorage
        const storedLang = localStorage.getItem('amneziawg_lang');
        this.currentLang = storedLang || langCode;
        
        // Apply translations
        this.applyTranslations();
        
        // Update language selector if exists
        const langSelector = document.getElementById('language-selector');
        if (langSelector) {
            langSelector.value = this.currentLang;
        }
    },
    
    // Get translation by key
    t: function(key) {
        return this.translations[this.currentLang][key] || this.translations['en'][key] || key;
    },
    
    // Apply translations to DOM
    applyTranslations: function() {
        // Translate elements with data-i18n attribute
        document.querySelectorAll('[data-i18n]').forEach(element => {
            const key = element.getAttribute('data-i18n');
            const translation = this.t(key);
            
            // Check if we should update text or placeholder
            if (element.hasAttribute('placeholder')) {
                element.placeholder = translation;
            } else if (element.tagName === 'INPUT' && element.type !== 'text') {
                element.value = translation;
            } else {
                element.textContent = translation;
            }
        });
        
        // Translate elements with data-i18n-html attribute (for HTML content)
        document.querySelectorAll('[data-i18n-html]').forEach(element => {
            const key = element.getAttribute('data-i18n-html');
            const translation = this.t(key);
            element.innerHTML = translation;
        });
        
        // Translate placeholders
        document.querySelectorAll('[data-i18n-placeholder]').forEach(element => {
            const key = element.getAttribute('data-i18n-placeholder');
            element.placeholder = this.t(key);
        });
        
        // Translate titles
        document.querySelectorAll('[data-i18n-title]').forEach(element => {
            const key = element.getAttribute('data-i18n-title');
            element.title = this.t(key);
        });
    },
    
    // Switch language
    switchLanguage: function(lang) {
        if (lang !== 'en' && lang !== 'ru') {
            lang = 'en';
        }
        
        this.currentLang = lang;
        localStorage.setItem('amneziawg_lang', lang);
        this.applyTranslations();
        
        // Update language selector display
        const langDisplay = document.getElementById('current-language');
        if (langDisplay) {
            langDisplay.textContent = lang.toUpperCase();
        }
        
        // Reload dynamic content if needed
        this.reloadDynamicContent();
    },
    
    // Reload dynamic content after language change
    reloadDynamicContent: function() {
        // This function can be extended to reload specific content
        // For now, we'll just update the page title
        const path = window.location.pathname;
        const titles = {
            '/': this.t('dashboard.title'),
            '/tunnels': this.t('tunnels.title'),
            '/files': this.t('files.title'),
            '/network': this.t('network.title'),
            '/firewall': this.t('firewall.title')
        };
        
        if (titles[path]) {
            document.title = titles[path] + ' - AmneziaWG Manager';
            const pageTitle = document.getElementById('page-title');
            if (pageTitle) {
                pageTitle.textContent = titles[path];
            }
        }
    }
};

// Initialize on DOM load
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => i18n.init());
} else {
    i18n.init();
}
