# AmneziaWG Configuration

## Security Notice

**IMPORTANT**: Never commit real cryptographic keys to version control.

## Setting Up Your Tunnel

The `ee.conf` file contains placeholder values that you must replace with your actual VPN credentials:

1. **PrivateKey**: Replace `YOUR_PRIVATE_KEY_HERE` with your WireGuard private key
2. **PublicKey**: Replace `YOUR_PEER_PUBLIC_KEY_HERE` with your VPN server's public key
3. **PresharedKey**: Replace `YOUR_PRESHARED_KEY_HERE` with your preshared key (if applicable)

### Generating Keys

To generate WireGuard keys:
```bash
# Generate private key
wg genkey

# Generate public key from private key
echo "YOUR_PRIVATE_KEY" | wg pubkey

# Generate preshared key
wg genpsk
```

### Important
- Keep your PrivateKey and PresharedKey confidential
- Never share these keys publicly or commit them to version control
- Update the endpoint IP address and port if needed
