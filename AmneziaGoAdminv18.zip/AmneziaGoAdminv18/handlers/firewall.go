package handlers

import (
        "encoding/json"
        "net/http"
        "os"
        "os/exec"
        "strings"

        "amneziawg-manager/logger"
        "amneziawg-manager/renderer"
)

type FirewallRule struct {
        Table    string `json:"table"`
        Chain    string `json:"chain"`
        Rule     string `json:"rule"`
        Handle   string `json:"handle,omitempty"`
}

type FirewallStatus struct {
        Forwarding     bool   `json:"forwarding"`
        Masquerading   bool   `json:"masquerading"`
        Rules          []FirewallRule `json:"rules"`
        SourceIface    string `json:"source_iface"`
        DestIface      string `json:"dest_iface"`
}

type ForwardingConfig struct {
        Enabled    bool   `json:"enabled"`
        SourceIface string `json:"source_iface"`
        DestIface   string `json:"dest_iface"`
}

type MasqueradeConfig struct {
        Enabled   bool   `json:"enabled"`
        Interface string `json:"interface"`
}

func FirewallPageHandler(w http.ResponseWriter, r *http.Request) {
        renderer.RenderPage(w, "firewall", "layout", nil)
}

func APIFirewallStatusHandler(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")

        interfaces := getDefaultInterfaces()
        
        status := FirewallStatus{
                Forwarding:   isIPForwardingEnabled(),
                Masquerading: isMasqueradingEnabled(),
                Rules:        getNftablesRules(),
                SourceIface:  interfaces.Source,
                DestIface:    interfaces.Dest,
        }

        respondJSON(w, status)
}

type DefaultInterfaces struct {
        Source string
        Dest   string
}

func getDefaultInterfaces() DefaultInterfaces {
        interfaces := DefaultInterfaces{}
        
        cmd := exec.Command("ip", "route", "show", "default")
        output, err := cmd.Output()
        if err == nil {
                line := string(output)
                if strings.Contains(line, "dev") {
                        parts := strings.Fields(line)
                        for i, part := range parts {
                                if part == "dev" && i+1 < len(parts) {
                                        interfaces.Dest = parts[i+1]
                                        break
                                }
                        }
                }
        } else {
                logger.Log.Error("failed to get default route", "error", err)
        }
        
        cmd = exec.Command("ip", "link", "show")
        output, err = cmd.Output()
        if err == nil {
                lines := strings.Split(string(output), "\n")
                for _, line := range lines {
                        if strings.Contains(line, "state UP") && !strings.Contains(line, "lo:") {
                                parts := strings.Fields(line)
                                if len(parts) >= 2 {
                                        iface := strings.TrimSuffix(parts[1], ":")
                                        if iface != interfaces.Dest {
                                                interfaces.Source = iface
                                                break
                                        }
                                }
                        }
                }
        } else {
                logger.Log.Error("failed to list network interfaces", "error", err)
        }
        
        if interfaces.Source == "" && interfaces.Dest != "" {
                logger.Log.Info("only one interface found, using same for both source and dest", "interface", interfaces.Dest)
                interfaces.Source = interfaces.Dest
        }
        
        if interfaces.Source == "" || interfaces.Dest == "" {
                logger.Log.Warn("could not auto-detect network interfaces", 
                        "source", interfaces.Source, "dest", interfaces.Dest)
        }
        
        return interfaces
}

func APIFirewallToggleForwardingHandler(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")

        var config ForwardingConfig
        if err := json.NewDecoder(r.Body).Decode(&config); err != nil {
                respondError(w, http.StatusBadRequest, "Invalid request")
                return
        }

        originalState := isIPForwardingEnabled()
        
        if !setIPForwarding(config.Enabled) {
                respondError(w, http.StatusInternalServerError, "Failed to toggle IP forwarding in sysctl")
                return
        }

        if config.Enabled && config.SourceIface != "" && config.DestIface != "" {
                if !setupInterfaceForwarding(config.SourceIface, config.DestIface) {
                        setIPForwarding(originalState)
                        respondError(w, http.StatusInternalServerError, "Failed to setup nftables forwarding rules")
                        return
                }
        } else if !config.Enabled {
                if err := exec.Command("nft", "flush", "chain", "inet", cfg.Firewall.FilterTableName, "forward").Run(); err != nil {
                        logger.Log.Warn("failed to flush forward chain when disabling", "error", err)
                }
        }

        respondSuccess(w, "IP forwarding "+map[bool]string{true: "enabled", false: "disabled"}[config.Enabled])
}

func APIFirewallToggleMasqueradeHandler(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")

        var config MasqueradeConfig
        if err := json.NewDecoder(r.Body).Decode(&config); err != nil {
                respondError(w, http.StatusBadRequest, "Invalid request")
                return
        }

        if !setMasquerading(config.Enabled, config.Interface) {
                respondError(w, http.StatusInternalServerError, "Failed to configure masquerading")
                return
        }
        
        respondSuccess(w, "Masquerading "+map[bool]string{true: "enabled", false: "disabled"}[config.Enabled])
}

func APIFirewallAddRuleHandler(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")

        var rule FirewallRule
        if err := json.NewDecoder(r.Body).Decode(&rule); err != nil {
                respondError(w, http.StatusBadRequest, "Invalid request")
                return
        }

        args := []string{"add", "rule"}
        args = append(args, strings.Fields(rule.Table)...)
        args = append(args, rule.Chain)
        args = append(args, strings.Fields(rule.Rule)...)

        cmd := exec.Command("nft", args...)
        output, err := cmd.CombinedOutput()
        if err != nil {
                respondError(w, http.StatusInternalServerError, "Failed to add rule: "+string(output))
                return
        }

        respondSuccess(w, "Rule added successfully")
}

func APIFirewallDeleteRuleHandler(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")

        var rule FirewallRule
        if err := json.NewDecoder(r.Body).Decode(&rule); err != nil {
                respondError(w, http.StatusBadRequest, "Invalid request")
                return
        }

        if rule.Handle == "" {
                respondError(w, http.StatusBadRequest, "Rule handle is required")
                return
        }

        args := []string{"delete", "rule"}
        args = append(args, strings.Fields(rule.Table)...)
        args = append(args, rule.Chain, "handle", rule.Handle)

        cmd := exec.Command("nft", args...)
        output, err := cmd.CombinedOutput()
        if err != nil {
                respondError(w, http.StatusInternalServerError, "Failed to delete rule: "+string(output))
                return
        }

        respondSuccess(w, "Rule deleted successfully")
}

func APIFirewallGetConfigHandler(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")

        cmd := exec.Command("nft", "list", "ruleset")
        output, err := cmd.Output()
        if err != nil {
                respondError(w, http.StatusInternalServerError, "Failed to read nftables config: "+err.Error())
                return
        }

        respondJSON(w, map[string]interface{}{
                "success": true,
                "config":  string(output),
        })
}

func APIFirewallSaveConfigHandler(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")

        var request struct {
                Config string `json:"config"`
        }

        if err := json.NewDecoder(r.Body).Decode(&request); err != nil {
                respondError(w, http.StatusBadRequest, "Invalid request")
                return
        }

        tmpFile, err := os.CreateTemp("", "nftables-*.conf")
        if err != nil {
                respondError(w, http.StatusInternalServerError, "Failed to create temp file")
                return
        }
        defer tmpFile.Close()

        if _, err := tmpFile.WriteString(request.Config); err != nil {
                respondError(w, http.StatusInternalServerError, "Failed to write config")
                return
        }

        cmd := exec.Command("nft", "-f", tmpFile.Name())
        output, err := cmd.CombinedOutput()
        if err != nil {
                respondError(w, http.StatusInternalServerError, "Failed to apply config: "+string(output))
                return
        }

        respondSuccess(w, "Configuration applied successfully")
}

func isIPForwardingEnabled() bool {
        data, err := os.ReadFile("/proc/sys/net/ipv4/ip_forward")
        if err != nil {
                return false
        }
        return strings.TrimSpace(string(data)) == "1"
}

func setIPForwarding(enable bool) bool {
        value := "0"
        if enable {
                value = "1"
        }

        cmd := exec.Command("sysctl", "-w", "net.ipv4.ip_forward="+value)
        return cmd.Run() == nil
}

func isMasqueradingEnabled() bool {
        cmd := exec.Command("nft", "list", "table", "ip", cfg.Firewall.NATTableName)
        output, err := cmd.Output()
        if err != nil {
                return false
        }
        return strings.Contains(string(output), "masquerade")
}

func setMasquerading(enable bool, iface string) bool {
        if enable {
                if err := exec.Command("nft", "add", "table", "ip", cfg.Firewall.NATTableName).Run(); err != nil {
                        logger.Log.Debug("nft add table failed (may already exist)", "table", cfg.Firewall.NATTableName, "error", err)
                }
                if err := exec.Command("nft", "add", "chain", "ip", cfg.Firewall.NATTableName, "postrouting", "{", "type", "nat", "hook", "postrouting", "priority", "100", ";", "}").Run(); err != nil {
                        logger.Log.Debug("nft add chain failed (may already exist)", "chain", "postrouting", "error", err)
                }
                
                if err := exec.Command("nft", "flush", "chain", "ip", cfg.Firewall.NATTableName, "postrouting").Run(); err != nil {
                        logger.Log.Warn("failed to flush postrouting chain", "error", err)
                }
                
                cmd := exec.Command("nft", "add", "rule", "ip", cfg.Firewall.NATTableName, "postrouting", "oifname", iface, "masquerade")
                if err := cmd.Run(); err != nil {
                        logger.Log.Error("failed to add masquerade rule", "interface", iface, "error", err)
                        return false
                }
                return true
        } else {
                if err := exec.Command("nft", "flush", "chain", "ip", cfg.Firewall.NATTableName, "postrouting").Run(); err != nil {
                        logger.Log.Warn("failed to flush postrouting chain", "error", err)
                }
                return true
        }
}

func setupInterfaceForwarding(sourceIface, destIface string) bool {
        if err := exec.Command("nft", "add", "table", "inet", cfg.Firewall.FilterTableName).Run(); err != nil {
                logger.Log.Debug("nft add table failed (may already exist)", "table", cfg.Firewall.FilterTableName, "error", err)
        }
        if err := exec.Command("nft", "add", "chain", "inet", cfg.Firewall.FilterTableName, "forward", "{", "type", "filter", "hook", "forward", "priority", "0", ";", "}").Run(); err != nil {
                logger.Log.Debug("nft add chain failed (may already exist)", "chain", "forward", "error", err)
        }
        
        if err := exec.Command("nft", "flush", "chain", "inet", cfg.Firewall.FilterTableName, "forward").Run(); err != nil {
                logger.Log.Warn("failed to flush forward chain", "error", err)
        }
        
        if err := exec.Command("nft", "add", "rule", "inet", cfg.Firewall.FilterTableName, "forward", "iifname", sourceIface, "oifname", destIface, "accept").Run(); err != nil {
                logger.Log.Error("failed to add forward rule", "source", sourceIface, "dest", destIface, "error", err)
                return false
        }
        if err := exec.Command("nft", "add", "rule", "inet", cfg.Firewall.FilterTableName, "forward", "iifname", destIface, "oifname", sourceIface, "ct", "state", "related,established", "accept").Run(); err != nil {
                logger.Log.Error("failed to add return forward rule", "source", destIface, "dest", sourceIface, "error", err)
                return false
        }
        return true
}

func getNftablesRules() []FirewallRule {
        rules := []FirewallRule{}

        cmd := exec.Command("nft", "-a", "list", "ruleset")
        output, err := cmd.Output()
        if err != nil {
                return rules
        }

        lines := strings.Split(string(output), "\n")
        currentTable := ""
        currentChain := ""

        for _, line := range lines {
                line = strings.TrimSpace(line)

                if strings.HasPrefix(line, "table ") {
                        parts := strings.Fields(line)
                        if len(parts) >= 3 {
                                currentTable = parts[1] + " " + parts[2]
                        }
                } else if strings.HasPrefix(line, "chain ") {
                        parts := strings.Fields(line)
                        if len(parts) >= 2 {
                                currentChain = parts[1]
                        }
                } else if strings.Contains(line, "# handle ") && currentTable != "" && currentChain != "" {
                        parts := strings.Split(line, "# handle ")
                        if len(parts) == 2 {
                                rule := strings.TrimSpace(parts[0])
                                handle := strings.TrimSpace(parts[1])

                                if rule != "" && !strings.HasPrefix(rule, "type ") && !strings.HasPrefix(rule, "policy ") {
                                        rules = append(rules, FirewallRule{
                                                Table:  currentTable,
                                                Chain:  currentChain,
                                                Rule:   rule,
                                                Handle: handle,
                                        })
                                }
                        }
                }
        }

        return rules
}
