
package handlers

import (
        "bufio"
        "crypto/rand"
        "crypto/sha256"
        "encoding/hex"
        "encoding/json"
        "fmt"
        "net/http"
        "os"
        "os/exec"
        "path/filepath"
        "strings"

        "amneziawg-manager/models"
)

func generateRouteID() string {
        b := make([]byte, 8)
        rand.Read(b)
        return hex.EncodeToString(b)
}

// sanitizeTunnelNameForIpset converts tunnel name to ipset-safe short hash
// Ipset has 31-char limit; with prefix "ar_" (3) + hash (6) + "_" (1) + routeID (16) = 26 chars
func sanitizeTunnelNameForIpset(name string) string {
        // Use SHA256 hash and take first 6 characters for uniqueness
        hash := sha256.Sum256([]byte(name))
        return hex.EncodeToString(hash[:])[:6]
}

func setupNftablesTable() error {
        commands := []string{
                fmt.Sprintf("nft add table inet %s", NftTableName),
                fmt.Sprintf("nft add chain inet %s prerouting { type filter hook prerouting priority -100 \\; }", NftTableName),
                fmt.Sprintf("nft add chain inet %s output { type filter hook output priority -100 \\; }", NftTableName),
        }

        for _, cmdStr := range commands {
                cmd := exec.Command("sh", "-c", cmdStr)
                cmd.Run() // Ignore errors if already exists
        }

        return nil
}

func createIpset(tunnelName string, routeID string, filterFile string) error {
        // Namespace ipset by tunnel name hash to avoid collisions (ipset 31-char limit)
        // Format: ar_<hash6>_<routeID> = 3 + 6 + 1 + 16 = 26 chars
        ipsetName := "ar_" + sanitizeTunnelNameForIpset(tunnelName) + "_" + routeID

        // Create ipset
        cmd := exec.Command("ipset", "create", ipsetName, "hash:net", "-exist")
        if err := cmd.Run(); err != nil {
                return fmt.Errorf("failed to create ipset: %v", err)
        }

        // Flush ipset
        cmd = exec.Command("ipset", "flush", ipsetName)
        if err := cmd.Run(); err != nil {
                return fmt.Errorf("failed to flush ipset: %v", err)
        }

        // Read filter file and add entries
        file, err := os.Open(filterFile)
        if err != nil {
                return fmt.Errorf("failed to open filter file: %v", err)
        }
        defer file.Close()

        scanner := bufio.NewScanner(file)
        for scanner.Scan() {
                line := strings.TrimSpace(scanner.Text())
                if line == "" || strings.HasPrefix(line, "#") {
                        continue
                }

                cmd = exec.Command("ipset", "add", ipsetName, line, "-exist")
                cmd.Run() // Continue on error
        }

        return nil
}

func destroyIpset(tunnelName string, routeID string) error {
        // Namespace ipset by tunnel name hash to match creation (ipset 31-char limit)
        // Format: ar_<hash6>_<routeID> = 3 + 6 + 1 + 16 = 26 chars
        ipsetName := "ar_" + sanitizeTunnelNameForIpset(tunnelName) + "_" + routeID
        cmd := exec.Command("ipset", "destroy", ipsetName)
        return cmd.Run()
}

func applyRoutingRules(tunnel *models.Tunnel) error {
        if tunnel.Mode != models.ModeNonGateway {
                return nil
        }

        // Setup nftables if not exists
        setupNftablesTable()

        for _, route := range tunnel.Routes {
                if !route.Enabled {
                        continue
                }

                // Skip routes without filter file - nothing to route
                if route.FilterFile == "" {
                        continue
                }

                // Namespace ipset by tunnel name hash to avoid collisions (ipset 31-char limit)
                // Format: ar_<hash6>_<routeID> = 3 + 6 + 1 + 16 = 26 chars
                ipsetName := "ar_" + sanitizeTunnelNameForIpset(tunnel.Name) + "_" + route.ID

                // Create ipset from filter file
                if err := createIpset(tunnel.Name, route.ID, route.FilterFile); err != nil {
                        return err
                }

                // Create unique comment identifier: tunnel_name:route_id (safe characters only)
                commentID := fmt.Sprintf("%s:%s", tunnel.Name, route.ID)

                // Build nft command with proper escaping - use direct command args, not shell
                var nftArgs []string
                switch route.Action {
                case models.ActionDirect:
                        nftArgs = []string{"add", "rule", "inet", NftTableName, "prerouting", 
                                "ip", "saddr", "@" + ipsetName, "mark", "set", "0x1", "counter", "comment", commentID}
                case models.ActionTunnel:
                        if route.TargetTunnel != "" {
                                mark := getTunnelMark(route.TargetTunnel)
                                nftArgs = []string{"add", "rule", "inet", NftTableName, "prerouting",
                                        "ip", "saddr", "@" + ipsetName, "mark", "set", mark, "counter", "comment", commentID}
                        }
                case models.ActionBlock:
                        nftArgs = []string{"add", "rule", "inet", NftTableName, "prerouting",
                                "ip", "saddr", "@" + ipsetName, "drop", "counter", "comment", commentID}
                }

                if len(nftArgs) > 0 {
                        cmd := exec.Command("nft", nftArgs...)
                        if err := cmd.Run(); err != nil {
                                return fmt.Errorf("failed to apply nftables rule: %v", err)
                        }
                }
        }

        return nil
}

func clearRoutingRules(tunnel *models.Tunnel) error {
        // Remove nftables rules for this tunnel's routes only
        for _, route := range tunnel.Routes {
                // Create the same comment ID we used when adding the rule
                commentID := fmt.Sprintf("%s:%s", tunnel.Name, route.ID)
                
                // Get list of rules with handles from prerouting chain
                cmd := exec.Command("nft", "-a", "list", "chain", "inet", NftTableName, "prerouting")
                output, err := cmd.Output()
                if err == nil {
                        // Parse output to find rules with our comment
                        lines := strings.Split(string(output), "\n")
                        for _, line := range lines {
                                // Check if line contains our comment ID
                                if strings.Contains(line, "comment \""+commentID+"\"") && strings.Contains(line, "# handle ") {
                                        // Extract handle number
                                        parts := strings.Split(line, "# handle ")
                                        if len(parts) == 2 {
                                                handle := strings.TrimSpace(parts[1])
                                                // Delete rule by handle
                                                delCmd := exec.Command("nft", "delete", "rule", "inet", NftTableName, "prerouting", "handle", handle)
                                                delCmd.Run() // Ignore errors
                                        }
                                }
                        }
                }
                
                // Destroy ipset for this route (namespaced by tunnel name)
                destroyIpset(tunnel.Name, route.ID)
        }

        return nil
}

func getTunnelMark(tunnelName string) string {
        // Simple hash-based mark generation
        hash := 0
        for _, c := range tunnelName {
                hash = hash*31 + int(c)
        }
        return fmt.Sprintf("0x%x", (hash&0xFFFF)+0x1000)
}

func checkDefaultGatewayConflict(tunnelName string) (bool, error) {
        tunnels, err := listTunnels()
        if err != nil {
                return false, err
        }

        for _, t := range tunnels {
                if t.Name == tunnelName {
                        continue
                }
                if t.Status == "up" {
                        config, _ := loadTunnelConfig(t.Name)
                        if config != nil && config.Mode == models.ModeDefaultGateway {
                                return true, nil
                        }
                }
        }

        return false, nil
}

func loadTunnelConfig(name string) (*models.Tunnel, error) {
        filePath, err := validateFilePath(name + ".conf")
        if err != nil {
                return nil, err
        }

        metaPath := strings.TrimSuffix(filePath, ".conf") + ".meta.json"
        data, err := os.ReadFile(metaPath)
        if err != nil {
                return nil, err
        }

        var tunnel models.Tunnel
        if err := json.Unmarshal(data, &tunnel); err != nil {
                return nil, err
        }

        return &tunnel, nil
}

func saveTunnelConfig(tunnel *models.Tunnel) error {
        filePath, err := validateFilePath(tunnel.Name + ".conf")
        if err != nil {
                return err
        }

        metaPath := strings.TrimSuffix(filePath, ".conf") + ".meta.json"
        data, err := json.MarshalIndent(tunnel, "", "  ")
        if err != nil {
                return err
        }

        return os.WriteFile(metaPath, data, 0600)
}

func APIGetTunnelConfigHandler(w http.ResponseWriter, r *http.Request) {
        name := r.URL.Query().Get("name")

        if err := validateTunnelName(name); err != nil {
                http.Error(w, err.Error(), http.StatusBadRequest)
                return
        }

        config, err := loadTunnelConfig(name)
        if err != nil {
                config = &models.Tunnel{
                        Name:   name,
                        Mode:   models.ModeNonGateway,
                        Routes: []models.Route{},
                }
        }

        w.Header().Set("Content-Type", "application/json")
        json.NewEncoder(w).Encode(config)
}

func APIUpdateTunnelConfigHandler(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")
        
        var tunnel models.Tunnel
        if err := json.NewDecoder(r.Body).Decode(&tunnel); err != nil {
                w.WriteHeader(http.StatusBadRequest)
                json.NewEncoder(w).Encode(map[string]interface{}{
                        "success": false,
                        "message": "Invalid request: " + err.Error(),
                })
                return
        }

        if err := validateTunnelName(tunnel.Name); err != nil {
                w.WriteHeader(http.StatusBadRequest)
                json.NewEncoder(w).Encode(map[string]interface{}{
                        "success": false,
                        "message": err.Error(),
                })
                return
        }

        // Check for default gateway conflict
        if tunnel.Mode == models.ModeDefaultGateway {
                conflict, err := checkDefaultGatewayConflict(tunnel.Name)
                if err != nil {
                        w.WriteHeader(http.StatusInternalServerError)
                        json.NewEncoder(w).Encode(map[string]interface{}{
                                "success": false,
                                "message": err.Error(),
                        })
                        return
                }
                if conflict {
                        w.WriteHeader(http.StatusConflict)
                        json.NewEncoder(w).Encode(map[string]interface{}{
                                "success": false,
                                "message": "Another tunnel is already running as default gateway",
                        })
                        return
                }
        }

        if err := saveTunnelConfig(&tunnel); err != nil {
                w.WriteHeader(http.StatusInternalServerError)
                json.NewEncoder(w).Encode(map[string]interface{}{
                        "success": false,
                        "message": "Failed to save configuration: " + err.Error(),
                })
                return
        }

        w.Header().Set("Content-Type", "application/json")
        json.NewEncoder(w).Encode(map[string]interface{}{
                "success": true,
                "message": "Configuration saved successfully",
        })
}

func APIListRoutesHandler(w http.ResponseWriter, r *http.Request) {
        tunnelName := r.URL.Query().Get("tunnel")
        
        if err := validateTunnelName(tunnelName); err != nil {
                http.Error(w, err.Error(), http.StatusBadRequest)
                return
        }

        config, err := loadTunnelConfig(tunnelName)
        if err != nil {
                w.Header().Set("Content-Type", "application/json")
                json.NewEncoder(w).Encode([]models.Route{})
                return
        }

        w.Header().Set("Content-Type", "application/json")
        json.NewEncoder(w).Encode(config.Routes)
}

func APIAddRouteHandler(w http.ResponseWriter, r *http.Request) {
        var req struct {
                TunnelName string       `json:"tunnel_name"`
                Route      models.Route `json:"route"`
        }

        if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
                http.Error(w, err.Error(), http.StatusBadRequest)
                return
        }

        if err := validateTunnelName(req.TunnelName); err != nil {
                http.Error(w, err.Error(), http.StatusBadRequest)
                return
        }

        config, err := loadTunnelConfig(req.TunnelName)
        if err != nil {
                http.Error(w, "Tunnel configuration not found", http.StatusNotFound)
                return
        }

        if config.Mode != models.ModeNonGateway {
                http.Error(w, "Routing rules only available for non-gateway tunnels", http.StatusBadRequest)
                return
        }

        req.Route.ID = generateRouteID()
        config.Routes = append(config.Routes, req.Route)

        if err := saveTunnelConfig(config); err != nil {
                http.Error(w, "Failed to save route", http.StatusInternalServerError)
                return
        }

        w.Header().Set("Content-Type", "application/json")
        json.NewEncoder(w).Encode(map[string]interface{}{
                "success": true,
                "message": "Route added successfully",
                "route":   req.Route,
        })
}

func APIDeleteRouteHandler(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")
        
        var req struct {
                TunnelName string `json:"tunnel_name"`
                RouteID    string `json:"route_id"`
        }

        if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
                w.WriteHeader(http.StatusBadRequest)
                json.NewEncoder(w).Encode(map[string]interface{}{
                        "success": false,
                        "message": "Invalid request: " + err.Error(),
                })
                return
        }

        config, err := loadTunnelConfig(req.TunnelName)
        if err != nil {
                w.WriteHeader(http.StatusNotFound)
                json.NewEncoder(w).Encode(map[string]interface{}{
                        "success": false,
                        "message": "Tunnel configuration not found",
                })
                return
        }

        newRoutes := []models.Route{}
        for _, route := range config.Routes {
                if route.ID != req.RouteID {
                        newRoutes = append(newRoutes, route)
                } else {
                        // Destroy ipset for this route (namespaced by tunnel name)
                        destroyIpset(req.TunnelName, route.ID)
                }
        }

        config.Routes = newRoutes

        if err := saveTunnelConfig(config); err != nil {
                w.WriteHeader(http.StatusInternalServerError)
                json.NewEncoder(w).Encode(map[string]interface{}{
                        "success": false,
                        "message": "Failed to delete route: " + err.Error(),
                })
                return
        }

        w.Header().Set("Content-Type", "application/json")
        json.NewEncoder(w).Encode(map[string]interface{}{
                "success": true,
                "message": "Route deleted successfully",
        })
}

func APIListFilterFilesHandler(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")
        
        filterFiles := []map[string]interface{}{}
        
        // List files from RoutesDir
        if err := os.MkdirAll(RoutesDir, 0755); err == nil {
                if files, err := os.ReadDir(RoutesDir); err == nil {
                        for _, file := range files {
                                if !file.IsDir() && strings.HasSuffix(file.Name(), ".txt") {
                                        info, _ := file.Info()
                                        filterFiles = append(filterFiles, map[string]interface{}{
                                                "name": file.Name(),
                                                "path": filepath.Join(RoutesDir, file.Name()),
                                                "size": info.Size(),
                                                "type": "route",
                                        })
                                }
                        }
                }
        }
        
        // List files from CidrDbsDir
        if err := os.MkdirAll(CidrDbsDir, 0755); err == nil {
                if files, err := os.ReadDir(CidrDbsDir); err == nil {
                        for _, file := range files {
                                if !file.IsDir() && strings.HasSuffix(file.Name(), ".pt") {
                                        info, _ := file.Info()
                                        filterFiles = append(filterFiles, map[string]interface{}{
                                                "name": file.Name(),
                                                "path": filepath.Join(CidrDbsDir, file.Name()),
                                                "size": info.Size(),
                                                "type": "cidr",
                                        })
                                }
                        }
                }
        }

        json.NewEncoder(w).Encode(filterFiles)
}

func APIUploadFilterFileHandler(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")
        
        if err := r.ParseMultipartForm(10 << 20); err != nil {
                w.WriteHeader(http.StatusBadRequest)
                json.NewEncoder(w).Encode(map[string]interface{}{
                        "success": false,
                        "message": "Invalid request: " + err.Error(),
                })
                return
        }

        file, header, err := r.FormFile("file")
        if err != nil {
                w.WriteHeader(http.StatusBadRequest)
                json.NewEncoder(w).Encode(map[string]interface{}{
                        "success": false,
                        "message": "No file provided: " + err.Error(),
                })
                return
        }
        defer file.Close()

        if !strings.HasSuffix(header.Filename, ".txt") {
                w.WriteHeader(http.StatusBadRequest)
                json.NewEncoder(w).Encode(map[string]interface{}{
                        "success": false,
                        "message": "Only .txt files are allowed",
                })
                return
        }

        if err := os.MkdirAll(RoutesDir, 0755); err != nil {
                w.WriteHeader(http.StatusInternalServerError)
                json.NewEncoder(w).Encode(map[string]interface{}{
                        "success": false,
                        "message": "Failed to create routes directory",
                })
                return
        }

        filename := filepath.Base(header.Filename)
        filePath := filepath.Join(RoutesDir, filename)

        dst, err := os.Create(filePath)
        if err != nil {
                w.WriteHeader(http.StatusInternalServerError)
                json.NewEncoder(w).Encode(map[string]interface{}{
                        "success": false,
                        "message": "Failed to save file: " + err.Error(),
                })
                return
        }
        defer dst.Close()

        if _, err := dst.ReadFrom(file); err != nil {
                w.WriteHeader(http.StatusInternalServerError)
                json.NewEncoder(w).Encode(map[string]interface{}{
                        "success": false,
                        "message": "Failed to write file: " + err.Error(),
                })
                return
        }

        w.Header().Set("Content-Type", "application/json")
        json.NewEncoder(w).Encode(map[string]interface{}{
                "success": true,
                "message": "Filter file uploaded successfully",
                "path":    filePath,
        })
}

func APIUploadCidrFileHandler(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")
        
        if err := r.ParseMultipartForm(10 << 20); err != nil {
                w.WriteHeader(http.StatusBadRequest)
                json.NewEncoder(w).Encode(map[string]interface{}{
                        "success": false,
                        "message": "Invalid request: " + err.Error(),
                })
                return
        }

        // Get company name from form
        companyName := r.FormValue("company_name")
        if companyName == "" {
                w.WriteHeader(http.StatusBadRequest)
                json.NewEncoder(w).Encode(map[string]interface{}{
                        "success": false,
                        "message": "Company name is required",
                })
                return
        }

        // Sanitize company name
        companyName = strings.TrimSpace(companyName)
        companyName = strings.ToLower(companyName)
        companyName = strings.ReplaceAll(companyName, " ", "_")
        // Remove any special characters
        var sanitized strings.Builder
        for _, r := range companyName {
                if (r >= 'a' && r <= 'z') || (r >= '0' && r <= '9') || r == '_' || r == '-' {
                        sanitized.WriteRune(r)
                }
        }
        companyName = sanitized.String()
        
        if companyName == "" {
                w.WriteHeader(http.StatusBadRequest)
                json.NewEncoder(w).Encode(map[string]interface{}{
                        "success": false,
                        "message": "Invalid company name",
                })
                return
        }

        file, _, err := r.FormFile("file")
        if err != nil {
                w.WriteHeader(http.StatusBadRequest)
                json.NewEncoder(w).Encode(map[string]interface{}{
                        "success": false,
                        "message": "No file provided: " + err.Error(),
                })
                return
        }
        defer file.Close()

        if err := os.MkdirAll(CidrDbsDir, 0755); err != nil {
                w.WriteHeader(http.StatusInternalServerError)
                json.NewEncoder(w).Encode(map[string]interface{}{
                        "success": false,
                        "message": "Failed to create cidrdbs directory",
                })
                return
        }

        // Generate filename: [company_name]_cidr.pt
        filename := fmt.Sprintf("%s_cidr.pt", companyName)
        filePath := filepath.Join(CidrDbsDir, filename)

        dst, err := os.Create(filePath)
        if err != nil {
                w.WriteHeader(http.StatusInternalServerError)
                json.NewEncoder(w).Encode(map[string]interface{}{
                        "success": false,
                        "message": "Failed to save file: " + err.Error(),
                })
                return
        }
        defer dst.Close()

        if _, err := dst.ReadFrom(file); err != nil {
                w.WriteHeader(http.StatusInternalServerError)
                json.NewEncoder(w).Encode(map[string]interface{}{
                        "success": false,
                        "message": "Failed to write file: " + err.Error(),
                })
                return
        }

        json.NewEncoder(w).Encode(map[string]interface{}{
                "success": true,
                "message": "CIDR file uploaded successfully",
                "path":    filePath,
                "filename": filename,
        })
}

func APIListAllRoutesHandler(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")
        
        tunnels, err := listTunnels()
        if err != nil {
                w.WriteHeader(http.StatusInternalServerError)
                json.NewEncoder(w).Encode([]interface{}{})
                return
        }

        allRoutes := []map[string]interface{}{}
        
        for _, tunnel := range tunnels {
                config, err := loadTunnelConfig(tunnel.Name)
                if err != nil || config == nil {
                        continue
                }
                
                if config.Mode != models.ModeNonGateway {
                        continue
                }
                
                for _, route := range config.Routes {
                        allRoutes = append(allRoutes, map[string]interface{}{
                                "tunnel_name":   tunnel.Name,
                                "id":           route.ID,
                                "name":         route.Name,
                                "filter_file":  route.FilterFile,
                                "action":       route.Action,
                                "target_tunnel": route.TargetTunnel,
                                "priority":     route.Priority,
                                "enabled":      route.Enabled,
                        })
                }
        }

        json.NewEncoder(w).Encode(allRoutes)
}
